/* Assertions on the procedural gaussian emitter — the runtime bake (§5c path A).
   Run: node nebula/test_splat_emit.js                                        */
require('./core.js');
const E = require('./splat_emit.js');
const N = globalThis.NEBULA;

let P = 0, F = 0;
const ok = (n, c, d = '') => {
  if (c) { P++; console.log(`  \x1b[32mPASS\x1b[0m  ${n}${d ? '  \x1b[90m' + d + '\x1b[0m' : ''}`); }
  else { F++; console.log(`  \x1b[31mFAIL\x1b[0m  ${n}  ${d}`); }
};
const hdr = s => console.log(`\n\x1b[1m${s}\x1b[0m`);
const dim = s => console.log(`  \x1b[90m${s}\x1b[0m`);

const W = 128, H = 80;
const world = new N.World(W, H, 1337);
for (let i = 0; i < 40; i++) world.microStep(1);
const agent = new N.SettlerAgent(1, { cooldown: 6, seed: 3 });
for (let i = 0; i < 12; i++) world.macroStep([agent]);

hdr('Emission — determinism and structural invariants');

const t0 = Date.now();
const g = E.emit(world, { density: 16, seed: 1 });
const emitMs = Date.now() - t0;
dim(`density 16 on a ${W}x${H} world: ${g.count.toLocaleString()} gaussians in ${emitMs} ms`);
dim(`wire size ${ (g.bytes/1024).toFixed(0) } KB (32 B/gaussian)`);

const g2 = E.emit(world, { density: 16, seed: 1 });
let identical = g2.count === g.count;
if (identical) for (let i = 0; i < g.pos.length; i++) if (g2.pos[i] !== g.pos[i]) { identical = false; break; }
ok('same seed produces byte-identical output (bake is a pure function of truth)', identical);

const g3 = E.emit(world, { density: 16, seed: 2 });
ok('different seed produces different placement', g3.pos[0] !== g.pos[0] || g3.count !== g.count);

let nonFinite = 0, badOpacity = 0, badScale = 0, outOfBounds = 0;
for (let i = 0; i < g.count; i++) {
  for (let k = 0; k < 3; k++) {
    if (!isFinite(g.pos[i*3+k]) || !isFinite(g.scale[i*3+k]) || !isFinite(g.color[i*3+k])) nonFinite++;
  }
  for (let k = 0; k < 4; k++) if (!isFinite(g.rot[i*4+k])) nonFinite++;
  if (!(g.opacity[i] >= 0 && g.opacity[i] <= 1)) badOpacity++;
  for (let k = 0; k < 3; k++) if (!(g.scale[i*3+k] > 0)) badScale++;
  const x = g.pos[i*3], z = g.pos[i*3+2];
  if (x < -2 || x > W * E.CELL_METRES + 2 || z < -2 || z > H * E.CELL_METRES + 2) outOfBounds++;
}
ok('no NaN or Infinity anywhere in the output', nonFinite === 0, `${nonFinite} non-finite values`);
ok('all opacities are in [0,1]', badOpacity === 0, `${badOpacity} out of range`);
ok('all scales are strictly positive (log-space packing requires it)', badScale === 0, `${badScale} non-positive`);
ok('all positions lie within the world footprint', outOfBounds === 0, `${outOfBounds} outside`);

// quaternion sanity: the viewer and .splat consumers assume unit-ish quaternions
let badQuat = 0;
for (let i = 0; i < g.count; i++) {
  const l = Math.hypot(g.rot[i*4], g.rot[i*4+1], g.rot[i*4+2], g.rot[i*4+3]);
  if (Math.abs(l - 1) > 0.02) badQuat++;
}
ok('rotations are unit quaternions', badQuat === 0, `${badQuat} non-unit of ${g.count}`);

hdr('Layers are placed where they belong');
const kinds = { 0: [], 1: [], 2: [], 3: [] };
for (let i = 0; i < g.count; i++) kinds[g.kind[i]].push(i);
dim(`terrain=${kinds[0].length.toLocaleString()}  vegetation=${kinds[1].length.toLocaleString()}  water=${kinds[2].length.toLocaleString()}  structure=${kinds[3].length.toLocaleString()}`);
ok('all four layers are populated', Object.values(kinds).every(a => a.length > 0));

// vegetation must sit ABOVE the terrain, or it reads as paint on the ground
let vegBelow = 0;
for (const i of kinds[1]) {
  const x = g.pos[i*3] / E.CELL_METRES, z = g.pos[i*3+2] / E.CELL_METRES;
  const xi = Math.min(W-1, Math.max(0, Math.round(x))), zi = Math.min(H-1, Math.max(0, Math.round(z)));
  const terrY = world.ch[N.CH.ELEV][zi*W+xi] * E.HEIGHT_METRES;
  if (g.pos[i*3+1] <= terrY) vegBelow++;
}
ok('vegetation sits above the terrain surface', vegBelow < kinds[1].length * 0.05,
  `${vegBelow}/${kinds[1].length} below ground`);

// water must sit at the waterline, flat
const waterY = 0.30 * E.HEIGHT_METRES;
let waterOff = 0;
for (const i of kinds[2]) if (Math.abs(g.pos[i*3+1] - (waterY + 0.02)) > 1e-4) waterOff++;
ok('the water sheet is flat at the waterline', waterOff === 0, `${waterOff} misplaced of ${kinds[2].length}`);

// terrain height must match the symbolic channel it came from
let terrErr = 0, terrMax = 0;
for (const i of kinds[0]) {
  const x = g.pos[i*3] / E.CELL_METRES, z = g.pos[i*3+2] / E.CELL_METRES;
  const e = E.bilerp(world.ch[N.CH.ELEV], W, H, x, z);
  const d = Math.abs(g.pos[i*3+1] - e * E.HEIGHT_METRES);
  terrErr += d; terrMax = Math.max(terrMax, d);
}
ok('terrain gaussians sit exactly on the symbolic heightfield',
  terrErr / kinds[0].length < 1e-4, `mean err ${(terrErr/kinds[0].length).toExponential(2)} m, max ${terrMax.toExponential(2)} m`);

hdr('Wire format round-trip');
const buf = E.toSplatBytes(g);
ok('packed size is exactly 32 bytes per gaussian', buf.byteLength === g.count * 32,
  `${buf.byteLength} vs ${g.count*32}`);
const back = E.fromSplatBytes(buf);
ok('round-trip preserves the gaussian count', back.count === g.count);
let maxPos = 0, maxScale = 0, maxCol = 0, maxOp = 0;
for (let i = 0; i < g.count * 3; i++) {
  maxPos = Math.max(maxPos, Math.abs(back.pos[i] - g.pos[i]));
  maxScale = Math.max(maxScale, Math.abs(back.scale[i] - g.scale[i]) / g.scale[i]);
  maxCol = Math.max(maxCol, Math.abs(back.color[i] - g.color[i]));
}
for (let i = 0; i < g.count; i++) maxOp = Math.max(maxOp, Math.abs(back.opacity[i] - g.opacity[i]));
ok('positions survive the round-trip exactly (float32 both ways)', maxPos === 0, `max err ${maxPos}`);
ok('scales survive to within float32 exp/log precision', maxScale < 1e-5, `max rel err ${maxScale.toExponential(2)}`);
ok('colour error is bounded by 8-bit quantisation', maxCol <= 1/255 + 1e-6, `max err ${maxCol.toFixed(5)} (1/255 = ${(1/255).toFixed(5)})`);
ok('opacity error is bounded by 8-bit quantisation', maxOp <= 1/255 + 1e-6, `max err ${maxOp.toFixed(5)}`);

hdr('Density scaling — the fidelity dial');
dim('  ' + 'density'.padStart(8) + ' ' + 'gaussians'.padStart(11) + ' ' + 'KB'.padStart(7) + ' ' + 'ms'.padStart(7));
let prev = 0;
const rows = [];
for (const d of [1, 4, 9, 16, 25, 36]) {
  const t = Date.now();
  const gg = E.emit(world, { density: d, seed: 1 });
  const ms = Date.now() - t;
  rows.push({ d, n: gg.count, kb: gg.bytes/1024, ms });
  dim(`  ${String(d).padStart(8)} ${gg.count.toLocaleString().padStart(11)} ${(gg.bytes/1024).toFixed(0).padStart(7)} ${String(ms).padStart(7)}`);
  prev = gg.count;
}
ok('gaussian count rises monotonically with density', rows.every((r, i) => i === 0 || r.n > rows[i-1].n));
ok('wire size rises proportionally (32 B/gaussian, no surprises)',
  Math.abs(rows[5].kb / rows[0].kb - rows[5].n / rows[0].n) < 0.01,
  `${(rows[5].kb/rows[0].kb).toFixed(2)}x bytes for ${(rows[5].n/rows[0].n).toFixed(2)}x gaussians`);
const scaling = Math.log(rows[5].ms / Math.max(1, rows[0].ms)) / Math.log(rows[5].n / rows[0].n);
dim(`  time scaling exponent: ${scaling.toFixed(2)} (1.0 = linear)`);

hdr('Bake cost — the number §5c is built on');
const bench = E.emit(world, { density: 9, seed: 1 });
const runs = [];
for (let i = 0; i < 5; i++) { const t = Date.now(); E.emit(world, { density: 9, seed: 1 }); runs.push(Date.now() - t); }
const best = Math.min(...runs);
dim(`  ${bench.count.toLocaleString()} gaussians in ${best} ms (min of 5, 2 Xeon cores)`);
dim(`  ${(bench.count/1000/best).toFixed(1)}k gaussians/ms   wire ${(bench.bytes/1024).toFixed(0)} KB`);
ok('emission is fast enough to be a runtime operation, not an offline job',
  best < 100, `${best} ms for ${bench.count.toLocaleString()} gaussians`);

// The safety property that justifies the whole split: emission is downstream of
// truth, so a broken emitter cannot corrupt the world.
const fpBefore = world.fingerprint();
E.emit(world, { density: 36, seed: 99 });
ok('emitting does not mutate symbolic truth', world.fingerprint() === fpBefore);

console.log(`\n\x1b[1m${P} passed, ${F} failed\x1b[0m\n`);
process.exit(F ? 1 : 0);
