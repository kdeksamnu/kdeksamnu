# Sprint Review — 5-Sprint Latent Substrate Plan

Reviewed against `nebula/sprint_review.js`, which ports the three quantitatively checkable
subsystems (Sprint 2 LCA, Sprint 3 token bucket, Sprint 5 archive tensor) faithfully to JS and
runs them. No Rust/CUDA/Postgres toolchain in the sandbox, so the SQL, Rust store, CUDA kernel
and WGSL are reviewed by reading; everything numeric below is **measured**, not estimated.

**23 assertions, all passing.** Findings are ordered by severity, not by sprint.

---

## Verdict

Four of the five sprints contain a defect that would ship. Three of them are in the parts the
plan's own Verification Summary marks as validated. The architecture has real merit and absorbs
more of the earlier review than it appears to — but it reintroduces latent-as-truth at the
storage layer while simultaneously having (in the Q/Ψ split) the exact mechanism needed to avoid
it.

**The single highest-value change available:** you already have two streams. Make **Q
authoritative** and **Ψ derived**. Details in §Synthesis.

---

## CRITICAL — would ship broken

### C1. The collapse kernel does not actually project onto basis states

```cuda
for (int k = 0; k < k_max; ++k) {
    float projection = 0.0f;
    for (int d = 0; d < feature_dim; ++d) {
        projection += cell_latent[d] * d_observer_vector[d];   // independent of k
    }
    float logit = (projection / (temperature * sqrtf(feature_dim)))
                + (cell_scar[k] - cell_anti_scar[k])
                + (cell_variance * 0.1f);
```

`projection` does not depend on `k`. It is recomputed identically `k_max` times. Consequences:

- **The world content cannot distinguish basis states.** The only term varying with `k` is the
  scar bias, so collapse outcomes are determined almost entirely by archive history plus noise.
  The latent features select *whether* to collapse, never *what* it collapses into.
- **Sprint 1 already defines the missing piece.** `ManifoldBasis.semantic_signature: [f32; 16]`
  exists for exactly this and is never read by the kernel. The intended design is visible; the
  implementation doesn't match it.
- **`feature_dim × k_max` redundant MACs** per cell. Hoisting the projection out of the loop is
  a free ~16× reduction in the kernel's inner work.

Fix: per-basis projection against `semantic_signature[k]`, hoisted loop.

### C2. `(cell_variance * 0.1f)` is mathematically inert

It is added to every logit equally. Softmax is shift-invariant, so this term **cannot change the
chosen distribution**. If variance is meant to widen the outcome distribution, it belongs on
`temperature`, not on the logits:

```cuda
float logit = projection_k / (temperature * (1.0f + cell_variance) * sqrtf(feature_dim)) + bias_k;
```

As written, variance has no effect on collapse at all — only on the shader's blend factor.

### C3. Archive tensor undergoes complete mode collapse (measured)

Verification claim 5 says the mechanism "works as described". It does, and that is the defect.

```
  collapses   logit gap   p(winning state)   winner   entropy vs uniform
          1        0.14           0.141171        5   99.9% of max
          5        0.41           0.171492        5   99.5% of max
         20        0.81           0.198331        5   98.0% of max
         50        1.38           0.240503        6   96.0% of max
        100        1.79           0.332534        3   90.6% of max
        500       29.68           1.000000        3    0.0% of max
       2000       56.66           1.000000        3    0.0% of max
```

Three separate problems in one table:

1. **Complete collapse.** p(winner) → 1.000000, entropy → 0. The cell becomes deterministic.
2. **The winner is arbitrary.** Watch the `winner` column: 5 → 5 → 5 → **6** → **3** → 3. It
   drifts for ~100 collapses before locking. The outcome is simultaneously terminal and
   unpredictable, which makes it impossible to tune, balance, or QA.
3. **Analytic confirmation.** With η=0.5 per event and γ=0.998 per event:
   `S_ss = 0.5/0.002 = 250` → attractor `+62.5`; `A_ss = 0.35×0.125/0.002 = 21.9` → repulsor
   `−7.7`. Steady-state logit gap ≈ **70**. Simulated 56.7 and still climbing. e⁷⁰ is not a
   probability distribution, it is a constant.

Root causes:
- **γ_decay is per-collapse-event, not per-tick.** The notation `S^{t+1} = S^t · γ_decay` implies
  a time constant; the implementation applies it once per collapse. A cell that collapses rarely
  never decays at all.
- **The anti-scar threshold `p > 0.05` is below uniform `1/K = 0.125`.** So *every* rejected
  state gets an anti-scar on *every* collapse — 7 repulsors at weight 0.35 against 1 attractor
  at 0.25.

**Gameplay consequence:** cells the player visits most collapse most often, so they lock in
hardest and earliest. The most-visited places become the least generative. That is inverted from
what a worldbuilding game wants, and it is invisible until hours into a session.

Measured fix — normalise the bias vector before it reaches the logits:

```
max p = 0.162 after 2000 collapses   (was 1.000000)
```

Full fix list, in leverage order: (1) γ per tick, (2) normalise/bound the bias vector,
(3) raise the anti-scar threshold well above 1/K or drop anti-scars, (4) entropy floor — reject
a collapse whose distribution is below H_min.

### C4. The token bucket does not hold $0.05/hr (measured)

Verification claim 3 says it "permits execution up to the exact $0.05/hr allowance". Measured:

```
  hour 1: $0.08333   <-- 1.67x the stated ceiling
  hour 2: $0.04167
  hour 3: $0.04167
  hour 4: $0.04167
```

**The plan's own math contradicts itself within four lines:**

```
Tokens_consumed(Δt) ≤ C_cap + r·Δt              (first formula)
∫ cost dτ ≤ r × 3600 = 50,000 = $0.05           (second formula)
```

With `C_cap = 50,000` **and** `r·3600 = 50,000`, the first formula gives **100,000 tokens =
$0.10** for hour one. The bucket is initialised full, so the ceiling is breached before the
limiter ever engages. Measured $0.0833 rather than $0.10 only because defect C5 partially masks
it — two bugs cancelling.

Fix: capacity is a *burst* allowance, not a second hour of budget. Set `C_cap ≈ r × 1..2 s`, or
start the bucket empty.

### C5. `cost.ceil()` over-charges short kernels by up to 2000×

```
  kernel duration   true cost        charged        overcharge
       1 µs      $5.00e-10     $1.00e-6        2000x
      10 µs      $5.00e-9      $1.00e-6         200x
     100 µs      $5.00e-8      $1.00e-6          20x
     500 µs      $2.50e-7      $1.00e-6           4x
    2000 µs      $1.00e-6      $1.00e-6           1x
```

The charge quantum is 1 micro-USD = **2 ms of GPU at $1.80/hr**. Every kernel shorter than 2 ms
is billed as if it ran 2 ms. The governor therefore throttles up to 2000× too early — and the
steady-state $0.0417 above is not frugality, it is ~17% of paid-for GPU capacity sitting unused.

The scaled-by-1000 representation already exists to solve this. It is defeated by applying
`ceil()` *before* scaling. Accumulate fractional cost in the scaled u64 and never ceil per call.

### C6. The reject path has a non-atomic store inside a CAS loop

```rust
loop {
    let current = self.available_tokens_scaled.load(Ordering::Acquire);
    let refilled = (current + added_tokens_scaled).min(max_tokens_scaled);
    if refilled < cost_scaled {
        self.available_tokens_scaled.store(refilled, Ordering::Release);   // <-- not a CAS
        return false;
    }
    ...compare_exchange_weak...
}
```

A thread that successfully deducts between this thread's `load` and this `store` has its
deduction **overwritten, and the tokens reappear**. The stated invariant
`consumed ≤ C_cap + r·Δt` is violated under contention — which is precisely the condition the
governor exists to survive.

Also: `added_tokens_scaled` is computed once outside the loop from a `Mutex<Instant>` that every
caller advances. Under contention most callers observe `elapsed ≈ 0`, so refill is serialised
behind that mutex and the lock-free CAS loop is not lock-free. The atomics buy nothing.

Fix: pack (timestamp, tokens) into one `AtomicU64` and use `fetch_update`, or apply refill via
`fetch_add` with saturation and make the reject path a CAS too.

### C7. `j_hash` does not cover the state that changes

`compute_j_hash` hashes: sector, position, tick, observer_count, latent_variance,
parent_merkle_hash, latent_vector.

It does **not** hash:

- **`probability_manifold`** — the central object of Sprint 1, and the one the section header
  calls "Cryptographic Immutability"
- `ego_density`, `consistency_coeff`
- `spectral_weights` (in the SQL schema; absent from the Rust struct entirely)
- `biome_id`, `cultural_lineage_id`
- `scar_tensor_id`, `accumulated_scar_weight`, `accumulated_anti_scar_pressure`
- `latent_features`, `entropy_pulse` — the fields Sprint 2 actually mutates

So the hash cannot detect corruption or tampering in any of them. Sprint 5's `jbp_merkle_hash`
has the same gap (omits `dialetecheic_tension`, `sector_coord`, `last_commit_tick`).

### C8. The autonomous dream is not logged, so Lex I cannot reproduce the past

`step_autonomous_dream` mutates `latent_variance`, `latent_features` and `entropy_pulse` and
emits **no event and no tick stamp**. An append-only Merkle DAG over `spatial_state_vectors`
therefore cannot reconstruct a prior world: the autonomous evolution between commits is simply
missing from the record.

This is the identical bug found and fixed in the Nebula prototype (interleaved replay), where it
produced a detectable fingerprint mismatch. **Here it is undetectable**, because of C7 — nothing
hashes the fields the dream mutates. Two defects compounding into a silent one.

Fix: stamp every dream advance with a tick range and record it as an event, or make the dream a
pure function of (committed state, elapsed ticks) so it can be recomputed rather than replayed.
The second is better — see C12.

### C9. `ManifoldSubstrateStore` is not the database the plan describes

Sprint 1 states state is persisted in PostgreSQL + pgvector. The Rust store is
`Arc<RwLock<HashMap<Uuid, SpatialStateVector>>>`. Nothing touches Postgres.

- `read_manifold_region` is an **O(n) linear scan over all values** under a full read lock. At
  world scale this is unusable, and it holds the lock for the entire scan.
- `spatial_index` is written on every insert and **never read by anything**. Dead code.
- Lock ordering: `storage` then `spatial_index`. Any future path that takes them in the other
  order deadlocks.

### C10. Lex I (Never-Overwrite) is asserted but not enforced — and is violated

Three independent gaps:

1. **`store.insert(verified.id, verified)` silently overwrites** an existing entry with the same
   UUID. `HashMap::insert` replaces. No duplicate check. This directly violates the doctrine the
   schema section is named after.
2. **No `UNIQUE` constraint on `j_hash`**, so the database will happily accept duplicates. For an
   append-only content-addressed store, uniqueness *is* the dedup mechanism — and it is also what
   makes intent idempotency work under an at-least-once broker.
3. **Nothing prevents `UPDATE`/`DELETE`.** Append-only requires revoked write privileges, a
   `BEFORE UPDATE OR DELETE` trigger that raises, or immutable partitions. The SQL has none.

### C11. The hash check is opt-out

```rust
if !vec.j_hash.is_empty() && vec.j_hash != computed {
    return Err(SubstrateError::HashMismatch(computed, vec.j_hash.clone()));
}
```

Pass `j_hash = ""` and the write is accepted unconditionally, with the hash computed for you.
Any caller — buggy or malicious — bypasses verification by omitting the field it is supposed to
verify. Compute server-side only, or always compare.

### C12. `write_manifold_update` is non-atomic

On `HashMismatch` it returns `Err` **after having already inserted every earlier vector in the
batch**. Partial write, no rollback, no transaction. For a store whose entire premise is
integrity, this is the worst place to be non-atomic.

### C13. Observed cells act as a variance sink (measured)

The dream skips `O > 0` cells, leaving them quenched at `0.001` (Sprint 3 sets that on collapse).
But unobserved neighbours still average them into the Laplacian, so variance **drains toward
every observed region**:

```
as submitted : cells adjacent to observed slab = [4.000, 4.000, 3.264], far field = 4.000
with Neumann : cells adjacent to observed slab = [4.000, 4.000, 4.000], far field = 4.000
```

**18.4% deficit adjacent to the slab.** Players carve a dead halo wherever they walk and it does
not refill. Combined with C3, visited regions become both frozen *and* drained.

Fix: reflecting (Neumann) boundary — substitute the cell's own variance for observed neighbours
instead of their quenched value. Measured: deficit → 0.

---

## IMPORTANT

### I1. LCA variance saturates; the 50-step test window hides it (measured)

Verification claim 2 is *literally true and vacuously so* — variance is bounded because
`.clamp()` bounds it. Boundedness is a property of the clamp, not of the dynamics.

```
  step    mean σ²   %at MAX(4.0)   %at MIN
     0    0.9952        0.0%        0.0%
    50    3.5367        9.2%        0.0%    <-- their test stops here
   200    3.9147       74.3%        0.0%
   600    3.9147       74.4%        0.0%

per-biome mean σ² after 600 steps:
  AbyssalMoss        3.9989
  LithicSilt         3.6571
  CrystallineBasalt  3.9994
  SporeCanopy        3.9995
```

**74.4% of cells pinned at the ceiling.** Every biome saturates, including LithicSilt — the only
one with a genuine restoring term — because the dominant source is biome-independent:

```rust
let cult_friction = (cultural_conflict / 6.0) * CULTURAL_FRICTION_RATE;
```

`cultural_conflict ≥ 0` always, so this is a **pure source with no sink**. Total variance is
pumped upward monotonically until the clamp absorbs it. `SporeCanopy`'s
`0.04 * (1 - v/MAX)` asymptotes to MAX rather than to an operating point.

This is the Mush Problem arriving through a different door: instead of averaging to the mean, it
saturates to the maximum. Either way the world loses differentiation.

Measured fix — make friction redistributive rather than additive:

```
with redistributive friction: mean σ² = 2.5988, 0.0% at MAX
```

**Test-window note:** at step 50 only 9.2% of cells are saturated. Any validation that stops at
50 steps will pass a system that is 74% saturated at step 200. Run to steady state or don't claim
stability.

### I2. `CrystallineBasalt` uses float modulo — a discontinuous vector field

```rust
BiomeCategory::CrystallineBasalt => -0.01 * (current_cell.latent_variance % 0.5 - 0.25),
```

`%` on f32 is a remainder, so this is a sawtooth with jump discontinuities every 0.5.
**15 sign flips across σ² ∈ [0.01, 4.0].** Cells chatter across the teeth and the banding shows
up directly in the render. Same class of defect as hard `if` biome thresholds poisoning a ReLU
fit — discontinuities in dynamics or targets always surface.

### I3. `entropy_pulse` grows without bound

`entropy_pulse += 0.05` every tick, never wrapped. `AbyssalMoss` reads `sin(entropy_pulse)`.
Measured: **f32 stops advancing after ~18,073,720 ticks ≈ 84 h at 60 ticks/s**, and `sin()` is
garbage well before that because the argument's ULP exceeds the period.

For a persistent world this is a session-length timescale. And because of C7 the pulse isn't
hashed, so replay divergence is invisible.

Fix: `(pulse + 0.05) % (2π)`. Verified to hold the value bounded with no behavioural cost.

### I4. The token bucket only governs GPU — the ungoverned cost is larger

The governor gates kernel launches. But Sprint 2's dream runs **CPU-side over every unobserved
cell, forever**. For a 64³ sector that is 262,144 cells × ~50 flops per tick; across a shard of
many sectors that is the dominant compute, and nothing bounds it. The $0.05/hr ceiling bounds the
cheaper of the two.

Better: the dream is largely linear diffusion with bounded sources, so **it can be jumped ahead
analytically or with far fewer substeps** rather than integrated every tick. A cell unobserved
for an hour does not need 3,600 steps — it needs the closed-form (or a coarse multi-step)
solution at t+3600. That converts the dream from O(cells × ticks) to O(cells × observations),
which is the difference between affordable and not.

### I5. WGSL: `harmonic_scar_intensity` is declared and never used

```wgsl
struct Uniforms { ...; observer_coherence: f32; harmonic_scar_intensity: f32; };
```

`harmonic_scar_intensity` never appears in the fragment shader. **Sprint 5's entire scar system
has no visual effect on the diegetic canvas** — it only biases the collapse kernel. Given that
Sprint 4 is titled "The Diegetic Canvas" and its stated purpose is that scars are *seen*, this
is a functional gap, not a nit.

`camera_pos` and `screen_resolution` are likewise unused.

### I6. WGSL: colour and alpha use different transition functions

```wgsl
let final_blend = step(dither, collapse_metric);            // binary, dithered
let final_color = mix(probabilistic_veil, lithic_surface, final_blend);
let final_alpha = mix(0.45 + 0.3 * wave_pattern, 1.0, collapse_metric);   // continuous
```

Colour switches hard on the Bayer dither while alpha ramps continuously. At the transition
boundary you get a sharp colour edge inside a soft alpha ramp — visible fringing around every
collapsing cell. Use the same dither for both, or both continuous.

### I7. WGSL: freshly collapsed cells render black

`lithic_surface = color * n_dot_l * cell_res.permanence`. Sprint 3 sets
`d_collapsed_potentiality[cell_id] = probs[chosen]` and quenches variance, but nothing
initialises `permanence`. If it starts at 0, the cell is black at the exact moment of collapse —
the most visually important instant in the system.

### I8. WGSL: no bounds check on runtime-sized arrays

`grid_dim = 64` implies 262,144 instances indexing `array<ResolutionCell>` and
`array<PotentialityCell>`. Runtime-sized storage arrays give undefined/zero on OOB. If the
streams are ever shorter than the instance count — a partially loaded sector, a streaming race —
you get silent black cells rather than a diagnostic. Clamp the index.

### I9. `q_state % 7u` conflates basis state with spectral constant

Sprint 1 keeps `spectral_weights REAL[7]` and the Ψ stream carries `spectral_constant_idx` as
separate fields. The resolved colour derives from `q_state % 7`, so basis index and spectral
constant are silently identified, and two different basis states can share a colour. Either
store the spectral constant in the Q stream or map basis→spectral explicitly.

### I10. `BASIS_DIM = 8` vs `MAX_BASIS_STATES = 16`

Sprint 5 fixes `BASIS_DIM = 8`; Sprint 3 caps at 16 and strides the bias arrays by a runtime
`basis_count`. Nothing enforces agreement. If `basis_count > 8`, `record_collapse`'s
`&[f32; 8]` cannot represent the extra states and the kernel reads bias memory the archive never
wrote.

### I11. `uuid_generate_v4()` breaks reproducibility

Random UUIDs mean replaying the log produces different primary keys, so a rebuild cannot be
compared against the original row-for-row. For a deterministic append-only store, derive the id
from content: `uuid_generate_v5(namespace, j_hash)`, or make `j_hash` the primary key.

### I12. Schema lacks the constraints the doctrine needs

No `UNIQUE (j_hash)` (see C10). No `CHECK (array_length(spectral_weights,1) = 7)`,
`CHECK (observer_count >= 0)`, `CHECK (latent_variance BETWEEN 0.01 AND 4.0)`,
`CHECK (array_length(latent_vector::real[],1) = 128)`. A 127-element `Vec<f32>` reaches the
database and fails with an opaque pgvector error rather than a clear one at the boundary.

No partitioning by sector, and an **HNSW index on a high-insert append-only table** — HNSW
insertion is expensive and the index will dominate write throughput. Consider deferring the
vector index until semantic traversal is actually on the critical path; the composite
`(sector_x, sector_y, sector_z, temporal_tick)` index is doing the real work.

### I13. Rust struct cannot round-trip the SQL row

`spatial_state_vectors` has `spectral_weights`, `scar_tensor_id`,
`accumulated_scar_weight`, `accumulated_anti_scar_pressure`. None appear in
`SpatialStateVector`. Either the struct is incomplete or the columns are write-only. Also
`parent_merkle_hash` has no genesis convention and no defined chain order — with concurrent
writers into different sectors, "parent" is ambiguous, and that ambiguity is a race.

---

## What is genuinely good

Credit where due — several ideas here are better than what I proposed:

1. **The O=0 / O>0 split is better than time-gated hierarchical inference.** Gating compute on
   *observation* rather than on a fixed macro/micro cadence is a genuinely stronger idea: it
   spends nothing where nobody is looking, and it scales with player attention rather than with
   world size. My §C4 gates by frequency; this gates by relevance. Adopt it.
2. **Append-only + Merkle + deterministic hash** is the right doctrine and matches C1 exactly.
   Lex I is correct. It just isn't enforced yet (C10).
3. **The token bucket governor** is the right mechanism and the right instinct — it is my §5b
   bake quota, generalised to GPU time. The implementation needs C4–C6 fixed; the concept is
   sound and should be kept.
4. **The Q / Ψ two-stream renderer** is structurally the truth/appearance split from the earlier
   review, arrived at independently. That is a good sign — it means the split is a real
   invariant of the problem, not an artefact of my framing.
5. **The Autonomous Dream** is a strong concept: an unobserved world that keeps becoming. It is
   the best idea in the document and it deserves to work.
6. **`bayer2x2` is correct** (0, 0.5, 0.75, 0.25), and using `@builtin(position)` in the fragment
   stage does give framebuffer coordinates, so the dither works despite the misleading
   `clip_position` name.

---

## Synthesis: the one change that fixes the most

You have two streams. **Promote Q to authority and demote Ψ to derived appearance.**

Right now `spatial_state_vectors` stores `latent_vector vector(128)` and
`probability_manifold JSONB` as *the world*. That is latent-as-truth, and it fails the same four
requirements measured earlier — authority, replay, attribution, debuggability. But the Q stream
already *is* discrete symbolic state: `collapsed_resolution_q`, `permanence`, normals, plus
`biome_id` and `cultural_lineage_id`.

So the change is small:

| | now | after |
|---|---|---|
| authoritative state | `latent_vector` + `probability_manifold` | `Q`, `permanence`, `biome_id`, `cultural_lineage_id`, scars |
| `latent_vector` / Ψ | truth | **derived appearance cache**, regenerable, disposable |
| replay | impossible (C8) | replay Q events + recompute Ψ |
| debuggability | inspect a 128-dim vector | inspect a discrete state |
| anti-cheat | unanswerable | intents validate against Q |
| client-side weights | client holds the world | client holds appearance only |

Concretely, this also resolves C3 and C13 for free:

- **C3:** if Q is authoritative, mode collapse in the archive is a *content* problem you can see
  and bound, not an invisible corruption of world state. And the bias normalisation fix becomes
  testable against a stable ground truth.
- **C13:** if Ψ is derived, the observation-boundary sink is a rendering artefact you can fix in
  the materializer, not a permanent hole in the world.
- **C8:** the dream becomes a function of (Q, elapsed ticks) that can be *recomputed* rather than
  replayed — which also gives you I4's analytic jump-ahead.

And it makes the physics metaphor stop doing damage. `d_latent_variances[cell_id] = 0.001f;
// Wave-function quenched to ground state` is a destructive mutation licensed by an analogy: real
measurement does not permanently destroy a system's future indeterminacy. The metaphor is
justifying a state transition with no recovery path, which is what produces the dead halo. With Ψ
derived, quenching is a *rendering decision* and re-potentiation is free.

---

## Suggested fix order

Cheapest-to-most-expensive, weighted by how much each unblocks:

1. **C2** — one line. Variance currently has zero effect on collapse.
2. **C1** — hoist the projection, index `semantic_signature[k]`. ~16× less inner work *and* it
   starts doing what it says.
3. **C5** — remove `ceil()`, accumulate scaled fractional cost. One line, restores 2000× of
   resolution.
4. **C4** — set capacity to a burst, not a full hour.
5. **C3(2)** — normalise the bias vector before softmax. Measured: p_max 1.000 → 0.162.
6. **I3** — `% (2π)` on entropy_pulse.
7. **I1** — make cultural friction redistributive. Measured: 74.4% at MAX → 0%.
8. **C13** — Neumann boundary at observed cells. Measured: 18.4% deficit → 0.
9. **C6** — CAS on the reject path, or pack (timestamp, tokens) into one atomic.
10. **C10/C11/C12** — `UNIQUE (j_hash)`, mandatory hash verification, single transaction.
11. **C7** — hash every mutable field, especially `probability_manifold`.
12. **C8/I4** — make the dream a pure function of (Q, Δt) with analytic jump-ahead.
13. **I5–I9** — shader correctness.
14. **Synthesis** — promote Q to authority. Do this before the storage layer hardens; retrofitting
    it after Sprint 1 ships means a migration.

Items 1–8 are each under an hour and all are measured improvements.

---

## Reproduce

```bash
cd nebula
node sprint_review.js     # 23 assertions, ~32 s — the numbers in this document
node test_core.js         # 44 assertions — kernel, composition, materializer, economics
node test_splatcache.js   # 39 assertions — distribution layer, bake frontier
```
