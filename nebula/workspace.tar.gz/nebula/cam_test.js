/* Camera math for viewer.html, extracted so it can be tested without a GPU.
   Column-major, matching WebGL's expectation for uniformMatrix4fv. */
const M4 = {
  perspective(out, fovYrad, aspect, near, far) {
    const f = 1 / Math.tan(fovYrad / 2);
    const nf = 1 / (near - far);
    out.fill(0);
    out[0] = f / aspect;
    out[5] = f;
    out[10] = (far + near) * nf;
    out[11] = -1;
    out[14] = 2 * far * near * nf;
    return out;
  },

  lookAt(out, eye, center, up) {
    let zx = eye[0] - center[0], zy = eye[1] - center[1], zz = eye[2] - center[2];
    let l = Math.hypot(zx, zy, zz);
    if (l === 0) { zx = 0; zy = 0; zz = 1; l = 1; }
    zx /= l; zy /= l; zz /= l;
    // x = normalize(cross(up, z))
    let xx = up[1] * zz - up[2] * zy;
    let xy = up[2] * zx - up[0] * zz;
    let xz = up[0] * zy - up[1] * zx;
    l = Math.hypot(xx, xy, xz);
    if (l === 0) { xx = 1; xy = 0; xz = 0; l = 1; }   // up parallel to view dir
    xx /= l; xy /= l; xz /= l;
    // y = cross(z, x)
    const yx = zy * xz - zz * xy;
    const yy = zz * xx - zx * xz;
    const yz = zx * xy - zy * xx;
    out[0] = xx; out[1] = yx; out[2] = zx; out[3] = 0;
    out[4] = xy; out[5] = yy; out[6] = zy; out[7] = 0;
    out[8] = xz; out[9] = yz; out[10] = zz; out[11] = 0;
    out[12] = -(xx * eye[0] + xy * eye[1] + xz * eye[2]);
    out[13] = -(yx * eye[0] + yy * eye[1] + yz * eye[2]);
    out[14] = -(zx * eye[0] + zy * eye[1] + zz * eye[2]);
    out[15] = 1;
    return out;
  },

  multiply(out, a, b) {          // out = a * b
    for (let c = 0; c < 4; c++) {
      for (let r = 0; r < 4; r++) {
        let s = 0;
        for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
        out[c * 4 + r] = s;
      }
    }
    return out;
  },

  /** Transform a point; returns [x,y,z,w] in clip space. */
  transformPoint(m, p) {
    return [
      m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12],
      m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13],
      m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14],
      m[3] * p[0] + m[7] * p[1] + m[11] * p[2] + m[15]
    ];
  },

  /** Orbit camera position from yaw/pitch/distance around a target. */
  orbitEye(target, yaw, pitch, dist) {
    const cp = Math.cos(pitch), sp = Math.sin(pitch);
    return [
      target[0] + dist * cp * Math.sin(yaw),
      target[1] + dist * sp,
      target[2] + dist * cp * Math.cos(yaw)
    ];
  }
};

/* ------------------------------------------------------------------ tests */
let P = 0, F = 0;
const ok = (n, c, d = '') => {
  if (c) { P++; console.log(`  \x1b[32mPASS\x1b[0m  ${n}${d ? '  \x1b[90m' + d + '\x1b[0m' : ''}`); }
  else { F++; console.log(`  \x1b[31mFAIL\x1b[0m  ${n}  ${d}`); }
};
const near = (a, b, e = 1e-5) => Math.abs(a - b) < e;

console.log('\x1b[1mCamera math\x1b[0m');

// 1. perspective: a point straight ahead at -z maps to NDC x=y=0
const proj = M4.perspective(new Float32Array(16), 48 * Math.PI / 180, 1.6, 0.1, 5000);
let c = M4.transformPoint(proj, [0, 0, -10]);
ok('perspective maps the optical axis to NDC x=y=0',
  near(c[0] / c[3], 0, 1e-5) && near(c[1] / c[3], 0, 1e-5), `ndc=${(c[0]/c[3]).toExponential(2)},${(c[1]/c[3]).toExponential(2)}`);
ok('perspective w = -z (standard GL convention)', near(c[3], 10, 1e-4), `w=${c[3].toFixed(4)}`);
ok('near plane maps to NDC z = -1', (() => {
  const p = M4.transformPoint(proj, [0, 0, -0.1]); return near(p[2] / p[3], -1, 1e-3);
})());
ok('far plane maps to NDC z = +1', (() => {
  const p = M4.transformPoint(proj, [0, 0, -5000]); return near(p[2] / p[3], 1, 1e-3);
})());

// 2. wider aspect must compress x, not y
const projWide = M4.perspective(new Float32Array(16), 48 * Math.PI / 180, 2.0, 0.1, 5000);
const a1 = M4.transformPoint(proj, [1, 1, -10]), a2 = M4.transformPoint(projWide, [1, 1, -10]);
ok('aspect ratio scales x only', near(a1[1] / a1[3], a2[1] / a2[3], 1e-5) && (a2[0] / a2[3]) < (a1[0] / a1[3]),
  `x ndc ${(a1[0]/a1[3]).toFixed(4)} -> ${(a2[0]/a2[3]).toFixed(4)}, y unchanged`);

// 3. lookAt: the target must land at NDC centre
const eye = M4.orbitEye([64, 5, 40], 0.6, 0.62, 150);
const view = M4.lookAt(new Float32Array(16), eye, [64, 5, 40], [0, 1, 0]);
const vp = M4.multiply(new Float32Array(16), proj, view);
const ct = M4.transformPoint(vp, [64, 5, 40]);
ok('lookAt puts the target at NDC x=y=0', near(ct[0] / ct[3], 0, 1e-4) && near(ct[1] / ct[3], 0, 1e-4),
  `ndc=${(ct[0]/ct[3]).toExponential(2)},${(ct[1]/ct[3]).toExponential(2)}`);
ok('the target is in front of the camera (w > 0)', ct[3] > 0, `w=${ct[3].toFixed(2)}`);

// 4. up vector must stay up: a point above the target has positive NDC y
const up = M4.transformPoint(vp, [64, 45, 40]);
ok('world +Y projects to screen +Y (not upside down)', up[1] / up[3] > 0, `ndc y=${(up[1]/up[3]).toFixed(4)}`);

// 5. view matrix is orthonormal (rotation) with unit determinant
const R = [[view[0],view[4],view[8]],[view[1],view[5],view[9]],[view[2],view[6],view[10]]];
const dot = (a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
ok('view rotation rows are orthonormal',
  near(dot(R[0],R[0]),1,1e-5) && near(dot(R[1],R[1]),1,1e-5) && near(dot(R[0],R[1]),0,1e-5),
  `|r0|=${Math.sqrt(dot(R[0],R[0])).toFixed(6)} r0.r1=${dot(R[0],R[1]).toExponential(2)}`);

// 6. orbit: pitch 0 keeps the eye level with the target; pitch >0 raises it
const e0 = M4.orbitEye([0,0,0], 0, 0, 100);
const e1 = M4.orbitEye([0,0,0], 0, Math.PI/4, 100);
ok('orbit at pitch 0 stays in the target plane', near(e0[1], 0, 1e-6), `y=${e0[1]}`);
ok('orbit raises the eye with pitch', e1[1] > 60, `y=${e1[1].toFixed(1)} at 45 deg`);
ok('orbit preserves distance', near(Math.hypot(...e1), 100, 1e-4), `r=${Math.hypot(...e1).toFixed(4)}`);

// 7. everything in the world must land inside the frustum at default camera
const target = [64, 5, 40], dist = 150;
const corners = [[0,0,0],[128,0,0],[0,0,80],[128,0,80],[64,12,40]];
let inside = 0;
for (const p of corners) {
  const q = M4.transformPoint(vp, p);
  const nx = q[0]/q[3], ny = q[1]/q[3], nz = q[2]/q[3];
  if (q[3] > 0 && nx >= -1.05 && nx <= 1.05 && ny >= -1.05 && ny <= 1.05 && nz >= -1.001 && nz <= 1) inside++;
}
ok('the whole chunk fits the default frustum', inside === corners.length, `${inside}/${corners.length} corners visible`);

// 8. degenerate cases must not produce NaN
const deg = M4.lookAt(new Float32Array(16), [0,10,0], [0,0,0], [0,1,0]); // up parallel to view
ok('lookAt with up parallel to the view direction does not produce NaN',
  Array.from(deg).every(Number.isFinite), 'falls back to a valid basis');

console.log(`\n\x1b[1m${P} passed, ${F} failed\x1b[0m`);

if (typeof module !== 'undefined') module.exports = M4;
// Only act as a test runner when executed directly; importing it (e.g. from the
// software renderer) must not terminate the importer.
if (require.main === module) process.exit(F ? 1 : 0);
