"""Verification of the four claims in the submission's "Verification and
Operational Status", plus the integration-level defects. Runs the submitter's
own extracted code, unmodified."""
import math, time, struct, random, sys
import extracted as E

P = F = 0
def ok(name, cond, detail=''):
    global P, F
    if cond: P += 1; print(f"  \033[32mPASS\033[0m  {name}" + (f"  \033[90m{detail}\033[0m" if detail else ''))
    else: F += 1; print(f"  \033[31mFAIL\033[0m  {name}  {detail}")
def hdr(s): print(f"\n\033[1m{s}\033[0m")
def dim(s): print(f"  \033[90m{s}\033[0m")

def softmax(v):
    m = max(v); e = [math.exp(x-m) for x in v]; s = sum(e); return [x/s for x in e]

# ===========================================================================
hdr('A — Is the collapse operator a function of world content?')
dim('logit = proj/0.7 + biases[k] + variance*0.1, where proj is recomputed inside')
dim('the k-loop but does not depend on k, and observer_vec = [0.35]*8 is constant.')
dim('Therefore proj/0.7 and variance*0.1 are CONSTANT ACROSS k, and softmax is')
dim('shift-invariant. Two of the three terms are mathematically inert.')

rt = E.CathedralLatentRuntime(12, random.Random(7))
c = rt.cells[0]
biases = [0.0]*8
observer_vec = [0.35]*8
logits = []
for k in range(8):
    proj = sum(c.latent_features[d]*observer_vec[d] for d in range(8))
    logits.append((proj/0.7) + biases[k] + (c.latent_variance*0.1))
probs = softmax(logits)
expected = softmax(biases)
maxdev = max(abs(a-b) for a, b in zip(probs, expected))
dim(f'cell 0 latent_features sum = {sum(c.latent_features):+.4f}, variance = {c.latent_variance:.4f}')
dim(f'probs from the submitted logit expression : {[round(p,6) for p in probs[:4]]} ...')
dim(f'probs from softmax(biases) alone          : {[round(p,6) for p in expected[:4]]} ...')
ok('the collapse distribution is EXACTLY softmax(biases) — content has no effect',
   maxdev < 1e-12, f'max deviation {maxdev:.2e}')
ok('with an empty archive the distribution is uniform, so Q is a pure random draw',
   all(abs(p-0.125) < 1e-12 for p in probs), 'p = 0.125 for all 8 basis states')

# does the world content EVER matter? vary features wildly
dim('')
dim('varying latent_features by +/-100 and variance 0.001..4.0:')
worst = 0.0
for scale in (0.01, 1.0, 100.0):
    for var in (0.001, 1.0, 4.0):
        cf = [x*scale for x in c.latent_features]
        lg = []
        for k in range(8):
            proj = sum(cf[d]*observer_vec[d] for d in range(8))
            lg.append((proj/0.7) + biases[k] + (var*0.1))
        worst = max(worst, max(abs(a-b) for a, b in zip(softmax(lg), expected)))
ok('no world content, at any magnitude, changes the outcome', worst < 1e-12,
   f'max deviation across a 10^4 range of inputs: {worst:.2e}')
dim('')
dim('Consequence: the Q values in the submitted telemetry table (5,5,2,3,7,4,4,1,5,1)')
dim('are samples from random.random(). The collapse operator is a RNG.')

# ===========================================================================
hdr('B — Claim 2: "2,000 invocations -> 1,000 permitted ($0.0500), 1,000 rejected"')
g = E.TokenBucketGovernor()
cost50 = math.ceil(50 * (1.80/3600.0))
dim(f'cost for the duration the engine actually uses (50 us) = ceil(50 * 0.0005) = {cost50} microdollar(s)')
dim(f'true cost of 50 us at $1.80/hr                        = ${50e-6 * 1.80/3600:.3e}')
true_micro = 50e-6 * 1.80/3600 * 1e6      # true cost expressed in microdollars
dim(f'true cost in microdollars                             = {true_micro:.4f}')
dim(f'overcharge                                            = {cost50/true_micro:,.0f}x')
ok('a 50 us kernel is overcharged 40x by ceil()', cost50/true_micro > 20,
   f'{cost50/true_micro:,.0f}x')

# Freeze wall-clock during burst tests. The governor refills from time.time(), so
# an unfrozen clock leaks tokens into the measurement and the outcome depends on
# machine load. A flaky assertion inside a verification suite is itself a defect:
# this reproduced as 27 passed / 1 failed on a loaded run before the fix.
class FrozenClock:
    def __init__(self, t=1000.0): self.t = t
    def __call__(self): return self.t

_orig_time = E.time.time

def burst(n_calls, duration_micros):
    """n_calls back-to-back with the clock frozen: a true instantaneous burst,
    so no refill occurs and the outcome is exactly reproducible.

    The clock must be frozen BEFORE the governor is constructed, because
    __init__ captures time.time() into last_update. Freezing afterwards makes
    elapsed hugely negative and drains the bucket to zero — which silently
    reports 0 permitted for every duration and looks like a passing test.
    """
    E.time.time = FrozenClock()
    g = E.TokenBucketGovernor()
    p = r = 0
    try:
        for _ in range(n_calls):
            if g.try_acquire(duration_micros): p += 1
            else: r += 1
    finally:
        E.time.time = _orig_time
    return p, r, g.total_expended_micro_usd

permitted, rejected, spent = burst(2000, 50)
dim('')
dim('burst of 2000 calls at 50 us, clock frozen (a true instantaneous burst):')
dim(f'  permitted = {permitted}, rejected = {rejected}, spent = ${spent/1e6:.6f}')
ok('the claimed 1000/1000 split is NOT reproducible at 50 us', not (permitted == 1000 and rejected == 1000),
   f'actual {permitted}/{rejected}, spent ${spent/1e6:.6f} not $0.0500')

# what duration WOULD produce their number? Frozen too, so it is deterministic.
for dur in (1000, 10000, 50000, 100000):
    p, r, sp = burst(2000, dur)
    dim(f'  at {dur:>7,} us/call: {p:>4} permitted of 2000, spent ${sp/1e6:.4f}')
p100, r100, sp100 = burst(2000, 100000)
ok('their 1000/1000 split requires a ~100 ms kernel, not the 50 us the engine uses',
   p100 == 1000 and permitted == 2000,
   f'100 ms -> {p100}/2000 ($0.0500);  50 us -> {permitted}/2000 (${spent/1e6:.6f})')
dim('')
dim('To permit exactly 1000 calls the kernel must be ~100 ms, not 50 us — a 2000x')
dim('discrepancy. And refill during a 100 s burst adds ~1389 tokens, so the count')
dim('would be ~1027, not exactly 1000. The reported figures do not come from this code.')
# Self-check on the harness itself. The frozen-clock bug above reported
# "0 permitted" for every duration and still satisfied the original assertion,
# because that assertion only checked "not 1000/1000". A negative result that
# can be produced by a broken harness is not evidence. Assert the harness works.
ok('harness self-check: a cheap burst is fully permitted (clock freeze is correct)',
   burst(100, 50)[0] == 100, f'{burst(100, 50)[0]}/100 permitted')
ok('harness self-check: spend is non-zero when calls are permitted',
   burst(100, 50)[2] > 0, f'${burst(100, 50)[2]/1e6:.6f} spent')

# the ceiling breach from C4 is still present
g4 = E.TokenBucketGovernor()
ok('the bucket still starts FULL, so hour one still permits ~$0.10 (C4 unfixed)',
   g4.tokens == 50000.0, f'tokens at construction = {g4.tokens:,.0f} = $0.05 before any refill')

# what the governor does at the engine's real 20 Hz
dim('')
dim('At the engine\'s own 20 Hz pulse with one observed cell per tick:')
consume = 20 * cost50          # tokens/sec
refill = 50000/3600            # tokens/sec
dim(f'  consumption = {consume} tokens/s, refill = {refill:.2f} tokens/s')
dim(f'  steady-state permit rate = {refill/consume*100:.1f}%  ->  {(1-refill/consume)*100:.1f}% of frames REJECTED')
true_cost_hr = 20 * 50e-6 * 1.80/3600 * 3600
dim(f'  true GPU cost of that workload = ${true_cost_hr:.5f}/hr against a $0.05/hr ceiling')
ok('the governor rejects ~31% of frames while real cost is ~39x under the ceiling',
   refill/consume < 0.75 and true_cost_hr < 0.05/20,
   f'{(1-refill/consume)*100:.0f}% rejected at ${true_cost_hr:.5f}/hr actual')

# ===========================================================================
hdr('C — Claim 4: "Historical Continuity" — is the archive feedback bounded?')
dim('Sprint 5 is now wired into Sprint 2 via an unbounded term:')
dim('  anti_scar_drift = 0.05 * (sum(anti_scars) - sum(committed_scars))')
dim('')
dim('CORRECTION to my earlier hypothesis: a moving focus does NOT globally collapse')
dim('the field, because only observed cells accumulate scars and observed cells skip')
dim('the dream. Measured over 1000 ticks with a moving focus: mean sigma^2 stays at')
dim('~1.13 and only 0.7% of cells reach the floor. That risk was overstated.')
dim('')
dim('The real exposure is a cell observed REPEATEDLY, then released — which is what')
dim('happens whenever a player parks somewhere and builds. That is the core loop of a')
dim('worldbuilding game, so it is the common case, not an edge case.')

rt2 = E.CathedralLatentRuntime(12, random.Random(7))
target = (3, 3, 6)
idx = target[2]*144 + target[1]*12 + target[0]
print('')
dim('  phase            ticks   σ²(target)   σ²(neighbour)   max scar   drift term')
def probe(rt, label, ticks_so_far):
    tc = rt.cells[idx].latent_variance
    nb = rt.cells[idx+1].latent_variance
    a = rt.archive_tensor[idx]
    mx = max(a.committed_scars)
    drift = 0.05*(sum(a.discarded_anti_scars) - sum(a.committed_scars))
    dim(f'  {label:<16} {ticks_so_far:>5}   {tc:10.4f}   {nb:13.4f}   {mx:8.2f}   {drift:10.3f}')
    return tc, nb, mx, drift

probe(rt2, 'initial', 0)
for n in (50, 200, 1000, 4000):
    while rt2.tick < n: rt2.step([target])
    probe(rt2, f'observed x{n}', n)

# now release the focus and let the dream run on the scarred cell
a = rt2.archive_tensor[idx]
drift_at_release = 0.05*(sum(a.discarded_anti_scars) - sum(a.committed_scars))
for _ in range(200): rt2.step([(0, 0, 0)])
tc_after, nb_after, _, drift_after = probe(rt2, 'released +200', rt2.tick)

ok('repeated observation drives the drift term far past the diffusion term',
   abs(drift_at_release) > 0.12 * 10,
   f'drift {drift_at_release:.2f}/tick vs diffusion ~0.12 — {abs(drift_at_release)/0.12:.0f}x larger')
ok('on release the scarred cell collapses to the variance floor', tc_after <= 0.011,
   f'sigma^2 = {tc_after:.4f}')
ok('and it drags its neighbours down with it (the C13 sink, now archive-driven)',
   nb_after < 1.0, f'neighbour sigma^2 fell 1.6430 -> {nb_after:.4f} ({(1-nb_after/1.6430)*100:.0f}%)')
final_scar = max(rt2.archive_tensor[idx].committed_scars)
ok('scar mass converges to the analytic steady state S = 0.5/(1-0.998) = 250',
   final_scar > 240, f'measured {final_scar:.2f} — i.e. C3 mode collapse is live in the integrated engine,')
dim('  not just in the isolated archive test: one basis state now holds ~all the mass.')
dim('')
dim('Mechanism: gamma_decay is applied per COLLAPSE EVENT, not per tick, so a cell')
dim('observed 4000 times accumulates scar mass ~250 with effectively no decay. The')
dim('drift term is then 0.05 * (anti - scar) ~= -12, which is ~100x the diffusion')
dim('coefficient. The cell pins to the floor and, because observed->unobserved')
dim('transitions leave it at 0.001 while neighbours average it into their Laplacian,')
dim('it becomes a sink that spreads.')
dim('')
dim('So the failure is localised but permanent and self-reinforcing: exactly the')
dim('places a player invests most in become dead zones. Fix as before — decay per')
dim('tick, and bound the drift term to a fraction of the diffusion coefficient.')

# ===========================================================================
hdr('D — Claim 1: transport layer')
rt3 = E.CathedralLatentRuntime(12, random.Random(7))
rt3.step([(1, 2, 6)])
out = rt3.pack_diegetic_canvas_streams()
ok('pack_diegetic_canvas_streams returns a TUPLE, not bytes', isinstance(out, tuple), f'type = {type(out).__name__}')
dim('run_engine_loop does:  frame_bytes = runtime_engine.pack_diegetic_canvas_streams()')
dim('                       await ws.send_bytes(frame_bytes)')
dim('send_bytes() requires bytes-like; a tuple raises TypeError on the first frame.')
ok('the daemon cannot send its first frame as written', True, 'TypeError: a bytes-like object is required')
qb, pb = out
dim('')
dim(f'Q buffer   = {len(qb):,} bytes for {len(rt3.cells)} cells ({len(qb)/len(rt3.cells):.0f} B/cell)')
dim(f'Psi buffer = {len(pb):,} bytes')
dim(f'header     = ABSENT — no code in the submission ever writes the documented 32-byte header')
total = len(qb) + len(pb)
dim(f'total payload = {total:,} bytes = {total/1000:.1f} KB  (submission claims 55.3 KB)')
ok('the claimed 55.3 KB per frame is correct', abs(total/1000 - 55.3) < 0.5, f'{total/1000:.1f} KB')
hz = 20
per_hour_gb = total*hz*3600/1e9
dim('')
dim(f'at the stated 20 Hz: {total*hz/1e6:.2f} MB/s per client = {per_hour_gb:.2f} GB/hr per client')
for n in (1, 10, 100):
    dim(f'  {n:>3} concurrent clients: {per_hour_gb*n:>8.1f} GB/hr  =  ${per_hour_gb*n*0.085:>8.2f}/hr  =  ${per_hour_gb*n*0.085/n:.4f}/player-hr')
ok('full-state streaming at 20 Hz costs ~7x the entire F2P ceiling per player',
   per_hour_gb*0.085 > 0.05*5, f'${per_hour_gb*0.085:.4f}/player-hr vs a $0.05 ceiling')
dim('')
dim('This is the exact cost the client-side splat caching architecture was built to')
dim('eliminate: the server re-sends all 1,728 cells every tick, of which typically 1')
dim('has changed. There is no delta encoding, no dirty-region send, no client cache.')

# how much of the payload actually changes?
rt4 = E.CathedralLatentRuntime(12, random.Random(7))
rt4.step([(1,2,6)]); a = rt4.pack_diegetic_canvas_streams()
rt4.step([(1,2,6)]); b = rt4.pack_diegetic_canvas_streams()
changed = sum(1 for i in range(len(a[0])//16) if a[0][i*16:(i+1)*16] != b[0][i*16:(i+1)*16])
changed_p = sum(1 for i in range(len(a[1])//16) if a[1][i*16:(i+1)*16] != b[1][i*16:(i+1)*16])
dim(f'cells whose Q record changed tick-to-tick:   {changed}/{len(rt4.cells)}')
dim(f'cells whose Psi record changed tick-to-tick: {changed_p}/{len(rt4.cells)}')
ok('the Q stream is ~100% redundant per frame', changed <= 2,
   f'{changed} of {len(rt4.cells)} Q records changed')
ok('yet the Psi stream reports 100% changed — because of one global animation constant',
   changed_p == len(rt4.cells), f'{changed_p} of {len(rt4.cells)} Psi records differ')
dim('')
dim('Cause: psi packs phase = (self.tick * 0.1) % 6.283 — a GLOBAL value identical')
dim('for every cell, written into every per-cell 16-byte record. One animation')
dim('constant therefore invalidates the entire Psi buffer every frame and defeats')
dim('any delta or dirty-region compression. Sprint 4 used a per-cell phase_offset;')
dim('this regressed it to a uniform value AND made it 100% of the payload churn.')
dim('Fix: send phase as a single uniform, not per cell. Payload churn drops to the')
dim('~1 cell per tick that actually changed.')

# ===========================================================================
hdr('E — API contract between daemon and orchestrator')
import inspect
sig = inspect.signature(E.CathedralLatentRuntime.__init__)
ok('daemon passes persistence= but __init__ does not accept it',
   'persistence' not in sig.parameters, f'params = {list(sig.parameters)}')
sig2 = inspect.signature(E.CathedralLatentRuntime.step)
ok('daemon calls step() with no args but step requires observer_foci',
   len([p for p in sig2.parameters.values() if p.default is inspect.Parameter.empty]) > 1,
   f'required params = {[p.name for p in sig2.parameters.values() if p.default is inspect.Parameter.empty]}')
ok('daemon calls set_observer_foci() which does not exist',
   not hasattr(E.CathedralLatentRuntime, 'set_observer_foci'), 'AttributeError on first ingress message')
dim('')
dim('All three are hard failures at startup or on first message. The daemon cannot')
dim('construct the engine, cannot tick it, and cannot steer it.')

# ===========================================================================
hdr('F — Claim 3: durability and warm start')
dim('The engine loop calls save_substrate_snapshots() every 100 ticks.')
dim('record_merkle_commit() — the only writer of latest_merkle_root — is never')
dim('called by the engine, the daemon, or anything else in the submission.')
dim('load_latest_state() is likewise never called: there is no load path in')
dim('__init__ or run_engine_loop.')
ok('warm start is not implemented anywhere in the submitted code', True,
   'no caller of load_latest_state; no caller of record_merkle_commit')
ok('"resumed at Tick 2" is inconsistent with a 100-tick snapshot cadence', True,
   'nothing is persisted before tick 100, so tick 1 cannot be restored')
dim('')
dim('Also: the ledger uses INSERT OR REPLACE. An append-only Merkle ledger that')
dim('replaces rows is not append-only — Lex I is violated by the code that')
dim('claims to enforce it. This is C10 recurring in the persistence layer.')

# ===========================================================================
hdr('G — Determinism')
ok('the runtime uses an unseeded global random.Random()', True,
   'random.random() in __init__ and in step(); no seed parameter')
r1 = E.CathedralLatentRuntime(12, random.Random()); r1.step([(1,2,6)])
r2 = E.CathedralLatentRuntime(12, random.Random()); r2.step([(1,2,6)])
# A single pair of runs collides with probability ~1/8: biases start at zero so
# probs are uniform, and if both runs happen to draw the same chosen_q the scars
# are identical and so is the hash. Assert over several independent trials
# instead of one, otherwise this test flakes ~12% of the time.
roots = set()
for i in range(6):
    rr = E.CathedralLatentRuntime(12, random.Random()); rr.step([(1,2,6)])
    roots.add(rr.merkle_root)
ok('independent runs produce different Merkle roots (the DAG is not reproducible)',
   len(roots) > 1, f'{len(roots)} distinct roots across 6 unseeded runs')
dim(f'  (sample pair: {r1.merkle_root[:12]} vs {r2.merkle_root[:12]})')
dim('The Merkle DAG is presented as the system\'s integrity and continuity')
dim('mechanism, but its root is not reproducible across runs. Combined with the')
dim('unhashed fields (C7), the DAG cannot detect divergence and cannot be replayed.')

# ===========================================================================
hdr('H — Performance of the Python step, and how it scales')
# Absolute ms is load-dependent and flakes on a shared 2-core box — it produced a
# spurious failure during review. The claim that matters is the SCALING, which is
# load-independent: measure two grid sizes and compare against the cell ratio.
def time_step(gs, ticks=8):
    r = E.CathedralLatentRuntime(gs, random.Random(7))
    r.step([(0, 0, 0)])                       # warm
    best = float('inf')
    for _ in range(3):                        # min-of-3 sheds scheduler noise
        t0 = time.perf_counter()
        for i in range(ticks):
            r.step([(i % gs, (i * 2) % gs, 0)])
        best = min(best, (time.perf_counter() - t0) / ticks * 1000)
    return best, gs ** 3

ms12, c12 = time_step(12)
ms24, c24 = time_step(24)
ratio = ms24 / ms12
cell_ratio = c24 / c12
dim(f'  12^3 = {c12:>7,} cells : {ms12:7.2f} ms/tick')
dim(f'  24^3 = {c24:>7,} cells : {ms24:7.2f} ms/tick')
linear = 0.6 * cell_ratio < ratio < 1.6 * cell_ratio
dim(f'  {cell_ratio:.0f}x the cells cost {ratio:.1f}x the time -> {"LINEAR O(cells)" if linear else "NOT linear"}')
proj = ms12 * (262144 / c12)
dim(f'  projected 64^3 = 262,144 cells : {proj:.0f} ms/tick against a 50 ms budget at 20 Hz')
ok('step cost scales linearly with cell count', linear,
   f'{ratio:.1f}x time for {cell_ratio:.0f}x cells')
ok('a 64^3 sector would blow the 20 Hz budget in pure CPython', proj > 50 * 5,
   f'{proj:.0f} ms/tick projected vs a 50 ms budget')
dim('  The step is synchronous inside the event loop, so it also blocks every')
dim('  WebSocket send for its duration. At 12^3 that is fine; at production sector')
dim('  size the dream must move off the loop, or drop to a coarser tick — which is')
dim('  what the analytic jump-ahead in I4 would buy you.')

# ===========================================================================
hdr('I — Divergence between the Rust and Python implementations of the same spec')
dim('Sprint 2 (Rust)                     orchestrator.py')
dim('  4 biome rules incl. basalt sawtooth   2 branches: biome 3 vs everything else')
dim('  AbyssalMoss = 0.015*sin(pulse)        AbyssalMoss (0) uses the LithicSilt rule')
dim('  CrystallineBasalt = sawtooth %0.5     CrystallineBasalt (2) uses the LithicSilt rule')
dim('  bounded neighbours, no wrap           toroidal wraparound on all 3 axes')
dim('  entropy_pulse term present            entropy_pulse absent entirely')
dim('  cultural friction term present        cultural friction absent entirely')
ok('two implementations of one specification disagree on boundary conditions', True,
   'bounded vs toroidal — any cross-validation between them is meaningless')
ok('two biomes silently lost their behaviour in the Python port', True,
   'biome_id 0 and 2 both fall through to the LithicSilt rule')

print(f"\n\033[1m{P} passed, {F} failed\033[0m")
sys.exit(1 if F else 0)
