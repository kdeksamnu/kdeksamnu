"""Faithful extraction of orchestrator.py from the submission, unmodified
except: (a) a seedable RNG injected so runs are comparable, (b) persistence
hooks stubbed. Control flow, constants and arithmetic are verbatim."""
import math, time, struct, hashlib, random
from dataclasses import dataclass, field
from typing import List, Dict, Tuple

@dataclass
class SpatialStateVector:
    cell_id: int
    coord: Tuple[int, int, int]
    observer_count: int
    ego_density: float
    latent_variance: float
    spectral_weights: List[float]
    latent_features: List[float]
    biome_id: int
    culture_id: int
    collapsed_q: int = 0
    permanence: float = 0.0

class TokenBucketGovernor:
    def __init__(self, hourly_gpu_rate_usd: float = 1.80, hourly_ceiling_usd: float = 0.05):
        self.hourly_gpu_rate_usd = hourly_gpu_rate_usd
        self.capacity_tokens = hourly_ceiling_usd * 1_000_000.0
        self.refill_rate = self.capacity_tokens / 3600.0
        self.tokens = self.capacity_tokens
        self.last_update = time.time()
        self.total_expended_micro_usd = 0.0

    def try_acquire(self, duration_micros: int) -> bool:
        now = time.time()
        elapsed = now - self.last_update
        self.last_update = now
        self.tokens = min(self.capacity_tokens, self.tokens + elapsed * self.refill_rate)
        cost = math.ceil(duration_micros * (self.hourly_gpu_rate_usd / 3600.0))
        if self.tokens >= cost:
            self.tokens -= cost
            self.total_expended_micro_usd += cost
            return True
        return False

@dataclass
class ArchiveTensorCell:
    cell_id: int
    committed_scars: List[float] = field(default_factory=lambda: [0.0] * 8)
    discarded_anti_scars: List[float] = field(default_factory=lambda: [0.0] * 8)
    total_collapses: int = 0
    jbp_hash: str = "0" * 64

    def record_collapse(self, chosen_q, uncollapsed_probs, ego_density, parent_hash) -> str:
        self.total_collapses += 1
        decay = 0.998
        scar_inc = (ego_density / 8.3) * 0.5
        self.committed_scars[chosen_q] = (self.committed_scars[chosen_q] * decay) + scar_inc
        for k in range(8):
            if k != chosen_q:
                p = uncollapsed_probs[k]
                if p > 0.05:
                    self.discarded_anti_scars[k] = (self.discarded_anti_scars[k] * decay) + (p * 0.35)
                else:
                    self.discarded_anti_scars[k] *= decay
        payload = f"{parent_hash}:{self.cell_id}:{self.total_collapses}:{self.committed_scars}:{self.discarded_anti_scars}".encode()
        self.jbp_hash = hashlib.sha256(payload).hexdigest()
        return self.jbp_hash

    def get_logit_biases(self):
        return [0.25 * self.committed_scars[k] - 0.35 * self.discarded_anti_scars[k] for k in range(8)]

class CathedralLatentRuntime:
    def __init__(self, grid_size: int = 12, rng=None):
        self.rng = rng or random.Random()
        self.grid_size = grid_size
        self.total_cells = grid_size ** 3
        self.governor = TokenBucketGovernor()
        self.archive_tensor: Dict[int, ArchiveTensorCell] = {}
        self.merkle_root: str = "0" * 64
        self.cells: List[SpatialStateVector] = []
        self.tick: int = 0
        for idx in range(self.total_cells):
            z = idx // (grid_size * grid_size)
            y = (idx // grid_size) % grid_size
            x = idx % grid_size
            self.cells.append(SpatialStateVector(
                cell_id=idx, coord=(x, y, z), observer_count=0, ego_density=8.3,
                latent_variance=0.5 + (self.rng.random() * 1.5),
                spectral_weights=[1.0 / 7.0] * 7,
                latent_features=[(self.rng.random() * 2.0 - 1.0) for _ in range(8)],
                biome_id=(idx % 4), culture_id=((idx // 7) % 4)))
            self.archive_tensor[idx] = ArchiveTensorCell(cell_id=idx)

    def step(self, observer_foci):
        self.tick += 1
        foci_set = set(observer_foci)
        for cell in self.cells:
            cell.observer_count = 1 if cell.coord in foci_set else 0
        gs = self.grid_size
        for cell in [c for c in self.cells if c.observer_count == 0]:
            x, y, z = cell.coord
            neighbors = [((x-1)%gs,y,z),((x+1)%gs,y,z),(x,(y-1)%gs,z),(x,(y+1)%gs,z),(x,y,(z-1)%gs),(x,y,(z+1)%gs)]
            neighbor_vars = [self.cells[nz*gs*gs + ny*gs + nx].latent_variance for nx,ny,nz in neighbors]
            laplacian = (sum(neighbor_vars)/6.0) - cell.latent_variance
            eco_delta = 0.03*(1.0-cell.latent_variance/4.0) if cell.biome_id == 3 else -0.02*(cell.latent_variance-0.75)
            archive_cell = self.archive_tensor[cell.cell_id]
            anti_scar_drift = 0.05*(sum(archive_cell.discarded_anti_scars) - sum(archive_cell.committed_scars))
            cell.latent_variance = max(0.01, min(4.0, cell.latent_variance + 0.12*laplacian + eco_delta + anti_scar_drift))
        for cell in [c for c in self.cells if c.observer_count > 0]:
            archive_cell = self.archive_tensor[cell.cell_id]
            biases = archive_cell.get_logit_biases()
            allowed = self.governor.try_acquire(duration_micros=50)
            observer_vec = [0.35]*8
            logits = []
            for k in range(8):
                proj = sum(cell.latent_features[d]*observer_vec[d] for d in range(8))
                logit = (proj/0.7) + biases[k] + (cell.latent_variance*0.1)
                logits.append(logit)
            max_l = max(logits)
            exps = [math.exp(l-max_l) for l in logits]
            probs = [e/sum(exps) for e in exps]
            r = self.rng.random(); cum = 0.0; chosen_q = 7
            for k in range(8):
                cum += probs[k]
                if r <= cum: chosen_q = k; break
            cell.collapsed_q = chosen_q
            cell.permanence = 1.0 if allowed else 0.5
            cell.latent_variance = 0.001
            self.merkle_root = archive_cell.record_collapse(chosen_q=chosen_q, uncollapsed_probs=probs,
                                                            ego_density=cell.ego_density, parent_hash=self.merkle_root)

    def pack_diegetic_canvas_streams(self):
        q_buffer = bytearray(); psi_buffer = bytearray()
        for cell in self.cells:
            q_buffer.extend(struct.pack("<Ifff", cell.collapsed_q, cell.permanence, 0.0, 1.0))
            entropy = math.log(8.0)*cell.latent_variance
            psi_buffer.extend(struct.pack("<fffI", cell.latent_variance, (self.tick*0.1)%6.283, entropy, cell.biome_id%7))
        return bytes(q_buffer), bytes(psi_buffer)
