/* Extracted radix sort from viewer.html — verified against a reference sort. */
function radixSort(order, depthKeys, n) {
  const keys = new Uint32Array(n);
  const B = new Int32Array(n);
  for (let i = 0; i < n; i++) keys[i] = (0xFFFFFFFF - depthKeys[i]) >>> 0;  // invert -> far first
  let src = order, dst = B;
  for (let pass = 0; pass < 4; pass++) {
    const shift = pass * 8;
    const hist = new Uint32Array(256);
    for (let i = 0; i < n; i++) hist[(keys[i] >>> shift) & 0xFF]++;
    let acc = 0;
    for (let i = 0; i < 256; i++) { const c = hist[i]; hist[i] = acc; acc += c; }
    // NOTE: the key must be looked up for the element currently at position i,
    // not for position i itself. After the first pass src is permuted, so
    // indexing keys[i] pairs each element with the wrong key and silently
    // produces a non-sorted result. It only "works" when all high bytes are
    // identical, which is why tiny-range inputs passed and real ones did not.
    for (let i = 0; i < n; i++) { const id = src[i]; const k = (keys[id] >>> shift) & 0xFF; dst[hist[k]++] = id; }
    const t = src; src = dst; dst = t;
  }
  if (src !== order) order.set(src);
  return order;
}
function floatToOrdered(f) {
  const u = new Float32Array([f]); const b = new Uint32Array(u.buffer)[0];
  return (b & 0x80000000) ? (~b >>> 0) : ((b | 0x80000000) >>> 0);
}
let P = 0, F = 0;
const ok = (n, c, d = '') => { if (c) { P++; console.log(`  \x1b[32mPASS\x1b[0m  ${n}${d ? '  \x1b[90m' + d + '\x1b[0m' : ''}`); } else { F++; console.log(`  \x1b[31mFAIL\x1b[0m  ${n}  ${d}`); } };

function trial(label, n, gen) {
  const depths = new Float32Array(n);
  for (let i = 0; i < n; i++) depths[i] = gen(i, n);
  const keys = new Uint32Array(n);
  for (let i = 0; i < n; i++) keys[i] = floatToOrdered(depths[i]);
  const order = new Int32Array(n); for (let i = 0; i < n; i++) order[i] = i;
  radixSort(order, keys, n);
  // reference: indices sorted by depth DESCENDING
  const ref = [...Array(n).keys()].sort((a, b) => depths[b] - depths[a]);
  let mono = true;
  for (let i = 1; i < n; i++) if (depths[order[i]] > depths[order[i - 1]] + 1e-6) mono = false;
  const sameSet = new Set(order).size === n;
  const matchesRef = ref.every((v, i) => Math.abs(depths[v] - depths[order[i]]) < 1e-6);
  ok(label, mono && sameSet && matchesRef,
    `monotonic=${mono} permutation=${sameSet} matchesRef=${matchesRef}`);
}

console.log('\x1b[1mRadix sort (back-to-front splat ordering)\x1b[0m');
trial('uniform random, 100k', 100000, (i, n) => Math.random() * 1e6);
trial('already sorted ascending', 50000, (i) => i * 3.5);
trial('already sorted descending', 50000, (i, n) => (n - i) * 3.5);
trial('all identical depths', 20000, () => 42.0);
trial('tiny range (float precision stress)', 50000, (i) => 100 + Math.random() * 1e-4);
trial('huge range', 50000, () => Math.random() * 1e9);
trial('near-zero depths', 20000, () => Math.random() * 1e-6);
trial('many duplicates', 60000, () => (Math.random() * 50) | 0);
trial('single element', 1, () => 7);

// the property that actually matters for rendering
const n = 30000;
const depths = new Float32Array(n);
for (let i = 0; i < n; i++) depths[i] = Math.random() * 500;
const keys = new Uint32Array(n);
for (let i = 0; i < n; i++) keys[i] = floatToOrdered(depths[i]);
const order = new Int32Array(n); for (let i = 0; i < n; i++) order[i] = i;
const t0 = performance.now();
for (let r = 0; r < 10; r++) radixSort(order, keys, n);
const ms = (performance.now() - t0) / 10;
console.log(`\n  \x1b[90m30k gaussians: ${ms.toFixed(2)} ms per sort (10 runs, 2 Xeon cores)\x1b[0m`);
ok('sort is fast enough to run every frame at 30k gaussians', ms < 8, `${ms.toFixed(2)} ms of a 16.7 ms budget`);
const t1 = performance.now();
const refArr = [...Array(n).keys()].sort((a, b) => depths[b] - depths[a]);
const msRef = performance.now() - t1;
console.log(`  \x1b[90mArray.sort comparator on the same data: ${msRef.toFixed(2)} ms  -> radix is ${(msRef / ms).toFixed(1)}x faster\x1b[0m`);
ok('radix beats a comparator sort', ms < msRef, `${ms.toFixed(2)} vs ${msRef.toFixed(2)} ms`);

console.log(`\n\x1b[1m${P} passed, ${F} failed\x1b[0m`);
process.exit(F ? 1 : 0);
