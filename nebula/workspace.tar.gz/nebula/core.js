/* ============================================================================
   PROJECT NEBULA — MLAOS Kernel (corrected architecture)
   ----------------------------------------------------------------------------
   Thesis under test:
     A deterministic SYMBOLIC kernel owns truth.
     A NEURAL materialization layer owns appearance.
     A HIERARCHICAL scheduler decides which one pays for a given decision.

   This file is dependency-free and runs identically in Node and the browser.
   It implements the five load-bearing claims of the corrected architecture:

     C1. Symbolic state as source of truth  -> idempotent, replayable, diffable
     C2. Composition, not vector averaging  -> coherent conflict resolution
     C3. Neural materializer as a CACHE     -> regenerable, never authoritative
     C4. Hierarchical inference             -> cheap micro, budgeted macro
     C5. Progressive refinement             -> latency hidden, not eliminated

   Plus the negative control: the naive "latent space as truth" design from the
   original roadmap, so the failure mode is visible rather than asserted.
   ============================================================================ */
(function (root) {
  'use strict';

  /* ==========================================================================
     0. Deterministic primitives
     ====================================================================== */

  // mulberry32 — tiny, fast, seedable. Determinism is a hard requirement:
  // any RNG here becomes part of the world's reproducibility contract.
  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // Spatially-coherent deterministic hash noise. Used as the neural
  // materializer's high-frequency conditioning input so detail is stable
  // across frames (no temporal shimmer) but varies per-location.
  function hash2(x, y, seed) {
    let h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(seed | 0, 2147483647);
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }

  function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function smooth(t) { return t * t * (3 - 2 * t); }

  function makeValueNoise(seed) {
    const rng = mulberry32(seed);
    const P = 512;
    const perm = new Uint8Array(P * 2);
    const p = new Uint8Array(P);
    for (let i = 0; i < P; i++) p[i] = i;
    for (let i = P - 1; i > 0; i--) {
      const j = (rng() * (i + 1)) | 0;
      const t = p[i]; p[i] = p[j]; p[j] = t;
    }
    for (let i = 0; i < P * 2; i++) perm[i] = p[i & (P - 1)];
    const grad = new Float32Array(P);
    for (let i = 0; i < P; i++) grad[i] = rng() * 2 - 1;

    return function (x, y) {
      const xi = Math.floor(x), yi = Math.floor(y);
      const xf = smooth(x - xi), yf = smooth(y - yi);
      const X = xi & (P - 1), Y = yi & (P - 1);
      const g00 = grad[perm[X + perm[Y]]];
      const g10 = grad[perm[X + 1 + perm[Y]]];
      const g01 = grad[perm[X + perm[Y + 1]]];
      const g11 = grad[perm[X + 1 + perm[Y + 1]]];
      const a = lerp(g00, g10, xf);
      const b = lerp(g01, g11, xf);
      return lerp(a, b, yf) * 0.5 + 0.5;
    };
  }

  function fbm(noise, x, y, octaves, lacunarity, gain) {
    let amp = 1, freq = 1, sum = 0, norm = 0;
    for (let o = 0; o < octaves; o++) {
      sum += amp * noise(x * freq, y * freq);
      norm += amp;
      amp *= gain; freq *= lacunarity;
    }
    return sum / norm;
  }

  // FNV-1a over a Float32Array — gives us a cheap world fingerprint for the
  // replay/idempotency proof.
  function stateHash(f32) {
    let h = 0x811c9dc5;
    for (let i = 0; i < f32.length; i++) {
      const b = (f32[i] * 1000) | 0; // quantize; float equality is fragile
      h ^= b & 0xff; h = Math.imul(h, 0x01000193);
      h ^= (b >>> 8) & 0xff; h = Math.imul(h, 0x01000193);
      h ^= (b >>> 16) & 0xff; h = Math.imul(h, 0x01000193);
    }
    return (h >>> 0).toString(16).padStart(8, '0');
  }

  /* ==========================================================================
     1. Tiny neural net — the materializer
     --------------------------------------------------------------------------
     Deliberately minimal: 2 hidden layers, ReLU, Adam. This is a stand-in for
     the real thing (a SIREN / tiny NeRF / splat decoder running in WGSL).
     What matters architecturally is its POSITION in the system: it consumes
     symbolic features and produces appearance. It never produces state.
     ====================================================================== */

  class MLP {
    /**
     * @param {number} leaky  slope for negative inputs. 0 = plain ReLU.
     *   Leaky is not a nicety here: with Adam's magnitude-normalized updates,
     *   a small tower chasing a noisy residual drives every pre-activation
     *   negative, gradients go exactly zero, and the tower becomes a constant
     *   function permanently. We watched the style tower die this way.
     */
    constructor(sizes, seed = 1, opts = {}) {
      this.sizes = sizes.slice();
      this.leaky = opts.leaky ?? 0;
      this.W = []; this.b = [];
      const rng = mulberry32(seed);
      for (let l = 0; l < sizes.length - 1; l++) {
        const nin = sizes[l], nout = sizes[l + 1];
        const std = Math.sqrt(2 / nin); // He init
        const w = new Float32Array(nin * nout);
        for (let i = 0; i < w.length; i++) w[i] = (rng() * 2 - 1) * std;
        this.W.push(w);
        this.b.push(new Float32Array(nout));
      }
      this.mW = this.W.map(w => new Float32Array(w.length));
      this.vW = this.W.map(w => new Float32Array(w.length));
      this.mb = this.b.map(b => new Float32Array(b.length));
      this.vb = this.b.map(b => new Float32Array(b.length));
      this.t = 0;
    }

    get paramCount() {
      let n = 0;
      for (const w of this.W) n += w.length;
      for (const b of this.b) n += b.length;
      return n;
    }

    // Forward pass. `out` is caller-supplied to avoid per-frame allocation —
    // at 60fps across thousands of cells, GC pressure is a real budget line.
    //
    // NB: the destination buffer must be resolved PER LAYER. An earlier version
    // hoisted `nxt = out` above the loop and let the hidden-layer branch
    // reassign it, which meant the output layer wrote into the scratch buffer
    // and the caller's array stayed zeroed. Classic aliasing bug; it silently
    // degrades to "network predicts the mean" rather than crashing.
    forward(input, out) {
      const L = this.W.length;
      const scratch = this._scratch || (this._scratch = []);
      let cur = input;
      for (let l = 0; l < L; l++) {
        const nin = this.sizes[l], nout = this.sizes[l + 1];
        const W = this.W[l], b = this.b[l];
        const isLast = (l === L - 1);
        let dst;
        if (isLast) {
          dst = out;                       // linear output, into caller buffer
        } else {
          let buf = scratch[l];
          if (!buf || buf.length < nout) { buf = new Float32Array(nout); scratch[l] = buf; }
          dst = buf;
        }
        for (let j = 0; j < nout; j++) {
          let s = b[j];
          for (let i = 0; i < nin; i++) s += cur[i] * W[i * nout + j];
          dst[j] = (isLast || s >= 0) ? s : s * this.leaky;   // activation on hidden only
        }
        cur = dst;
      }
      return cur;
    }

    step(xs, ys, lr = 0.01) {
      // Plain SGD + Adam moments. Backprop written out explicitly: this net is
      // small enough that clarity beats generality.
      const L = this.W.length;
      const acts = [xs];
      let cur = xs;
      for (let l = 0; l < L; l++) {
        const nin = this.sizes[l], nout = this.sizes[l + 1];
        const W = this.W[l], b = this.b[l];
        const z = new Float32Array(nout), a = new Float32Array(nout);
        for (let j = 0; j < nout; j++) {
          let s = b[j];
          for (let i = 0; i < nin; i++) s += cur[i] * W[i * nout + j];
          z[j] = s;
          a[j] = (l === L - 1) ? s : (s > 0 ? s : s * this.leaky);
        }
        acts.push(a);
        cur = a;
      }
      // output delta (MSE, linear output)
      const nOut = this.sizes[L];
      let delta = new Float32Array(nOut);
      let loss = 0;
      for (let j = 0; j < nOut; j++) {
        const e = cur[j] - ys[j];
        loss += e * e;
        delta[j] = e;
      }
      loss /= nOut;

      const b1 = 0.9, b2 = 0.999, eps = 1e-8;
      this.t++;
      const c1 = 1 - Math.pow(b1, this.t), c2 = 1 - Math.pow(b2, this.t);

      for (let l = L - 1; l >= 0; l--) {
        const nin = this.sizes[l], nout = this.sizes[l + 1];
        const W = this.W[l], b = this.b[l];
        const aPrev = acts[l];
        const mW = this.mW[l], vW = this.vW[l], mb = this.mb[l], vb = this.vb[l];
        const nextDelta = new Float32Array(nin);
        for (let j = 0; j < nout; j++) {
          const d = delta[j];
          // bias
          mb[j] = b1 * mb[j] + (1 - b1) * d;
          vb[j] = b2 * vb[j] + (1 - b2) * d * d;
          b[j] -= lr * (mb[j] / c1) / (Math.sqrt(vb[j] / c2) + eps);
          for (let i = 0; i < nin; i++) {
            const idx = i * nout + j;
            const g = d * aPrev[i];
            mW[idx] = b1 * mW[idx] + (1 - b1) * g;
            vW[idx] = b2 * vW[idx] + (1 - b2) * g * g;
            W[idx] -= lr * (mW[idx] / c1) / (Math.sqrt(vW[idx] / c2) + eps);
            nextDelta[i] += d * W[idx];
          }
        }
        if (l > 0) {
          // ReLU derivative on pre-activation of layer l-1's output (acts[l])
          const lk = this.leaky;
          for (let i = 0; i < nin; i++) nextDelta[i] *= acts[l][i] > 0 ? 1 : lk;
          delta = nextDelta;
        }
      }
      return loss;
    }
  }

  /* ==========================================================================
     2. Symbolic world state — the source of truth
     --------------------------------------------------------------------------
     Structured channels on a grid. Every mutation is an INTENT applied by a
     pure, idempotent function. This is the layer that answers "what is true",
     "who did it", "can we rewind", and "did two clients converge".
     ====================================================================== */

  const CH = { ELEV: 0, MOIST: 1, ROCK: 2, VEG: 3, STRUCT: 4, WATER: 5, N: 6 };
  const CH_NAMES = ['elev', 'moist', 'rock', 'veg', 'struct', 'water'];

  class World {
    constructor(w, h, seed = 1337) {
      this.w = w; this.h = h; this.seed = seed;
      this.ch = [];
      for (let i = 0; i < CH.N; i++) this.ch.push(new Float32Array(w * h));
      this.events = [];       // append-only intent log (event sourcing)
      this.applied = new Set(); // event ids — enforces idempotency
      this.settlements = [];
      this.nextEventId = 1;
      this.macroTick = 0;
      this.microTick = 0;
      this.massClip = 0;   // mass lost to range clipping — makes the budget auditable
      this.authoredMass = 0; // mass added/removed by player & agent intents
      this.initialMass = 0;  // set after generation
      this._gen(seed);
      this.initialMass = this.elevMass();
    }

    idx(x, y) { return y * this.w + x; }
    inBounds(x, y) { return x >= 0 && y >= 0 && x < this.w && y < this.h; }

    /** Mass the simulation alone is responsible for. Should stay ~0 forever. */
    simDrift() {
      const expected = this.initialMass + this.authoredMass;
      return expected === 0 ? 0 : Math.abs(this.elevMass() - expected) / Math.abs(expected);
    }

    _gen(seed) {
      const n1 = makeValueNoise(seed);
      const n2 = makeValueNoise(seed ^ 0x9e37);
      const n3 = makeValueNoise(seed ^ 0x5bf0);
      const { w, h } = this;
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const i = this.idx(x, y);
          const nx = x / w, ny = y / h;
          // island falloff so the world reads as a landmass
          const dx = (nx - 0.5) * 2, dy = (ny - 0.5) * 2;
          const d = Math.sqrt(dx * dx + dy * dy);
          const falloff = clamp(1 - Math.pow(d * 1.15, 3), 0, 1);

          let e = fbm(n1, nx * 5, ny * 5, 5, 2.0, 0.5);
          e = Math.pow(e, 1.4) * falloff;
          // a mountain ridge
          const ridge = Math.exp(-Math.pow((ny - 0.35 - 0.08 * Math.sin(nx * 6)) * 7, 2));
          e = clamp(e * 0.72 + ridge * 0.42 * falloff, 0, 1);
          this.ch[CH.ELEV][i] = e;

          const m = fbm(n2, nx * 3.5 + 11, ny * 3.5 + 7, 4, 2.0, 0.5);
          this.ch[CH.MOIST][i] = clamp(m * 0.7 + (1 - e) * 0.35, 0, 1);
          this.ch[CH.ROCK][i] = clamp(Math.pow(e, 2.2) * 1.2, 0, 1);
          this.ch[CH.WATER][i] = e < 0.30 ? clamp((0.30 - e) / 0.30, 0, 1) : 0;

          const v = fbm(n3, nx * 7 + 3, ny * 7 + 5, 3, 2.0, 0.5);
          const habitable = e > 0.32 && e < 0.78;
          this.ch[CH.VEG][i] = habitable ? clamp(v * this.ch[CH.MOIST][i] * 1.7, 0, 1) : 0;
          this.ch[CH.STRUCT][i] = 0;
        }
      }
    }

    // ---------------------------------------------------------------- intents

    /**
     * Apply an intent. Idempotent by event id, order-tolerant for spatially
     * disjoint brushes, and composable for overlapping ones.
     *
     * This is the function that replaces "consensus via vector averaging".
     * Composition is defined PER CHANNEL SEMANTIC, not per geometry:
     *   - terrain   : additive, then clamped        (mountain + valley = pass)
     *   - water     : max / carve                     (river cuts through ridge)
     *   - veg       : multiplicative survival         (fire * forest = clearing)
     *   - struct    : max with footprint exclusion    (no two buildings overlap)
     */
    apply(intent) {
      if (this.applied.has(intent.id)) return { duplicate: true };
      this.applied.add(intent.id);
      this.events.push(intent);
      const m0 = this.elevMass();
      const dirty = OPS[intent.op](this, intent);
      // Authored mass change is intentional; simulation mass change is not.
      // Tracking them separately is what lets the drift readout mean anything.
      this.authoredMass += this.elevMass() - m0;
      return { duplicate: false, dirty };
    }

    makeIntent(op, params) {
      return {
        id: this.nextEventId++, op, params,
        t: this.macroTick,
        // The micro tick at which this intent was authored. Replay MUST
        // interleave simulation and edits in this order: applying every event
        // first and then fast-forwarding the sim produces a DIFFERENT world,
        // because erosion/vegetation are state-dependent. Getting this wrong
        // is exactly how rollback netcode silently desyncs.
        mt: this.microTick,
        actor: params.actor || 'player'
      };
    }

    /**
     * Deterministic replay from the event log — the "save state" story, and
     * also rollback, reconciliation, and time-dilation fast-forward (§4.3).
     *
     * @param {number} microTicks  run the simulation forward to this tick,
     *   interleaving events at the tick each was authored at. Defaults to the
     *   highest tick referenced by the log, which makes replay a pure function
     *   of the log alone.
     */
    static replay(events, w, h, seed, microTicks = null) {
      const world = new World(w, h, seed);
      // Sort by id: replay order is canonical, NOT arrival order. This is what
      // makes the system order-tolerant across a network.
      const sorted = events.slice().sort((a, b) => a.id - b.id);
      const target = microTicks === null
        ? sorted.reduce((m, e) => Math.max(m, e.mt || 0), 0)
        : microTicks;
      for (const e of sorted) {
        const at = e.mt || 0;
        while (world.microTick < Math.min(at, target)) world.microStep(1);
        world.apply(e);
      }
      while (world.microTick < target) world.microStep(1);
      return world;
    }

    fingerprint() {
      let h = 0x811c9dc5;
      for (let c = 0; c < CH.N; c++) h = (h ^ (hash32(stateHash(this.ch[c])))) >>> 0;
      return h.toString(16).padStart(8, '0');
    }

    // ------------------------------------------------------------- simulation

    /**
     * MICRO tier — every frame. Cheap, deterministic, and STRICTLY MASS
     * CONSERVING (modulo range clipping, which is accounted for).
     *
     * This is symbolic physics. Neural nets are deliberately not allowed here:
     * learned simulators do not conserve momentum/energy and their error
     * compounds over rollout, so a world meant to persist for simulated
     * centuries would slowly unstick and float apart. Guarding that with
     * another probabilistic model is worse — two networks arguing, neither with
     * ground truth. The guardrail here is arithmetic, and it cannot lie.
     *
     * Scheme: pairwise flux exchange over each undirected edge exactly once.
     * Every unit removed from a cell is added to its neighbour. Flux is clamped
     * to half the head difference so the gradient can never invert (no
     * oscillation / checkerboarding).
     */
    microStep(dt) {
      this.microTick++;
      const { w, h } = this;
      const elev = this.ch[CH.ELEV], water = this.ch[CH.WATER];
      const K = clamp(0.22 * dt, 0, 0.45);   // transport rate, CFL-limited

      const exchange = (a, b) => {
        const ha = elev[a] + water[a] * 0.5;
        const hb = elev[b] + water[b] * 0.5;
        const dh = ha - hb;
        if (dh === 0) return;
        const hi = dh > 0 ? a : b, lo = dh > 0 ? b : a;
        const d = Math.abs(dh);
        if (d < 0.0015) return;              // angle of repose threshold

        // sediment flux: only from exposed terrain, never from open water
        const availSed = Math.max(0, elev[hi] - 0.02);
        const sedFlux = Math.min(d * K * 0.5, availSed * 0.5, d * 0.25);
        if (sedFlux > 0) {
          elev[hi] -= sedFlux;
          elev[lo] += sedFlux;
          // range clipping is the ONLY non-conservative step; account for it
          if (elev[lo] > 1) { this.massClip += elev[lo] - 1; elev[lo] = 1; }
          if (elev[hi] < 0) { this.massClip += -elev[hi]; elev[hi] = 0; }
          // transported sediment scours the bed slightly -> more rock exposed
          this.ch[CH.ROCK][hi] = clamp(this.ch[CH.ROCK][hi] + sedFlux * 0.05, 0, 1);
        }

        // water flux: spreads downhill, strictly conservative
        const availW = water[hi];
        const wFlux = Math.min(d * K * 0.9, availW * 0.5, d * 0.25);
        if (wFlux > 0) { water[hi] -= wFlux; water[lo] += wFlux; }
      };

      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const i = this.idx(x, y);
          if (x + 1 < w) exchange(i, i + 1);   // each undirected edge once
          if (y + 1 < h) exchange(i, i + w);
        }
      }

      // vegetation dynamics: logistic growth gated by moisture/elevation/rock.
      // Does not touch elevation, so it cannot break the mass budget.
      const veg = this.ch[CH.VEG], moist = this.ch[CH.MOIST], rock = this.ch[CH.ROCK];
      const g = 0.030 * dt, die = 0.020 * dt;
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const i = this.idx(x, y);
          const e = elev[i];
          const habitable = e > 0.31 && e < 0.80 && water[i] < 0.4;
          if (!habitable) { veg[i] = clamp(veg[i] * (1 - die), 0, 1); continue; }
          const carry = clamp(moist[i] * 1.35 * (1 - rock[i] * 0.65), 0, 1);
          if (carry <= 0.001) { veg[i] = clamp(veg[i] * (1 - die), 0, 1); continue; }
          veg[i] = clamp(veg[i] + g * veg[i] * (1 - veg[i] / carry) + (veg[i] < 0.02 ? g * 0.06 * carry : 0), 0, 1);
        }
      }
    }

    /** Total elevation mass — used to prove conservation over long rollouts. */
    elevMass() {
      let s = 0;
      const a = this.ch[CH.ELEV];
      for (let i = 0; i < a.length; i++) s += a[i];
      return s;
    }

    /**
     * MACRO tier — infrequent, budgeted. This is where expensive model calls
     * are allowed. In production this is the LLM / policy network; here it is
     * a utility function so the demo stays deterministic and free.
     */
    macroStep(agents) {
      this.macroTick++;
      const out = [];
      for (const a of agents) out.push(...a.decide(this));
      return out;
    }
  }

  function hash32(str) {
    let h = 0x811c9dc5;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return h >>> 0;
  }

  /* ==========================================================================
     3. Intent operators — the composition algebra
     ====================================================================== */

  function brushMask(world, cx, cy, r, falloff = 2) {
    const pts = [];
    const ri = Math.ceil(r);
    for (let y = cy - ri; y <= cy + ri; y++) {
      for (let x = cx - ri; x <= cx + ri; x++) {
        if (!world.inBounds(x, y)) continue;
        const d = Math.hypot(x - cx, y - cy) / r;
        if (d > 1) continue;
        pts.push({ i: world.idx(x, y), x, y, w: Math.pow(1 - d, falloff) });
      }
    }
    return pts;
  }

  function dirtyRect(world, mask, pad = 2) {
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (const p of mask) {
      if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x;
      if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y;
    }
    if (x1 < 0) return null;
    return {
      x0: Math.max(0, x0 - pad), y0: Math.max(0, y0 - pad),
      x1: Math.min(world.w - 1, x1 + pad), y1: Math.min(world.h - 1, y1 + pad)
    };
  }

  const OPS = {
    raise(world, it) {
      const { x, y, r, amount } = it.params;
      const mask = brushMask(world, x, y, r);
      for (const p of mask) {
        const e = world.ch[CH.ELEV][p.i];
        // additive then clamped: composition of two raises is a taller peak
        world.ch[CH.ELEV][p.i] = clamp(e + amount * p.w * (1 - e * 0.45), 0, 1);
        world.ch[CH.ROCK][p.i] = clamp(world.ch[CH.ROCK][p.i] + amount * p.w * 0.5, 0, 1);
      }
      return dirtyRect(world, mask);
    },

    lower(world, it) {
      const { x, y, r, amount } = it.params;
      const mask = brushMask(world, x, y, r);
      for (const p of mask) {
        world.ch[CH.ELEV][p.i] = clamp(world.ch[CH.ELEV][p.i] - amount * p.w, 0, 1);
        world.ch[CH.ROCK][p.i] = clamp(world.ch[CH.ROCK][p.i] - amount * p.w * 0.3, 0, 1);
      }
      return dirtyRect(world, mask);
    },

    /**
     * Carve a river. Note the composition rule: water uses `max` and elev uses
     * `min` against the bed profile. A river through a mountain therefore
     * yields a CANYON — the exact outcome the original roadmap wanted from
     * vector averaging, achieved deterministically and reproducibly.
     */
    carve(world, it) {
      const { x, y, r, depth, dir } = it.params;
      const mask = brushMask(world, x, y, r);
      const ang = (dir || 0) * Math.PI;
      for (const p of mask) {
        const along = (p.x - x) * Math.cos(ang) + (p.y - y) * Math.sin(ang);
        const bed = clamp(depth * p.w * (1 - Math.abs(along) / (r * 1.6)), 0, 1);
        world.ch[CH.ELEV][p.i] = Math.min(world.ch[CH.ELEV][p.i], Math.max(0.02, world.ch[CH.ELEV][p.i] - bed));
        world.ch[CH.WATER][p.i] = Math.max(world.ch[CH.WATER][p.i], bed > 0.05 ? clamp(bed * 2.2, 0, 1) : 0);
        world.ch[CH.VEG][p.i] *= (1 - bed * 0.8);
        world.ch[CH.MOIST][p.i] = clamp(world.ch[CH.MOIST][p.i] + bed * 0.5, 0, 1);
      }
      return dirtyRect(world, mask, 3);
    },

    /** Vegetation: multiplicative survival. Deforestation near water leaves a
     *  riparian buffer automatically because moisture raises regrowth carry. */
    deforest(world, it) {
      const { x, y, r, amount } = it.params;
      const mask = brushMask(world, x, y, r);
      let removed = 0;
      for (const p of mask) {
        const before = world.ch[CH.VEG][p.i];
        // riparian protection is a SYMBOLIC constraint, not a guardrail net
        const riparian = world.ch[CH.WATER][p.i] > 0.25 ? 0.35 : 1.0;
        world.ch[CH.VEG][p.i] = before * (1 - amount * p.w * riparian);
        removed += (before - world.ch[CH.VEG][p.i]);
      }
      it._removedVeg = removed;
      return dirtyRect(world, mask);
    },

    afforest(world, it) {
      const { x, y, r, amount } = it.params;
      const mask = brushMask(world, x, y, r);
      for (const p of mask) {
        const e = world.ch[CH.ELEV][p.i];
        if (e < 0.31 || e > 0.80 || world.ch[CH.WATER][p.i] > 0.4) continue;
        world.ch[CH.VEG][p.i] = clamp(world.ch[CH.VEG][p.i] + amount * p.w, 0, 1);
      }
      return dirtyRect(world, mask);
    },

    /** Structures: max-composition with footprint exclusion. Two builders in
     *  the same cell resolve by claim order (deterministic), not by blending. */
    build(world, it) {
      const { x, y, r, kind, actor } = it.params;
      const mask = brushMask(world, x, y, Math.max(1.5, r));
      for (const p of mask) {
        if (world.ch[CH.WATER][p.i] > 0.35) continue;
        world.ch[CH.STRUCT][p.i] = Math.max(world.ch[CH.STRUCT][p.i], clamp(0.55 + p.w * 0.45, 0, 1));
        world.ch[CH.VEG][p.i] *= (1 - 0.9 * p.w);
        world.ch[CH.ELEV][p.i] = clamp(world.ch[CH.ELEV][p.i] * (1 - 0.05 * p.w) + 0.02, 0, 1);
      }
      if (kind === 'settlement') {
        world.settlements.push({ x, y, r, owner: actor || 'player', born: world.macroTick, id: it.id });
      }
      return dirtyRect(world, mask);
    },

    /** The negotiation resolver's write primitive: restore a compromise state. */
    resolve(world, it) {
      const { ops } = it.params;
      let dirty = null;
      for (const sub of ops) {
        const d = OPS[sub.op](world, { params: sub.params, id: it.id + ':' + sub.op });
        if (d) dirty = dirty ? unionRect(dirty, d) : d;
      }
      return dirty;
    }
  };

  function unionRect(a, b) {
    return {
      x0: Math.min(a.x0, b.x0), y0: Math.min(a.y0, b.y0),
      x1: Math.max(a.x1, b.x1), y1: Math.max(a.y1, b.y1)
    };
  }

  /* ==========================================================================
     4. The negative control — "latent space as truth"
     --------------------------------------------------------------------------
     This is the original roadmap's §4.2 implemented faithfully, so its failure
     is demonstrated rather than asserted.

     Each intent maps to a fixed embedding. Overlap regions are resolved by
     averaging embeddings. A linear decoder projects embeddings back to world
     features. Watch what happens to (a) semantic coherence and (b) idempotency
     under event re-delivery.
     ====================================================================== */

  const EMBED_DIM = 24;

  // A crude but honest stand-in for "an encoder learned from data".
  // Each op gets a distinct direction in latent space.
  const OP_EMBED = {
    raise:    { elev: 1.0, rock: 0.8, water: -0.3, veg: -0.4 },
    lower:    { elev: -1.0, rock: -0.3, water: 0.5, veg: 0.2 },
    carve:    { elev: -0.6, rock: -0.2, water: 1.0, veg: -0.5 },
    deforest: { elev: 0.0, rock: 0.2, water: -0.2, veg: -1.0 },
    afforest: { elev: 0.0, rock: -0.3, water: 0.3, veg: 1.0 },
    build:    { elev: 0.2, rock: 0.6, water: -0.6, veg: -0.8, struct: 1.0 }
  };

  function embedIntent(intent) {
    const v = new Float32Array(EMBED_DIM);
    const src = OP_EMBED[intent.op] || {};
    const keys = ['elev', 'moist', 'rock', 'veg', 'struct', 'water'];
    const rng = mulberry32(hash32(intent.op) ^ 0x5eed);
    for (let d = 0; d < EMBED_DIM; d++) {
      let s = 0;
      for (let k = 0; k < keys.length; k++) s += (src[keys[k]] || 0) * basisFn(k, d);
      // every embedding also carries a little idiosyncratic noise, exactly as
      // real learned embeddings do. This is what makes averaging catastrophic.
      v[d] = s + (rng() - 0.5) * 0.55;
    }
    const n = Math.hypot(...v) || 1;
    for (let d = 0; d < EMBED_DIM; d++) v[d] /= n;
    return v;
  }

  function basisFn(k, d) {
    // fixed pseudo-random projection basis
    return Math.sin((k + 1) * 12.9898 + (d + 1) * 78.233) * 0.5;
  }

  class LatentWorld {
    /**
     * @param {boolean} average  true  = naive running-mean averaging (the
     *                            original roadmap §4.2, verbatim)
     *                            false = anchored accumulation (its mitigation)
     */
    constructor(w, h, seed = 1337, average = true) {
      this.w = w; this.h = h; this.average = average; this.seed = seed;
      this.latent = [];
      for (let d = 0; d < EMBED_DIM; d++) this.latent.push(new Float32Array(w * h));
      this.count = new Float32Array(w * h);   // intents touching a cell
      this.ch = [];
      for (let c = 0; c < CH.N; c++) this.ch.push(new Float32Array(w * h));
      this.decoder = null;
      this.events = [];
      this.applied = new Set();
      this.nextEventId = 1;
      this.reDeliveryDrift = 0;
      this.projection = null;
    }

    idx(x, y) { return y * this.w + x; }
    inBounds(x, y) { return x >= 0 && y >= 0 && x < this.w && y < this.h; }

    /**
     * Encode a symbolic world into latent space. This is the honest baseline:
     * the original design assumes the world already IS vectors, so we must give
     * it the same starting world or the comparison is rigged.
     */
    seedFrom(world) {
      const rng = mulberry32(this.seed ^ 0xbeef);
      this.projection = new Float32Array(EMBED_DIM * CH.N);
      for (let d = 0; d < EMBED_DIM; d++) {
        for (let c = 0; c < CH.N; c++) {
          this.projection[d * CH.N + c] = (rng() * 2 - 1);
        }
      }
      const f = new Float32Array(MAT_IN);
      for (let y = 0; y < this.h; y++) {
        for (let x = 0; x < this.w; x++) {
          const i = this.idx(x, y);
          featuresAt(world, x, y, f);
          for (let d = 0; d < EMBED_DIM; d++) {
            let s = 0;
            for (let c = 0; c < CH.N; c++) s += this.projection[d * CH.N + c] * f[c];
            this.latent[d][i] = s;
          }
          this.count[i] = 1;
        }
      }
      // snapshot the pristine encoding so intent deltas are relative to it
      this.base = this.latent.map(a => a.slice());
      return this;
    }

    apply(intent) {
      const id = intent.id;
      const dup = this.applied.has(id);
      this.applied.add(id);
      this.events.push(intent);
      const v = embedIntent(intent);
      const fake = {
        w: this.w, h: this.h,
        inBounds: (x, y) => this.inBounds(x, y),
        idx: (x, y) => this.idx(x, y)
      };
      const mask = brushMask(fake, intent.params.x, intent.params.y, intent.params.r || 3);
      const strength = 2.6; // intent salience relative to the base terrain encoding

      for (const p of mask) {
        if (this.average) {
          // Running mean — THE bug. Two consequences, both fatal:
          //  (1) non-idempotent: re-delivering an event moves the mean again,
          //      so at-least-once brokers permanently desync clients;
          //  (2) wherever intents overlap the mean lands between semantic
          //      clusters, i.e. off-manifold, which decodes to mush.
          const n = this.count[p.i];
          for (let d = 0; d < EMBED_DIM; d++) {
            this.latent[d][p.i] = (this.latent[d][p.i] * n + v[d] * strength * p.w) / (n + p.w);
          }
          this.count[p.i] = n + p.w;
        } else {
          // Anchored accumulation: intents add, they do not dilute.
          for (let d = 0; d < EMBED_DIM; d++) this.latent[d][p.i] += v[d] * strength * p.w;
        }
        if (dup) this.reDeliveryDrift += 1;
      }
      return dirtyRect(this, mask);
    }

    /** Fit a linear decoder latent->features against ground truth. */
    fitDecoder(symbolicWorld, samples = 4000, seed = 7) {
      const rng = mulberry32(seed);
      const X = [], Y = [];
      for (let s = 0; s < samples; s++) {
        const i = (rng() * this.w * this.h) | 0;
        const x = new Float32Array(EMBED_DIM + 1);
        for (let d = 0; d < EMBED_DIM; d++) x[d] = this.latent[d][i];
        x[EMBED_DIM] = 1; // bias
        X.push(x);
        const y = new Float32Array(CH.N);
        for (let c = 0; c < CH.N; c++) y[c] = symbolicWorld.ch[c][i];
        Y.push(y);
      }
      this.decoder = leastSquares(X, Y, EMBED_DIM + 1, CH.N);
      return this.decodeError(X, Y);
    }

    decodeError(X, Y) {
      if (!this.decoder) return Infinity;
      let se = 0, n = 0;
      for (let s = 0; s < X.length; s++) {
        const pred = matVec(this.decoder, X[s], CH.N);
        for (let c = 0; c < CH.N; c++) { const e = pred[c] - Y[s][c]; se += e * e; n++; }
      }
      return Math.sqrt(se / n);
    }

    decodeToChannels() {
      if (!this.decoder) return this.ch;
      const x = new Float32Array(EMBED_DIM + 1);
      x[EMBED_DIM] = 1;
      for (let i = 0; i < this.w * this.h; i++) {
        for (let d = 0; d < EMBED_DIM; d++) x[d] = this.latent[d][i];
        const y = matVec(this.decoder, x, CH.N);
        for (let c = 0; c < CH.N; c++) this.ch[c][i] = clamp(y[c], 0, 1);
      }
      return this.ch;
    }

    /** How "mushy" is this world? Variance across cells, per channel.
     *  Averaging collapses variance -> low detail -> the Mush Problem. */
    mushScore() {
      let total = 0;
      for (let c = 0; c < CH.N; c++) {
        const arr = this.ch[c];
        let mean = 0;
        for (let i = 0; i < arr.length; i++) mean += arr[i];
        mean /= arr.length;
        let v = 0;
        for (let i = 0; i < arr.length; i++) { const d = arr[i] - mean; v += d * d; }
        total += Math.sqrt(v / arr.length);
      }
      return total / CH.N;
    }
  }

  function matVec(M, x, rows) {
    const out = new Float32Array(rows);
    for (let r = 0; r < rows; r++) {
      let s = 0;
      for (let c = 0; c < x.length; c++) s += M[r * x.length + c] * x[c];
      out[r] = s;
    }
    return out;
  }

  // Normal equations with Tikhonov regularization — ridge regression.
  // We regularize because the latent matrix is rank-deficient by construction:
  // this is itself a symptom of the design (24 dims cannot carry a world).
  function leastSquares(X, Y, dim, outDim, lambda = 0.8) {
    const A = new Float64Array(dim * dim);
    const B = new Float64Array(dim * outDim);
    for (let s = 0; s < X.length; s++) {
      const x = X[s], y = Y[s];
      for (let i = 0; i < dim; i++) {
        const xi = x[i];
        for (let j = 0; j < dim; j++) A[i * dim + j] += xi * x[j];
        for (let o = 0; o < outDim; o++) B[i * outDim + o] += xi * y[o];
      }
    }
    for (let i = 0; i < dim; i++) A[i * dim + i] += lambda;
    const Ainv = invert(A, dim);
    const M = new Float64Array(outDim * dim);
    for (let o = 0; o < outDim; o++) {
      for (let i = 0; i < dim; i++) {
        let s = 0;
        for (let j = 0; j < dim; j++) s += Ainv[i * dim + j] * B[j * outDim + o];
        M[o * dim + i] = s;
      }
    }
    return M;
  }

  function invert(A, n) {
    const M = new Float64Array(n * 2 * n);
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) M[i * 2 * n + j] = A[i * n + j];
      M[i * 2 * n + n + i] = 1;
    }
    for (let col = 0; col < n; col++) {
      let piv = col;
      for (let r = col + 1; r < n; r++) if (Math.abs(M[r * 2 * n + col]) > Math.abs(M[piv * 2 * n + col])) piv = r;
      if (piv !== col) for (let k = 0; k < 2 * n; k++) {
        const t = M[col * 2 * n + k]; M[col * 2 * n + k] = M[piv * 2 * n + k]; M[piv * 2 * n + k] = t;
      }
      const d = M[col * 2 * n + col] || 1e-12;
      for (let k = 0; k < 2 * n; k++) M[col * 2 * n + k] /= d;
      for (let r = 0; r < n; r++) {
        if (r === col) continue;
        const f = M[r * 2 * n + col];
        if (f === 0) continue;
        for (let k = 0; k < 2 * n; k++) M[r * 2 * n + k] -= f * M[col * 2 * n + k];
      }
    }
    const inv = new Float64Array(n * n);
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) inv[i * n + j] = M[i * 2 * n + n + j];
    return inv;
  }

  /* ==========================================================================
     5. Neural materializer — appearance as a cache
     --------------------------------------------------------------------------
     Trained ONCE against a curated target function (in production: against
     baked ground truth / reference renders). At runtime it is a pure function
     of symbolic features. It can be wrong, stale, or missing entirely and the
     world remains correct — that is the whole point of the split.
     ====================================================================== */

  const STYLE_DIM = 4;            // regional "character" code — see below
  const MAT_IN = 9 + STYLE_DIM;   // channels + slope + aspect + hash + style
  const MAT_OUT = 4;              // r, g, b, micro-displacement

  function smoothstep(e0, e1, x) {
    const t = clamp((x - e0) / (e1 - e0 || 1e-6), 0, 1);
    return t * t * (3 - 2 * t);
  }

  /**
   * Curated biome target — the SYMBOLIC ground truth the materializer learns.
   *
   * Every transition is a smoothstep blend, not a hard branch. This matters for
   * two reasons beyond looking better:
   *   1. A ReLU network cannot represent a discontinuity without unbounded
   *      width. Hard `if` thresholds guarantee a smeared fit and a visible
   *      "pop" when progressive refinement swaps lo-fi for hi-fi.
   *   2. Smooth targets give smooth gradients, so the bake converges in far
   *      fewer steps — directly reducing offline GPU cost.
   *
   * In production this function is replaced by your reference renders; the
   * contract is the same either way: it is authored truth, and the net
   * approximates it. The net never decides what the world IS.
   */
  function biomeTarget(elev, moist, rock, veg, struct, water, slope, out) {
    // --- base palette: dry grassland -> lush forest, by vegetation & moisture
    const lush = clamp(veg * 0.75 + moist * 0.35, 0, 1);
    let r = lerp(172, 66, lush);
    let g = lerp(154, 118, lush);
    let b = lerp(96, 52, lush);

    // --- shore / sand: low ground near the waterline
    const sand = (1 - smoothstep(0.30, 0.40, elev)) * (1 - smoothstep(0.15, 0.40, water));
    r = lerp(r, 208, sand); g = lerp(g, 192, sand); b = lerp(b, 146, sand);

    // --- exposed rock: high rockiness and too barren to hold vegetation
    const barren = 1 - smoothstep(0.10, 0.38, veg);
    const rockT = smoothstep(0.42, 0.72, rock) * barren * (0.55 + slope * 0.45);
    r = lerp(r, 128, rockT); g = lerp(g, 124, rockT); b = lerp(b, 120, rockT);

    // --- snow / high alpine
    const snow = smoothstep(0.74, 0.88, elev);
    r = lerp(r, 244, snow); g = lerp(g, 247, snow); b = lerp(b, 252, snow);

    // --- water body, applied last so it occludes the bed
    const deep = smoothstep(0.18, 0.55, water);
    const shallow = smoothstep(0.02, 0.20, water);
    const wt = clamp(shallow, 0, 1);
    r = lerp(r, lerp(84, 16, deep), wt);
    g = lerp(g, lerp(136, 52, deep), wt);
    b = lerp(b, lerp(164, 104, deep), wt);

    // --- built structure
    const s = smoothstep(0.18, 0.75, struct);
    r = lerp(r, 216, s * 0.88); g = lerp(g, 198, s * 0.88); b = lerp(b, 170, s * 0.88);

    out[0] = clamp(r / 255, 0, 1);
    out[1] = clamp(g / 255, 0, 1);
    out[2] = clamp(b / 255, 0, 1);
    out[3] = slope * 0.25 + s * 0.55 - deep * 0.10;   // micro-displacement
    return out;
  }

  /**
   * The style-conditioned target — what the neural materializer learns and
   * what a shader lookup table CANNOT express, because `style` is not a world
   * channel. It is a property of the REGIONAL WEIGHTS.
   *
   * This is the architectural justification for the materializer, and it is
   * also the mechanism behind the roadmap's Phase 6.2 marketplace: the same
   * symbolic world, rendered through a different style code, looks different —
   * while remaining byte-identical in truth. Swap the weights, keep the save.
   */
  function styledTarget(f, style, out) {
    biomeTarget(f[0], f[1], f[2], f[3], f[4], f[5], f[6], out);
    const hash = f[8];
    // Style dimensions modulate palette, grain and relief exaggeration.
    const warm = style[0] - 0.5, cool = style[1] - 0.5;
    const grain = style[2], relief = style[3] - 0.5;
    const n = (hash - 0.5) * (0.05 + grain * 0.16);
    out[0] = clamp(out[0] + warm * 0.20 + n * 1.15, 0, 1);
    out[1] = clamp(out[1] + cool * 0.06 + n * 0.85, 0, 1);
    out[2] = clamp(out[2] - warm * 0.10 + cool * 0.18 + n * 0.95, 0, 1);
    out[3] = out[3] + relief * 0.30 * (f[6] - 0.3);
    return out;
  }

  /** Named style presets — stand-ins for player-authored regional weights. */
  const STYLE_PRESETS = {
    vanilla:    [0.50, 0.50, 0.25, 0.50],
    arid:       [0.86, 0.30, 0.55, 0.66],
    boreal:     [0.22, 0.72, 0.30, 0.44],
    neon:       [0.78, 0.24, 0.92, 0.78],
    monochrome: [0.50, 0.52, 0.10, 0.30]
  };

  /**
   * Two-tower conditional decoder.
   *
   * Tower A (`baseNet`) maps world channels -> appearance. It learns the biome
   * ramp, which is piecewise and capacity-hungry.
   * Tower B (`styleNet`) maps the regional style code (+ grain + slope) ->
   * a residual. It learns style conditioning, which is mostly linear with a
   * couple of multiplicative interactions.
   *
   * Why not one MLP over the concatenation? Because a single ReLU stack spends
   * nearly all its capacity on the harder of the two tasks and underfits the
   * other. Measured: a single 48x48 tower recovered only ~35% of the style
   * signal. Splitting the towers recovers it, and it also means a regional
   * style pack can be swapped WITHOUT retraining the base appearance model —
   * which is precisely what the roadmap's Phase 6.2 marketplace needs.
   *
   * Trained by block coordinate descent: the residual is additive, so each
   * tower is stepped against the other tower's current output held constant.
   */
  const CHAN_IN = 9;                       // channels + slope + aspect + grain
  const STYLE_IN = STYLE_DIM + 2;          // style + grain + slope

  class Materializer {
    constructor(seed = 42) {
      this.baseNet = new MLP([CHAN_IN, 48, 48, MAT_OUT], seed);
      this.styleNet = new MLP([STYLE_IN, 24, 24, MAT_OUT], seed ^ 0xa11ce, { leaky: 0.2 });
      this.trained = false;
      this.trainLoss = Infinity;
      this._chan = new Float32Array(CHAN_IN);
      this._sty = new Float32Array(STYLE_IN);
      this._a = new Float32Array(MAT_OUT);
      this._b = new Float32Array(MAT_OUT);
    }

    get paramCount() { return this.baseNet.paramCount + this.styleNet.paramCount; }
    get net() { return this.baseNet; }   // back-compat for tests that poke weights

    /**
     * Bounded work: this is the OFFLINE BAKE. Paid once per model, never per
     * frame. That is what makes "bake heavy / run light" close on cost.
     */
    train(world, steps = 2600, seed = 99) {
      const rng = mulberry32(seed);
      const f = new Float32Array(MAT_IN);
      const ys = new Float32Array(MAT_OUT);
      const style = new Float32Array(STYLE_DIM);
      let last = 0;
      for (let s = 0; s < steps; s++) {
        const batch = 24;
        let acc = 0;
        for (let k = 0; k < batch; k++) {
          // ~85% real world states, ~15% randomized so the model generalizes
          // to terrain the player has not visited yet.
          if (rng() < 0.85 && world) {
            const i = (rng() * world.w * world.h) | 0;
            featuresAt(world, i % world.w, (i / world.w) | 0, f, null);
          } else {
            f[0] = rng(); f[1] = rng(); f[2] = Math.pow(rng(), 2);
            f[3] = rng(); f[4] = Math.pow(rng(), 3); f[5] = Math.pow(rng(), 2);
            f[6] = rng() * 0.6; f[7] = rng() * 2 - 1; f[8] = rng();
          }
          for (let d = 0; d < STYLE_DIM; d++) style[d] = rng();
          f.set(style, 9);

          N_styledTarget(f, style, ys);

          // split the input into the two towers' views
          this._chan.set(f.subarray(0, CHAN_IN));
          this._sty[0] = style[0]; this._sty[1] = style[1];
          this._sty[2] = style[2]; this._sty[3] = style[3];
          this._sty[4] = f[8];   // grain
          this._sty[5] = f[6];   // slope

          // block coordinate descent
          this.baseNet.forward(this._chan, this._a);
          const residB = new Float32Array(MAT_OUT);
          for (let o = 0; o < MAT_OUT; o++) residB[o] = ys[o] - this._a[o];
          acc += this.styleNet.step(this._sty, residB, 0.006) * 0.5;

          this.styleNet.forward(this._sty, this._b);
          const residA = new Float32Array(MAT_OUT);
          for (let o = 0; o < MAT_OUT; o++) residA[o] = ys[o] - this._b[o];
          acc += this.baseNet.step(this._chan, residA, 0.012) * 0.5;
        }
        last = acc / batch;
      }
      this.trainLoss = last;
      this.trained = true;
      return last;
    }

    /** High-fidelity path: style-aware, carries learned detail. */
    decode(features, out) {
      this._chan.set(features.subarray(0, CHAN_IN));
      this._sty[0] = features[9]; this._sty[1] = features[10];
      this._sty[2] = features[11]; this._sty[3] = features[12];
      this._sty[4] = features[8];
      this._sty[5] = features[6];
      this.baseNet.forward(this._chan, this._a);
      this.styleNet.forward(this._sty, this._b);
      for (let o = 0; o < MAT_OUT; o++) out[o] = this._a[o] + this._b[o];
      return out;
    }

    /**
     * Low-fidelity path — NO network, NO style. Renders on frame 0 while the
     * neural bake is in flight. Instant, and never wrong enough to mislead:
     * it is the same symbolic truth, minus learned detail.
     */
    decodeLoFi(features, out) {
      return biomeTarget(features[0], features[1], features[2], features[3],
        features[4], features[5], features[6], out);
    }
  }

  // local alias so the class body above stays readable
  const N_styledTarget = styledTarget;

  function featuresAt(world, x, y, out, style) {
    const i = world.idx(x, y);
    const elev = world.ch[CH.ELEV][i];
    let dx = 0, dy = 0;
    if (x > 0 && x < world.w - 1) dx = world.ch[CH.ELEV][i + 1] - world.ch[CH.ELEV][i - 1];
    if (y > 0 && y < world.h - 1) dy = world.ch[CH.ELEV][i + world.w] - world.ch[CH.ELEV][i - world.w];
    out[0] = elev;
    out[1] = world.ch[CH.MOIST][i];
    out[2] = world.ch[CH.ROCK][i];
    out[3] = world.ch[CH.VEG][i];
    out[4] = world.ch[CH.STRUCT][i];
    out[5] = world.ch[CH.WATER][i];
    out[6] = Math.min(1, Math.hypot(dx, dy) * 6);                        // slope
    out[7] = (dx === 0 && dy === 0) ? 0 : Math.atan2(dy, dx) / Math.PI;  // aspect
    out[8] = hash2(x, y, world.seed);                                    // stable grain
    if (style) out.set(style, 9);
    return out;
  }
  /* ==========================================================================
     6. Progressive refinement — the latency story
     --------------------------------------------------------------------------
     The client never waits on generation. It renders lo-fi from symbolic truth
     IMMEDIATELY, then upgrades chunks as materialization completes. Fidelity
     arrives; responsiveness never leaves.
     ====================================================================== */

  class RefinementScheduler {
    constructor(world, chunkW, chunkH, opts = {}) {
      this.world = world;
      this.cw = chunkW; this.chh = chunkH;
      this.cols = Math.ceil(world.w / chunkW);
      this.rows = Math.ceil(world.h / chunkH);
      this.state = new Uint8Array(this.cols * this.rows); // 0=lofi 1=queued 2=hidim
      this.progress = new Float32Array(this.cols * this.rows);
      this.queue = [];
      // Simulated bake cost per chunk. In production this is a GPU job; the
      // number below is what makes the latency-hiding claim testable.
      this.bakeMsPerChunk = opts.bakeMsPerChunk ?? 90;
      this.msPerFrame = opts.msPerFrame ?? 16.7;
      this.stats = { bakes: 0, cacheHits: 0, cacheMisses: 0, bakeMsTotal: 0 };
    }

    cid(cx, cy) { return cy * this.cols + cx; }

    invalidate(rect) {
      if (!rect) return [];
      const cx0 = Math.floor(rect.x0 / this.cw), cx1 = Math.floor(rect.x1 / this.cw);
      const cy0 = Math.floor(rect.y0 / this.chh), cy1 = Math.floor(rect.y1 / this.chh);
      const touched = [];
      for (let cy = cy0; cy <= cy1; cy++) {
        for (let cx = cx0; cx <= cx1; cx++) {
          if (cx < 0 || cy < 0 || cx >= this.cols || cy >= this.rows) continue;
          const id = this.cid(cx, cy);
          if (this.state[id] === 2) this.stats.cacheMisses++;
          this.state[id] = 1;
          this.progress[id] = 0;
          if (!this.queue.includes(id)) this.queue.push(id);
          touched.push(id);
        }
      }
      return touched;
    }

    /** Advance simulated bake work by one frame's worth of budget. */
    tick(frameMs = this.msPerFrame) {
      let budget = frameMs * (this.parallelBakes || 2);
      const done = [];
      while (budget > 0 && this.queue.length) {
        const id = this.queue[0];
        const need = this.bakeMsPerChunk * (1 - this.progress[id]);
        const spend = Math.min(need, budget);
        this.progress[id] += spend / this.bakeMsPerChunk;
        budget -= spend;
        this.stats.bakeMsTotal += spend;
        if (this.progress[id] >= 1) {
          this.state[id] = 2;
          this.progress[id] = 1;
          this.queue.shift();
          this.stats.bakes++;
          done.push(id);
        }
      }
      return done;
    }

    /** Which fidelity does a given cell render at, right now? */
    fidelityAt(x, y) {
      const id = this.cid(Math.floor(x / this.cw), Math.floor(y / this.chh));
      if (this.state[id] === 2) { this.stats.cacheHits++; return 1; }
      return 0;
    }

    fractionHiFi() {
      let n = 0;
      for (let i = 0; i < this.state.length; i++) if (this.state[i] === 2) n++;
      return n / this.state.length;
    }
  }

  /* ==========================================================================
     7. Agents — macro tier only
     ====================================================================== */

  class SettlerAgent {
    constructor(id, opts = {}) {
      this.id = id;
      this.cooldown = opts.cooldown ?? 40;
      this.lastDecision = -1e9;
      this.rng = mulberry32(opts.seed ?? (id * 7919 + 13));
      this.utility = opts.utility ?? { water: 1.4, flat: 1.1, veg: 0.9, isolate: 0.7, avoidRock: 0.8 };
      this.log = [];
      this.tokenBudget = opts.tokenBudget ?? 64; // hard cap per macro decision
    }

    decide(world) {
      if (world.macroTick - this.lastDecision < this.cooldown) return [];
      this.lastDecision = world.macroTick;

      // sample candidate sites — cheap, bounded
      let best = null;
      for (let s = 0; s < 90; s++) {
        const x = 6 + ((this.rng() * (world.w - 12)) | 0);
        const y = 6 + ((this.rng() * (world.h - 12)) | 0);
        const score = this.scoreSite(world, x, y);
        if (!best || score.v > best.v) best = { x, y, v: score.v, why: score.why };
      }
      if (!best || best.v < 0.42) return [];

      const intent = world.makeIntent('build', {
        x: best.x, y: best.y, r: 2.4, kind: 'settlement', actor: 'agent:' + this.id
      });
      world.apply(intent);
      const ev = {
        tick: world.macroTick, actor: this.id, kind: 'FOUND_SETTLEMENT',
        x: best.x, y: best.y, score: +best.v.toFixed(3),
        rationale: best.why, tokens: Math.min(this.tokenBudget, 24 + ((best.v * 40) | 0))
      };
      this.log.push(ev);
      return [ev];
    }

    scoreSite(world, x, y) {
      const i = world.idx(x, y);
      const e = world.ch[CH.ELEV][i];
      if (e < 0.33 || e > 0.76 || world.ch[CH.WATER][i] > 0.3) return { v: -1, why: 'uninhabitable' };

      // water within radius
      let waterNear = 0, vegNear = 0, structNear = 0, slopeAcc = 0, n = 0;
      const R = 6;
      for (let dy = -R; dy <= R; dy++) {
        for (let dx = -R; dx <= R; dx++) {
          const xx = x + dx, yy = y + dy;
          if (!world.inBounds(xx, yy)) continue;
          const j = world.idx(xx, yy);
          const d = Math.hypot(dx, dy);
          if (d > R) continue;
          const w = 1 - d / R;
          waterNear += world.ch[CH.WATER][j] * w;
          vegNear += world.ch[CH.VEG][j] * w;
          structNear += world.ch[CH.STRUCT][j] * w;
          slopeAcc += Math.abs(world.ch[CH.ELEV][j] - e) * w;
          n += w;
        }
      }
      waterNear /= n; vegNear /= n; structNear /= n;
      const flat = 1 - clamp(slopeAcc / n * 12, 0, 1);
      const u = this.utility;
      // Normalise by the maximum attainable positive utility so the score is a
      // true [0,1] and the acceptance threshold means what it says. (Clamping
      // the raw sum to 1 *before* normalising silently caps every site below
      // threshold and the agent never acts — easy bug to miss.)
      const raw =
        u.water * clamp(waterNear * 3.2, 0, 1) +
        u.flat * flat +
        u.veg * clamp(vegNear * 1.8, 0, 1) -
        u.isolate * clamp(structNear * 1.4, 0, 1) -
        u.avoidRock * world.ch[CH.ROCK][i];
      const maxPos = u.water + u.flat + u.veg;
      const v = clamp(raw / maxPos, 0, 1);

      const why = [];
      if (waterNear > 0.12) why.push('fresh water');
      if (flat > 0.6) why.push('level ground');
      if (vegNear > 0.2) why.push('timber/forage');
      if (structNear > 0.2) why.push('crowded — penalized');
      return { v, why: why.join(', ') || 'marginal' };
    }
  }

  /**
   * The negotiation resolver.
   *
   * Conflict between player intent and agent intent is resolved by composing
   * SYMBOLIC operations — not by blending vectors. The output is a deterministic,
   * explainable compromise plus a narrative event the player can read.
   */
  class NegotiationResolver {
    constructor() { this.history = []; }

    /**
     * @param {World} world
     * @param {object} playerIntent  already-applied intent that caused harm
     * @returns {object|null} resolution event
     */
    resolve(world, playerIntent) {
      if (playerIntent.op !== 'deforest') return null;
      const { x, y, r } = playerIntent.params;

      // find affected settlements
      const affected = world.settlements.filter(s => Math.hypot(s.x - x, s.y - y) < r + s.r + 5);
      if (!affected.length) return null;

      const removed = playerIntent._removedVeg || 0;
      if (removed < 0.6) return null; // below the grievance threshold

      const s = affected[0];
      const grievance = clamp(removed / 6, 0, 1);

      // Compromise is a COMPOSITION of concrete operations:
      //   partial restoration + a riparian/green buffer + relocation pressure.
      const ops = [
        { op: 'afforest', params: { x, y, r: r * 0.55, amount: 0.35 + grievance * 0.45 } },
        { op: 'afforest', params: { x: s.x, y: s.y, r: s.r + 3, amount: 0.25 } }
      ];
      const compromise = world.makeIntent('resolve', { ops, actor: 'resolver' });
      const dirty = world.apply(compromise);

      const outcome =
        grievance > 0.72 ? 'PROTEST' :
        grievance > 0.40 ? 'COMPROMISE' : 'GRUMBLING';

      const ev = {
        tick: world.macroTick, kind: outcome,
        player: { x, y, r }, settlement: { x: s.x, y: s.y, owner: s.owner },
        grievance: +grievance.toFixed(3),
        text: this.narrate(outcome, grievance, s),
        opsApplied: ops.length,
        dirty
      };
      this.history.push(ev);
      return ev;
    }

    narrate(outcome, g, s) {
      const who = s.owner.startsWith('agent') ? 'the settlers' : 'the townsfolk';
      switch (outcome) {
        case 'PROTEST':
          return `${who} of the settlement at (${s.x},${s.y}) block your crews. ` +
                 `Grievance ${(g * 100) | 0}%. A green belt is replanted and your clearance is halved.`;
        case 'COMPROMISE':
          return `${who} petition you. Grievance ${(g * 100) | 0}%. ` +
                 `They accept the clearing in exchange for replanting near the water.`;
        default:
          return `${who} grumble about the felling (${(g * 100) | 0}% grievance) but let it stand.`;
      }
    }
  }

  /* ==========================================================================
     8. Cost model — because unit economics decide feasibility
     --------------------------------------------------------------------------
     The binding constraint for this project is not fidelity or latency in the
     abstract; it is dollars per player-hour. Both architectures are modelled
     from the same assumption set so the comparison is honest.

     Key asymmetry: a BAKE is paid once per chunk and amortized over every
     player-hour that chunk is viewed. RUNTIME GENERATION is paid per player
     per interaction and never amortizes. That single difference is the whole
     business case for "bake heavy, run light".
     ====================================================================== */

  const PRICE = {
    gpuHourA100: 2.50,        // $/GPU-hour, on-demand, 2026-ish
    cpuHour: 0.05,            // $/vCPU-hour
    llmPerMTok: 0.10,         // $/1M tokens, small instruct model, blended in+out
    deviceInference: 0.0      // runs on the player's GPU — free to us
  };

  class CostModel {
    constructor(assumptions = {}) {
      // Bake cost per chunk, GPU-seconds. A 3DGS / splat-texture bake of one
      // chunk at production quality is minutes on an A100; we use a modest
      // number so the corrected case is not flattered.
      this.bakeGpuSecPerChunk = assumptions.bakeGpuSecPerChunk ?? 45;
      // Runtime text->3D / neural-asset generation per player interaction.
      this.runtimeGenGpuSec = assumptions.runtimeGenGpuSec ?? 6;
      this.chunksPerShard = assumptions.chunksPerShard ?? 120;
      this.chunkLifetimeHours = assumptions.chunkLifetimeHours ?? 24; // rebake cadence
      this.macroCallsPerPlayerHour = assumptions.macroCallsPerPlayerHour ?? 12;
      this.tokensPerMacroCall = assumptions.tokensPerMacroCall ?? 900;
      this.interactionsPerPlayerHour = assumptions.interactionsPerPlayerHour ?? 120;
      this.serverVcpu = assumptions.serverVcpu ?? 0.5;
      this.macroServerVcpu = assumptions.macroServerVcpu ?? 2.0;
    }

    // ---- observed accounting (what actually happened this session) ----
    constructor_reset() {}
    addMicro(seconds) { this.obsMicroSec = (this.obsMicroSec || 0) + seconds; }
    addMacro(tokens) {
      this.obsMacroCalls = (this.obsMacroCalls || 0) + 1;
      this.obsMacroTokens = (this.obsMacroTokens || 0) + tokens;
    }
    addBake(seconds) {
      this.obsBakes = (this.obsBakes || 0) + 1;
      this.obsBakeSec = (this.obsBakeSec || 0) + seconds;
    }
    addDecode(seconds) { this.obsDecodeSec = (this.obsDecodeSec || 0) + seconds; }

    /** Observed device-side work. Free to the operator — that is the point. */
    observed() {
      return {
        microSec: this.obsMicroSec || 0,
        macroCalls: this.obsMacroCalls || 0,
        macroTokens: this.obsMacroTokens || 0,
        bakes: this.obsBakes || 0,
        bakeSec: this.obsBakeSec || 0,
        decodeSec: this.obsDecodeSec || 0,
        // what this session WOULD have cost on the server if it were not on-device
        avoidedServerCost: (this.obsDecodeSec || 0) * (PRICE.gpuHourA100 / 3600)
      };
    }

    /** Corrected: bake offline/on-demand, cache, serve from device. */
    corrected(players) {
      const bakesPerHour = this.chunksPerShard / this.chunkLifetimeHours;
      const bake = bakesPerHour * this.bakeGpuSecPerChunk / 3600 * PRICE.gpuHourA100;
      const macro = players * this.macroCallsPerPlayerHour *
        (this.tokensPerMacroCall / 1e6) * PRICE.llmPerMTok;
      const cpu = this.serverVcpu * PRICE.cpuHour;
      return {
        label: 'corrected (bake heavy / run light)',
        bake, macro, cpu, device: 0,
        total: bake + macro + cpu,
        perPlayerHour: (bake + macro + cpu) / Math.max(players, 1)
      };
    }

    /** Naive: the original roadmap — generate the world at runtime, per action. */
    naive(players) {
      const gen = players * this.interactionsPerPlayerHour *
        this.runtimeGenGpuSec / 3600 * PRICE.gpuHourA100;
      const macro = players * this.macroCallsPerPlayerHour * 5 *
        (this.tokensPerMacroCall * 3 / 1e6) * PRICE.llmPerMTok;
      const cpu = this.macroServerVcpu * PRICE.cpuHour;
      return {
        label: 'naive (runtime generation)',
        bake: 0, macro, cpu, device: 0, gen,
        total: gen + macro + cpu,
        perPlayerHour: (gen + macro + cpu) / Math.max(players, 1)
      };
    }

    static fmt(c) {
      const parts = [];
      if (c.bake) parts.push(`bake ${c.bake.toFixed(2)}`);
      if (c.gen) parts.push(`runtime-gen ${c.gen.toFixed(2)}`);
      if (c.macro) parts.push(`macro-LLM ${c.macro.toFixed(2)}`);
      if (c.cpu) parts.push(`cpu ${c.cpu.toFixed(2)}`);
      return `${c.label}: ${c.total.toFixed(2)}/hr  [${parts.join(', ')}]  ` +
             `= ${c.perPlayerHour.toFixed(4)}/player-hr`;
    }
  }

  /* ==========================================================================
     exports
     ====================================================================== */

  const NEBULA = {
    // primitives
    mulberry32, hash2, clamp, lerp, smooth, makeValueNoise, fbm, stateHash, hash32,
    // world
    World, CH, CH_NAMES, OPS, brushMask, dirtyRect, unionRect, featuresAt,
    // negative control
    LatentWorld, embedIntent, EMBED_DIM, OP_EMBED, leastSquares,
    // neural materialization
    MLP, Materializer, biomeTarget, styledTarget, MAT_IN, MAT_OUT,
    STYLE_DIM, STYLE_PRESETS,
    // scheduling
    RefinementScheduler,
    // agents
    SettlerAgent, NegotiationResolver,
    // economics
    CostModel, PRICE
  };

  root.NEBULA = NEBULA;
  if (typeof module !== 'undefined' && module.exports) module.exports = NEBULA;

})(typeof globalThis !== 'undefined' ? globalThis : this);
