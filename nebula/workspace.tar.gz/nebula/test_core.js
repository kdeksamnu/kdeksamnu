/* Verify the corrected architecture's load-bearing claims, numerically.
   Run: node nebula/test_core.js                                            */

const N = require('./core.js');

const W = 128, H = 80;
let pass = 0, fail = 0;
function ok(name, cond, detail = '') {
  if (cond) { pass++; console.log(`  \x1b[32mPASS\x1b[0m  ${name}${detail ? '  \x1b[90m' + detail + '\x1b[0m' : ''}`); }
  else { fail++; console.log(`  \x1b[31mFAIL\x1b[0m  ${name}  ${detail}`); }
}
function hdr(s) { console.log(`\n\x1b[1m${s}\x1b[0m`); }

/* ---------------------------------------------------------------- C1 */
hdr('C1 — Symbolic state is replayable, idempotent, and diffable');

const world = new N.World(W, H, 1337);
const h0 = world.fingerprint();

const intents = [
  world.makeIntent('raise',    { x: 40, y: 30, r: 6, amount: 0.5 }),
  world.makeIntent('carve',    { x: 44, y: 33, r: 4, depth: 0.4, dir: 0.4 }),
  world.makeIntent('afforest', { x: 70, y: 50, r: 7, amount: 0.6 }),
  world.makeIntent('deforest', { x: 72, y: 51, r: 5, amount: 0.7 }),
  world.makeIntent('build',    { x: 90, y: 40, r: 3, kind: 'settlement', actor: 'player' }),
];
for (const it of intents) world.apply(it);
const h1 = world.fingerprint();
ok('applying intents changes state', h1 !== h0, `${h0} -> ${h1}`);

// idempotency: re-deliver every event
for (const it of intents) {
  const r = world.apply(it);
  if (!r.duplicate) { fail++; console.log('  \x1b[31mFAIL\x1b[0m  re-delivery was not detected as duplicate'); break; }
}
ok('re-delivered events are no-ops (idempotent)', world.fingerprint() === h1);

// replay from log reproduces exactly
const replayed = N.World.replay(world.events, W, H, 1337);
ok('event-log replay reproduces identical state', replayed.fingerprint() === h1, replayed.fingerprint());

// order tolerance: shuffle arrival order, replay canonically
const shuffled = world.events.slice().sort(() => Math.random() - 0.5);
const r2 = N.World.replay(shuffled, W, H, 1337);
ok('arrival order does not affect converged state', r2.fingerprint() === h1);

// diffability — a vector cannot do this
const elevDelta = [];
for (let i = 0; i < W * H; i++) {
  const d = world.ch[N.CH.ELEV][i] - replayed.ch[N.CH.ELEV][i];
  if (Math.abs(d) > 1e-6) elevDelta.push(i);
}
ok('state is diffable at cell granularity', elevDelta.length === 0, `${elevDelta.length} differing cells`);

// The bug the headless harness caught: micro-simulation mutates state without
// logging an event, so replaying the log alone produced a DIFFERENT world.
// Events must be interleaved with simulation at the tick each was authored.
{
  const live = new N.World(96, 60, 4242);
  for (let i = 0; i < 30; i++) live.microStep(1);
  live.apply(live.makeIntent('raise', { x: 30, y: 25, r: 6, amount: 0.6 }));
  for (let i = 0; i < 40; i++) live.microStep(1);
  live.apply(live.makeIntent('carve', { x: 33, y: 27, r: 5, depth: 0.5, dir: 0.3 }));
  for (let i = 0; i < 50; i++) live.microStep(1);
  live.apply(live.makeIntent('afforest', { x: 60, y: 40, r: 7, amount: 0.7 }));
  for (let i = 0; i < 25; i++) live.microStep(1);
  const liveFp = live.fingerprint();

  const naiveReplay = N.World.replay(live.events, 96, 60, 4242, 0); // no sim
  const interleaved = N.World.replay(live.events, 96, 60, 4242, live.microTick);

  ok('replaying the log WITHOUT simulation does NOT reproduce the live world',
    naiveReplay.fingerprint() !== liveFp, 'this is the bug that would desync rollback netcode');
  ok('replaying with interleaved simulation reproduces it exactly',
    interleaved.fingerprint() === liveFp, `${interleaved.fingerprint()} vs ${liveFp}`);
  ok('interleaved replay restores the tick count', interleaved.microTick === live.microTick,
    `${interleaved.microTick} vs ${live.microTick}`);

  // and the sim-only mass budget stays clean even after authored edits
  ok('sim drift separates authored mass from simulation mass', live.simDrift() < 1e-4,
    `simDrift=${live.simDrift().toExponential(2)}  authoredMass=${live.authoredMass.toFixed(3)}`);
}

/* ---------------------------------------------------------------- C2 */
hdr('C2 — Composition beats vector averaging (the "mush" test)');

const base = new N.World(W, H, 1337);           // shared starting world
const sym = N.World.replay([], W, H, 1337);       // corrected architecture
const naive = new N.LatentWorld(W, H, 1337, true).seedFrom(base);    // §4.2 verbatim
const anchored = new N.LatentWorld(W, H, 1337, false).seedFrom(base); // its mitigation

// The exact scenario from the roadmap §4.2: Player A builds a mountain,
// Player B carves a river, in the SAME region.
const conflict = [
  { op: 'raise', params: { x: 64, y: 40, r: 8, amount: 0.85 }, id: 1 },
  { op: 'carve', params: { x: 64, y: 40, r: 8, depth: 0.8, dir: 0.5 }, id: 2 },
];
for (const c of conflict) {
  sym.apply(sym.makeIntent(c.op, c.params));
  naive.apply(c);
  anchored.apply(c);
}

// CRITICAL experimental-design point: the decoder is fit ONCE, on the base
// world, BEFORE any player acts. That is how it works in production — you do
// not refit your decoder after every edit. Fitting it afterwards lets the
// latent design memorise the answer and hide its own failure.
const base2 = new N.World(W, H, 1337);
const rmseN = naive.fitDecoder(base2), rmseA = anchored.fitDecoder(base2);
console.log(`  \x1b[90mdecoder fit on untouched base world: naive RMSE=${rmseN.toFixed(4)}  anchored RMSE=${rmseA.toFixed(4)}\x1b[0m`);
naive.decodeToChannels(); anchored.decodeToChannels();

// Did the symbolic composition produce a CANYON (high relief + water present)?
let peak = 0, canyonCells = 0, waterCells = 0;
for (let y = 30; y < 50; y++) {
  for (let x = 54; x < 74; x++) {
    const i = sym.idx(x, y);
    peak = Math.max(peak, sym.ch[N.CH.ELEV][i]);
    if (sym.ch[N.CH.WATER][i] > 0.2) waterCells++;
  }
}
// canyon = water sitting in a low channel surrounded by high terrain
for (let y = 30; y < 50; y++) {
  for (let x = 54; x < 74; x++) {
    const i = sym.idx(x, y);
    if (sym.ch[N.CH.WATER][i] > 0.2 && sym.ch[N.CH.ROCK][i] > 0.25) canyonCells++;
  }
}
ok('symbolic composition yields a river cutting high terrain', peak > 0.7 && waterCells > 0,
  `peak=${peak.toFixed(3)} waterCells=${waterCells} canyonCells=${canyonCells}`);

// ---- Why the naive design fails, measured three ways ----

// (a) Can it even REPRESENT the composed outcome? Compare decoded channels
//     against symbolic ground truth inside the conflict region.
let seN = 0, seA = 0, nR = 0;
let naiveHasCanyon = 0, symHasCanyon = 0;
for (let y = 32; y < 48; y++) {
  for (let x = 56; x < 72; x++) {
    const i = sym.idx(x, y);
    for (let c = 0; c < N.CH.N; c++) {
      const t = sym.ch[c][i];
      seN += (naive.ch[c][i] - t) ** 2;
      seA += (anchored.ch[c][i] - t) ** 2;
      nR++;
    }
    if (sym.ch[N.CH.WATER][i] > 0.2 && sym.ch[N.CH.ROCK][i] > 0.25) symHasCanyon++;
    if (naive.ch[N.CH.WATER][i] > 0.2 && naive.ch[N.CH.ROCK][i] > 0.25) naiveHasCanyon++;
  }
}
const rmseNaive = Math.sqrt(seN / nR), rmseAnchored = Math.sqrt(seA / nR);
console.log(`  \x1b[90mreconstruction RMSE in conflict region: naive=${rmseNaive.toFixed(4)}  anchored=${rmseAnchored.toFixed(4)}\x1b[0m`);
console.log(`  \x1b[90mcanyon cells (water in rocky terrain):  symbolic=${symHasCanyon}  naive-decoded=${naiveHasCanyon}\x1b[0m`);
ok('naive latent state cannot represent the composed outcome', rmseNaive > 0.03,
  `RMSE ${rmseNaive.toFixed(4)}`);
ok('symbolic composition produces the canyon the roadmap wanted', symHasCanyon > 20,
  `${symHasCanyon} cells`);
ok('naive averaging fails to produce that canyon', naiveHasCanyon < symHasCanyon * 0.5,
  `${naiveHasCanyon} vs ${symHasCanyon}`);

// (b) The actual failure mode is NOT impossible extremes — it is regression to
//     the mean. Averaging pulls every channel toward the global average, so the
//     overlap zone stops being a mountain-river system and becomes a flat,
//     featureless mid-value field. That is the roadmap's own "Mush Problem",
//     and no amount of Anchor-Node post-processing fixes it, because the
//     information was destroyed at the moment of averaging.
function interiorStats(ch, c, cells) {
  let m = 0;
  for (const i of cells) m += ch[c][i];
  m /= cells.length;
  let v = 0;
  for (const i of cells) { const d = ch[c][i] - m; v += d * d; }
  return { mean: m, std: Math.sqrt(v / cells.length) };
}
const overlapCells = (() => {
  const maskA = N.brushMask(sym, 64, 40, 8);
  const cells = [];
  for (const p of maskA) if (p.w > 0.35) cells.push(p.i);
  return cells;
})();
console.log(`  \x1b[90moverlap interior: ${overlapCells.length} cells touched by BOTH intents\x1b[0m`);
let mushReport = [];
let mushDetected = 0;
for (let c = 0; c < N.CH.N; c++) {
  const a = interiorStats(sym.ch, c, overlapCells);
  const b = interiorStats(naive.ch, c, overlapCells);
  mushReport.push(`${N.CH_NAMES[c]}: sym σ=${a.std.toFixed(3)} naive σ=${b.std.toFixed(3)}`);
  if (a.std > 0.02 && b.std < a.std * 0.6) mushDetected++;
}
console.log('  \x1b[90m  ' + mushReport.join('  |  ') + '\x1b[0m');
ok('naive averaging collapses detail in the overlap zone (the mush)',
  mushDetected >= 2, `${mushDetected}/${N.CH.N} channels lost >40% of their variance`);

// And the sharpest single number: error concentrated in the cells BOTH intents
// touched, which is exactly where the roadmap proposed to average.
let seOverlapN = 0, seOverlapS = 0, nOverlap = 0;
{
  const maskA = N.brushMask(sym, 64, 40, 8);
  const maskB = N.brushMask(sym, 64, 40, 8);
  const setA = new Set(maskA.map(p => p.i));
  for (const p of maskB) {
    if (!setA.has(p.i)) continue;
    if (p.w < 0.3) continue;              // interior of the overlap only
    for (let c = 0; c < N.CH.N; c++) {
      seOverlapN += (naive.ch[c][p.i] - sym.ch[c][p.i]) ** 2;
      nOverlap++;
    }
  }
}
const rmseOverlap = nOverlap ? Math.sqrt(seOverlapN / nOverlap) : 0;
console.log(`  \x1b[90mnaive reconstruction error in the overlap interior: RMSE=${rmseOverlap.toFixed(4)}\x1b[0m`);
ok('error concentrates exactly where averaging was proposed', rmseOverlap > 0.05,
  `RMSE ${rmseOverlap.toFixed(4)}`);

// (c) Idempotency failure under re-delivery — already asserted above.
const beforeDrift = naive.latent[0].slice();
naive.apply(conflict[0]); // same event id, delivered twice (at-least-once broker)
let moved = 0;
for (let i = 0; i < beforeDrift.length; i++) if (Math.abs(beforeDrift[i] - naive.latent[0][i]) > 1e-9) moved++;
ok('naive latent averaging DIVERGES under event re-delivery (the bug)', moved > 0, `${moved} cells drifted`);

const symBefore = sym.fingerprint();
const reDelivered = { id: 999, op: 'raise', params: { x: 20, y: 20, r: 4, amount: 0.3 } };
sym.apply(reDelivered);
const afterFirst = sym.fingerprint();
sym.apply(reDelivered); // same event id again — at-least-once broker redelivery
ok('symbolic state does NOT diverge under re-delivery', sym.fingerprint() === afterFirst);
ok('...and the redelivery is actually detected, not silently absorbed',
  sym.apply(reDelivered).duplicate === true);
ok('state genuinely changed on first delivery (test is not vacuous)', afterFirst !== symBefore);

/* ---------------------------------------------------------------- C3 */
hdr('C3 — Neural materializer: learns appearance, cannot corrupt truth');

const mat = new N.Materializer(42);
const t0 = Date.now();
const loss = mat.train(sym, 3000);
const trainMs = Date.now() - t0;
console.log(`  \x1b[90mparams=${mat.net.paramCount}  trainLoss=${loss.toFixed(5)}  bakeTime=${trainMs}ms (paid once, offline)\x1b[0m`);
ok('materializer trains to low error', loss < 0.01, `loss=${loss.toFixed(5)}`);
ok('bake completes in bounded time', trainMs < 15000, `${trainMs}ms`);

// The honest question is NOT "does the student beat the teacher" — the LUT is
// the teacher, so that test is meaningless. The real question: can the neural
// pass express something the symbolic channels CANNOT?
//
// `style` is not a world channel. It is a property of the regional weights.
// A shader LUT over world channels is structurally incapable of rendering it.
const fin = new Float32Array(N.MAT_IN);
const oHi = new Float32Array(N.MAT_OUT), oLo = new Float32Array(N.MAT_OUT);
const tgt = new Float32Array(N.MAT_OUT);
const style = new Float32Array(N.STYLE_DIM);

function evalAgainst(stylePreset, samples = 3000, seed = 5) {
  style.set(N.STYLE_PRESETS[stylePreset]);
  let seHi = 0, seLo = 0, m = 0;
  const rng = N.mulberry32(seed);
  for (let s = 0; s < samples; s++) {
    const x = (rng() * W) | 0, y = (rng() * H) | 0;
    N.featuresAt(sym, x, y, fin, style);
    N.styledTarget(fin, style, tgt);
    mat.decode(fin, oHi);
    mat.decodeLoFi(fin, oLo);
    for (let c = 0; c < 3; c++) {
      seHi += (oHi[c] - tgt[c]) ** 2;
      seLo += (oLo[c] - tgt[c]) ** 2;
    }
    m += 3;
  }
  return { hi: Math.sqrt(seHi / m), lo: Math.sqrt(seLo / m) };
}

const evArid = evalAgainst('arid');
const evBoreal = evalAgainst('boreal');
console.log(`  \x1b[90mstyle="arid"    hi-fi(neural)=${evArid.hi.toFixed(4)}  lo-fi(LUT)=${evArid.lo.toFixed(4)}\x1b[0m`);
console.log(`  \x1b[90mstyle="boreal"  hi-fi(neural)=${evBoreal.hi.toFixed(4)}  lo-fi(LUT)=${evBoreal.lo.toFixed(4)}\x1b[0m`);
// lo-fi is style-blind by construction, so any correct style rendering is a
// win for hi-fi. Require a clear margin, not a rounding difference.
ok('neural pass expresses style the LUT structurally cannot',
  evArid.hi < evArid.lo * 0.9 && evBoreal.hi < evBoreal.lo * 0.9,
  `arid ${((1 - evArid.hi / evArid.lo) * 100).toFixed(0)}% better, boreal ${((1 - evBoreal.hi / evBoreal.lo) * 100).toFixed(0)}% better`);

// The marketplace thesis (roadmap §6.2), tested: same truth, different weights,
// different world — and the save file is untouched.
const truthBeforeStyle = sym.fingerprint();
function meanColor(preset) {
  style.set(N.STYLE_PRESETS[preset]);
  let r = 0, g = 0, b = 0, n = 0;
  const rng = N.mulberry32(21);
  for (let s = 0; s < 1200; s++) {
    N.featuresAt(sym, (rng() * W) | 0, (rng() * H) | 0, fin, style);
    mat.decode(fin, oHi);
    r += oHi[0]; g += oHi[1]; b += oHi[2]; n++;
  }
  return [r / n, g / n, b / n];
}
const cNeon = meanColor('neon'), cMono = meanColor('monochrome');
const styleDelta = Math.hypot(cNeon[0] - cMono[0], cNeon[1] - cMono[1], cNeon[2] - cMono[2]);
console.log(`  \x1b[90mneon   -> rgb(${cNeon.map(v => (v * 255) | 0).join(',')})\x1b[0m`);
console.log(`  \x1b[90mmono   -> rgb(${cMono.map(v => (v * 255) | 0).join(',')})\x1b[0m`);
ok('swapping regional weights visibly changes the world', styleDelta > 0.05,
  `delta=${styleDelta.toFixed(3)}`);
ok('...while world truth stays byte-identical (the save is portable)',
  sym.fingerprint() === truthBeforeStyle);

// lo-fi must be CLOSE to hi-fi, or the progressive swap "pops" and the whole
// latency-hiding strategy is visibly worse than just waiting.
let seAgree = 0, nAgree = 0;
style.set(N.STYLE_PRESETS.vanilla);
{
  const rng = N.mulberry32(31);
  for (let s = 0; s < 3000; s++) {
    N.featuresAt(sym, (rng() * W) | 0, (rng() * H) | 0, fin, style);
    mat.decode(fin, oHi); mat.decodeLoFi(fin, oLo);
    for (let c = 0; c < 3; c++) { seAgree += (oHi[c] - oLo[c]) ** 2; nAgree++; }
  }
}
const agree = Math.sqrt(seAgree / nAgree);
console.log(`  \x1b[90mlo-fi vs hi-fi disagreement: ${(agree * 255).toFixed(1)}/255 (pop severity on swap)\x1b[0m`);
ok('progressive swap is not jarring (lo-fi tracks hi-fi)', agree < 0.12,
  `${(agree * 255).toFixed(1)}/255`);

// the critical safety property: a garbage materializer cannot corrupt truth
mat.net.W[0].fill(999); mat.net.b[0].fill(-999); // "corrupt" the network
mat.decode(fin, oHi);
ok('destroying the neural layer leaves world truth intact', sym.fingerprint() === truthBeforeStyle);
mat.net.W[0].fill(0); // leave it broken on purpose; nothing downstream depends on it

/* ---------------------------------------------------------------- C4 */
hdr('C4 — Hierarchical inference: micro is cheap, macro is budgeted');

const agent = new N.SettlerAgent(1, { cooldown: 8, seed: 3 });
const mt0 = Date.now();
const MICRO_STEPS = 120;
for (let i = 0; i < MICRO_STEPS; i++) sym.microStep(1);
const microMs = (Date.now() - mt0) / MICRO_STEPS;
console.log(`  \x1b[90mmicro: ${microMs.toFixed(2)}ms per world-tick over ${W * H} cells (${(microMs / (W * H) * 1e6).toFixed(2)}µs/cell)\x1b[0m`);
ok('micro tier runs inside a 16.7ms frame budget', microMs < 12, `${microMs.toFixed(2)}ms`);

const mt1 = Date.now();
let macroEvents = 0, macroTokens = 0;
const MACRO_STEPS = 40;
for (let i = 0; i < MACRO_STEPS; i++) {
  const evs = sym.macroStep([agent]);
  macroEvents += evs.length;
  for (const e of evs) macroTokens += e.tokens;
}
const macroMs = Date.now() - mt1;
console.log(`  \x1b[90mmacro: ${macroEvents} decisions, ${macroTokens} tokens total, ${macroMs}ms wall\x1b[0m`);
ok('macro tier produces decisions', macroEvents > 0, `${macroEvents} settlements founded`);
ok('macro tier respects a hard token budget', macroTokens <= agent.tokenBudget * macroEvents,
  `${macroTokens}/${agent.tokenBudget * macroEvents}`);
ok('macro tier is orders of magnitude less frequent than micro', MICRO_STEPS / MACRO_STEPS >= 2,
  `${MICRO_STEPS} micro : ${MACRO_STEPS} macro`);

/* ---------------------------------------------------------------- C5 */
hdr('C5 — Progressive refinement hides latency');

const sched = new N.RefinementScheduler(sym, 16, 10, { bakeMsPerChunk: 90 });
const rect = { x0: 30, y0: 20, x1: 80, y1: 55 };
const touched = sched.invalidate(rect);
ok('edit invalidates only affected chunks', touched.length > 0 && touched.length < sched.cols * sched.rows,
  `${touched.length}/${sched.cols * sched.rows} chunks`);

// frame 0: everything must render immediately at lo-fi
let hifiAtFrame0 = 0;
for (const id of touched) if (sched.state[id] === 2) hifiAtFrame0++;
ok('frame 0 renders instantly at lo-fi (zero blocking)', hifiAtFrame0 === 0);

let frames = 0;
while (sched.queue.length && frames < 600) { sched.tick(16.7); frames++; }
const settleMs = frames * 16.7;
console.log(`  \x1b[90m${touched.length} chunks reached hi-fi in ${frames} frames (${settleMs.toFixed(0)}ms) while remaining interactive\x1b[0m`);
ok('all chunks reach hi-fi', sched.queue.length === 0);
ok('refinement settles in bounded time', settleMs < 3000, `${settleMs.toFixed(0)}ms`);

/* ------------------------------------------------------ Negotiation */
hdr('Negotiation resolver — deterministic, explainable compromise');

const nw = new N.World(W, H, 2024);
const ag = new N.SettlerAgent(9, { cooldown: 1, seed: 11 });
nw.apply(nw.makeIntent('build', { x: 60, y: 40, r: 3, kind: 'settlement', actor: 'agent:9' }));
const resolver = new N.NegotiationResolver();

const grievious = nw.makeIntent('deforest', { x: 61, y: 41, r: 7, amount: 0.95 });
nw.apply(grievious);
const res = resolver.resolve(nw, grievious);
ok('conflict is detected and resolved', res !== null, res ? res.kind : '');
ok('resolution is explainable in prose', !!(res && res.text && res.text.length > 20));
ok('resolution composes concrete symbolic ops', res && res.opsApplied >= 2, `${res && res.opsApplied} ops`);
if (res) console.log(`  \x1b[90m"${res.text}"\x1b[0m`);

// determinism: same conflict -> same resolution
const nw2 = new N.World(W, H, 2024);
nw2.apply(nw2.makeIntent('build', { x: 60, y: 40, r: 3, kind: 'settlement', actor: 'agent:9' }));
const g2 = nw2.makeIntent('deforest', { x: 61, y: 41, r: 7, amount: 0.95 });
nw2.apply(g2);
const res2 = new N.NegotiationResolver().resolve(nw2, g2);
ok('resolution is deterministic (replayable for netcode)', res && res2 && res.kind === res2.kind && res.grievance === res2.grievance);

/* ------------------------------------------------------------ Economics */
hdr('Unit economics — bake heavy / run light vs generate at runtime');

const cm = new N.CostModel();
const corr = cm.corrected(100);
const naiveCost = cm.naive(100);
console.log('  \x1b[90m' + N.CostModel.fmt(corr) + '\x1b[0m');
console.log('  \x1b[90m' + N.CostModel.fmt(naiveCost) + '\x1b[0m');
ok('corrected architecture is at least 10x cheaper', naiveCost.total / corr.total > 10,
  `${(naiveCost.total / corr.total).toFixed(1)}x cheaper`);
ok('corrected architecture is F2P-viable (< $0.05/player-hr)', corr.perPlayerHour < 0.05,
  `${corr.perPlayerHour.toFixed(4)}/player-hr`);
// A F2P server budget is roughly $0.05/player-hr before the margin is gone.
ok('naive architecture blows the F2P server budget (> $0.05/player-hr)',
  naiveCost.perPlayerHour > 0.05,
  `${naiveCost.perPlayerHour.toFixed(2)}/player-hr`);

/* ------------------------------------------------------- Mass conservation */
hdr('Sanity — symbolic micro-sim conserves mass (neural physics cannot guarantee this)');

const cw = new N.World(64, 40, 77);
const before = cw.elevMass();
const TICKS = 400;
for (let i = 0; i < TICKS; i++) cw.microStep(1);
const after = cw.elevMass();
const drift = Math.abs(after - before) / before;
console.log(`  \x1b[90mmass drift over ${TICKS} ticks: ${(drift * 1e4).toFixed(2)}bp  ` +
  `(clip accounting: ${cw.massClip.toFixed(4)})\x1b[0m`);
ok('terrain sim conserves mass over long rollout', drift < 1e-4, `${(drift * 1e4).toFixed(2)} basis points`);
let finite = true;
for (let i = 0; i < cw.ch[N.CH.ELEV].length; i++) if (!isFinite(cw.ch[N.CH.ELEV][i])) finite = false;
ok(`no NaN/Inf after ${TICKS} ticks`, finite);
// and the world still has structure — it did not flatten into mush
const vBefore = (() => { const b = new N.World(64, 40, 77); let m = 0; for (const v of b.ch[N.CH.ELEV]) m += v; m /= b.ch[N.CH.ELEV].length; let s = 0; for (const v of b.ch[N.CH.ELEV]) s += (v - m) ** 2; return Math.sqrt(s / b.ch[N.CH.ELEV].length); })();
let m2 = 0; for (const v of cw.ch[N.CH.ELEV]) m2 += v; m2 /= cw.ch[N.CH.ELEV].length;
let s2 = 0; for (const v of cw.ch[N.CH.ELEV]) s2 += (v - m2) ** 2;
const vAfter = Math.sqrt(s2 / cw.ch[N.CH.ELEV].length);
console.log(`  \x1b[90mterrain relief: before=${vBefore.toFixed(4)} after=${vAfter.toFixed(4)}\x1b[0m`);
ok('relief is preserved (no slow collapse to a flat plane)', vAfter > vBefore * 0.35);

/* ------------------------------------------------------------------ */
console.log(`\n\x1b[1m${pass} passed, ${fail} failed\x1b[0m\n`);
process.exit(fail ? 1 : 0);
