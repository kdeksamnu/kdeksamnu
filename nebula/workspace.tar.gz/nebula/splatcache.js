/* ============================================================================
   PROJECT NEBULA — Client-Side Neural Splat Caching & Distribution Layer
   ----------------------------------------------------------------------------
   This is the layer that sits between the bake farm and the player's GPU.
   It exists because "pre-bake chunks and decode them on the client" is the
   easy half. The hard half is:

     1. VERSIONING      — a chunk's appearance is a function of (symbolic truth,
                          style weights, LOD). Change any one and the old bytes
                          are wrong. Content-addressing makes correctness free.
     2. INVALIDATION    — when player A edits a chunk, every client holding a
                          cached bake of it is now stale. Bounded how?
     3. EGRESS          — "zero runtime server cost" is false. Splats are bytes,
                          bytes cross a network, and networks are billed.
     4. DEVICE FLOOR    — the weakest supported GPU sets the LOD you must be
                          able to fall back to, and that fallback must never
                          require a download.

   Design rule inherited from the kernel: this layer distributes APPEARANCE.
   Truth travels on its own small, authoritative, always-current stream. A
   client may render anything it likes; it may never ASSERT anything.
   ============================================================================ */
(function (root) {
  'use strict';

  /* ==========================================================================
     0. Byte budgets — the numbers that decide feasibility
     --------------------------------------------------------------------------
     These are the assumptions every cost figure downstream depends on. They
     are deliberately exposed and overridable: the single most valuable thing
     you can do for this project is replace them with MEASURED values from one
     real baked chunk. Until then they are honest estimates, clearly labelled.

     Reference points (2026):
       - 3DGS chunk, ~50k gaussians, raw            ~3.0 MB
       - same, compressed (half-float + quantized)  ~1.0-1.5 MB
       - LOD1 proxy (low gaussian count / impostor) ~150-250 KB
       - symbolic channels for a 64x64x6 chunk      ~48 KB raw, ~6-10 KB zstd
     ====================================================================== */

  const DEFAULT_BUDGET = {
    lod0Bytes: 1.20e6,   // full splat bake
    lod1Bytes: 0.18e6,   // proxy bake
    lod2Bytes: 0,        // procedural: derived from the truth stream, no extra bytes
    truthChunkBytes: 8e3,   // compressed symbolic channels, first fetch
    truthEditBytes: 220,    // per-edit delta broadcast (intent, not pixels)
    clientCacheBytes: 256e6, // IndexedDB budget (browser storage is not infinite)
    persistentAcrossSessions: true
  };

  const CDN = {
    egressPerGB: 0.085,     // $/GB to internet, blended mid-tier 2026
    originFetchPerGB: 0.02, // origin -> edge
    putsPerGB: 0.005        // bake farm -> origin
  };

  const LOD = { SPLAT: 0, PROXY: 1, PROCEDURAL: 2 };

  /** What one full chunk bake costs in GPU-seconds and dollars. */
  const BAKE = { gpuSecPerChunk: 45, gpuHourPrice: 2.50 };
  BAKE.costPerBake = BAKE.gpuSecPerChunk / 3600 * BAKE.gpuHourPrice;

  /**
   * How many full bakes per player-hour a given budget allows.
   * This is the number that decides the whole business, and it is small:
   * at $0.05/player-hr for 100 players it is 1.6 bakes. A worldbuilding game
   * generates 30-300 edits per player-hour, so live edits CANNOT each earn a
   * bake. Bakes are for settled content; in-flight edits render procedurally.
   */
  function bakesAffordable(targetPerPlayerHour, players = 100) {
    return targetPerPlayerHour * players / BAKE.costPerBake / players;
  }

  function bytesForLOD(lod, budget) {
    const b = budget || DEFAULT_BUDGET;
    return lod === LOD.SPLAT ? b.lod0Bytes
      : lod === LOD.PROXY ? b.lod1Bytes
        : b.lod2Bytes;
  }

  /* ==========================================================================
     1. Content addressing
     --------------------------------------------------------------------------
     The key insight that makes this whole layer safe:

       chunk key = f(position, truthVersion, styleHash, lod)

     An edit does NOT mutate a cached blob. It produces a NEW key. The old blob
     becomes unreachable garbage rather than incorrect data. That means:

       - a client can never render a chunk that disagrees with the truth it
         holds, because the key is derived from the truth version;
       - cache invalidation stops being a correctness problem and becomes only
         a STALENESS problem — bounded by how fast the version feed arrives;
       - two players requesting the same chunk at the same version hit the same
         CDN object, so edge caching deduplicates origin egress for free.

     This is the single most important property in the file.
     ====================================================================== */

  function chunkKey(cx, cy, truthVersion, styleHash, lod) {
    return `${cx},${cy}|v${truthVersion}|s${styleHash}|L${lod}`;
  }

  /** Coarse hash of a style code, so swapping regional weights invalidates. */
  function styleHashOf(styleArr) {
    let h = 0x811c9dc5;
    for (let i = 0; i < styleArr.length; i++) {
      const q = Math.round(styleArr[i] * 4096); // quantize: near-identical packs share a hash
      h ^= q & 0xff; h = Math.imul(h, 0x01000193);
      h ^= (q >>> 8) & 0xff; h = Math.imul(h, 0x01000193);
    }
    return (h >>> 0).toString(36);
  }

  /* ==========================================================================
     2. Bake store — the origin + CDN edge
     ====================================================================== */

  class BakeStore {
    constructor(budget = DEFAULT_BUDGET, cdn = CDN) {
      this.budget = budget; this.cdn = cdn;
      this.objects = new Map();   // key -> { bytes, lod, bakedAt }
      this.edge = new Set();      // keys currently warm at the edge
      this.edgeCapacity = 40e9;   // 40 GB of edge, LRU-ish by insertion for the model
      this.stats = {
        puts: 0, putBytes: 0,
        edgeHits: 0, originFetches: 0, originBytes: 0,
        misses: 0            // requested a bake that was never made
      };
    }

    /** The bake farm uploads here. Paid once per (chunk, version, style, lod). */
    put(key, lod, bakedAt = 0) {
      const bytes = bytesForLOD(lod, this.budget);
      if (!this.objects.has(key)) {
        this.stats.puts++;
        this.stats.putBytes += bytes;
      }
      this.objects.set(key, { bytes, lod, bakedAt });
      return bytes;
    }

    /** Client requests a bake. Edge hit = cheap; origin fetch = pricier. */
    get(key) {
      const obj = this.objects.get(key);
      if (!obj) { this.stats.misses++; return null; }
      if (this.edge.has(key)) {
        this.stats.edgeHits++;
        return obj;
      }
      this.stats.originFetches++;
      this.stats.originBytes += obj.bytes;
      this.edge.add(key);
      return obj;
    }

    /** Egress billed to the operator: bytes delivered to clients + origin pulls. */
    egressCost(clientBytes) {
      return clientBytes / 1e9 * this.cdn.egressPerGB
        + this.stats.originBytes / 1e9 * this.cdn.originFetchPerGB
        + this.stats.putBytes / 1e9 * this.cdn.putsPerGB;
    }

    get uniqueObjects() { return this.objects.size; }
    get storedBytes() {
      let s = 0; for (const o of this.objects.values()) s += o.bytes; return s;
    }
  }

  /* ==========================================================================
     3. Client cache — LRU under a hard byte budget
     --------------------------------------------------------------------------
     Browser storage is finite and evictable by the OS under pressure. The
     cache must therefore degrade by LOD, never by correctness: if LOD0 does
     not fit, serve LOD1; if that does not fit, fall back to LOD2 procedural,
     which costs zero bytes and is always available because the truth stream
     is already resident.
     ====================================================================== */

  class ClientCache {
    constructor(store, opts = {}) {
      this.store = store;
      this.budgetBytes = opts.budgetBytes ?? DEFAULT_BUDGET.clientCacheBytes;
      this.rttMs = opts.rttMs ?? 90;             // edge latency
      this.throughputMBps = opts.throughputMBps ?? 12; // realistic mobile-ish
      this.entries = new Map();                  // key -> { bytes, lod, lastUse }
      this.byPos = new Map();                    // "cx,cy" -> Set<key>, for O(1) invalidation
      this.truthSeen = new Set();                // "cx,cy|v" truth already held
      this.clock = 0;
      this.stats = {
        requests: 0, hits: 0, misses: 0,
        bytesDownloaded: 0, msWaiting: 0,
        evictions: 0, bytesEvicted: 0,
        lodDowngrades: 0, proceduralFallbacks: 0
      };
      this.pending = new Map();                  // key -> resolve time (in-flight)
    }

    get usedBytes() { let s = 0; for (const e of this.entries.values()) s += e.bytes; return s; }

    /** Evict least-recently-used until `need` bytes fit. */
    _makeRoom(need) {
      if (this.usedBytes + need <= this.budgetBytes) return;
      const order = [...this.entries.entries()].sort((a, b) => a[1].lastUse - b[1].lastUse);
      for (const [k, e] of order) {
        if (this.usedBytes + need <= this.budgetBytes) break;
        this._drop(k, e);
        this.stats.evictions++;
        this.stats.bytesEvicted += e.bytes;
      }
    }

    /**
     * Request a chunk at a given LOD. Returns what was actually served, which
     * may be a lower LOD than requested if the budget or the store says no.
     *
     * The fallback ladder is the device-floor guarantee: LOD2 always succeeds,
     * because it needs no download at all.
     */
    request(cx, cy, truthVersion, styleHash, wantLOD = LOD.SPLAT) {
      this.stats.requests++;
      for (let lod = wantLOD; lod <= LOD.PROCEDURAL; lod++) {
        const key = chunkKey(cx, cy, truthVersion, styleHash, lod);
        const cached = this.entries.get(key);
        if (cached) {
          cached.lastUse = ++this.clock;
          this.stats.hits++;
          return { served: lod, key, bytes: 0, ms: 0, fromCache: true };
        }
        if (lod === LOD.PROCEDURAL) {
          // No bytes, no latency, no dependency on the bake farm.
          this.stats.proceduralFallbacks++;
          this.stats.misses++;
          return { served: LOD.PROCEDURAL, key, bytes: 0, ms: 0, fromCache: false, procedural: true };
        }
        const obj = this.store.get(key);
        if (!obj) {
          // Not baked yet. Downgrade and try again — this is what happens in
          // the first seconds after a player edits virgin terrain.
          this.stats.lodDowngrades++;
          continue;
        }
        this._makeRoom(obj.bytes);
        const ms = this.rttMs + (obj.bytes / 1e6) / this.throughputMBps * 1000;
        this._insert(key, `${cx},${cy}`, obj.bytes, lod);
        this.stats.misses++;
        this.stats.bytesDownloaded += obj.bytes;
        this.stats.msWaiting += ms;
        if (lod !== wantLOD) this.stats.lodDowngrades++;
        return { served: lod, key, bytes: obj.bytes, ms, fromCache: false };
      }
    }

    _insert(key, pos, bytes, lod) {
      this.entries.set(key, { bytes, lod, lastUse: ++this.clock });
      let set = this.byPos.get(pos);
      if (!set) { set = new Set(); this.byPos.set(pos, set); }
      set.add(key);
    }

    _drop(key, entry) {
      this.entries.delete(key);
      const pos = key.split('|')[0];
      const set = this.byPos.get(pos);
      if (set) { set.delete(key); if (!set.size) this.byPos.delete(pos); }
    }

    /**
     * Truth-stream invalidation: drop every cached version of this chunk
     * position. Deliberately over-evicts across versions and style packs —
     * that costs a refetch but can never serve stale appearance as current.
     * O(1) in the number of cached versions, not O(cache size).
     */
    invalidatePosition(cx, cy) {
      const pos = `${cx},${cy}`;
      const set = this.byPos.get(pos);
      if (!set || !set.size) return 0;
      let n = 0;
      for (const k of [...set]) { this._drop(k, this.entries.get(k)); n++; }
      return n;
    }

    /** Does this client already hold the truth for (chunk, version)?
     *  Used to charge the truth stream exactly once per version per client. */
    needsTruth(cx, cy, version) {
      const k = `${cx},${cy}|${version}`;
      if (this.truthSeen.has(k)) return false;
      this.truthSeen.add(k);
      return true;
    }
  }

  /* ==========================================================================
     4. Version feed — bounding staleness
     --------------------------------------------------------------------------
     When player A commits an intent that dirties chunk C, the authority bumps
     C's truth version and broadcasts it. Every client that has C cached is now
     stale by exactly one broadcast hop.

     The staleness window is the ONLY thing separating "co-op worldbuilding"
     from "everyone sees a different world". It is a product requirement, not
     an implementation detail, and it must be measured.
     ====================================================================== */

  class VersionFeed {
    constructor(opts = {}) {
      this.broadcastMs = opts.broadcastMs ?? 120;  // authority -> all subscribed clients
      this.versions = new Map();                   // "cx,cy" -> version
      this.stats = { broadcasts: 0, chunksDirty: 0, stalenessMsTotal: 0, stalenessSamples: 0 };
    }

    versionOf(cx, cy) { return this.versions.get(`${cx},${cy}`) || 0; }

    /** Called by the authority when an intent dirties a chunk. */
    bump(cx, cy) {
      const k = `${cx},${cy}`;
      const v = (this.versions.get(k) || 0) + 1;
      this.versions.set(k, v);
      this.stats.broadcasts++;
      this.stats.chunksDirty++;
      return v;
    }

    /** Record how long a client sat on a stale bake. */
    observeStaleness(ms) {
      this.stats.stalenessMsTotal += ms;
      this.stats.stalenessSamples++;
    }

    get meanStalenessMs() {
      return this.stats.stalenessSamples
        ? this.stats.stalenessMsTotal / this.stats.stalenessSamples : 0;
    }
  }

  /* ==========================================================================
     5. Distribution model — what it actually costs
     --------------------------------------------------------------------------
     Simulates a shard: N concurrent players, each traversing and editing,
     with a shared bake store and a shared version feed. Produces the numbers
     that decide whether "client-side splat caching" is a business or a hobby.
     ====================================================================== */

  class DistributionModel {
    constructor(opts = {}) {
      this.budget = Object.assign({}, DEFAULT_BUDGET, opts.budget || {});
      this.cdn = Object.assign({}, CDN, opts.cdn || {});
      this.store = new BakeStore(this.budget, this.cdn);
      this.feed = new VersionFeed(opts);
      this.chunksBaked = new Set();
    }

    /** Bake farm produces a chunk. Cost is paid once per unique key. */
    bake(cx, cy, version, styleHash, lod = LOD.SPLAT) {
      const key = chunkKey(cx, cy, version, styleHash, lod);
      if (!this.chunksBaked.has(key)) {
        this.chunksBaked.add(key);
        this.store.put(key, lod);
      }
      return key;
    }

    /**
     * Run one shard-hour.
     * @param players        concurrent players
     * @param chunksPerPlayer chunks a player touches per hour (traversal + edits)
     * @param editsPerHour   global edit rate for the shard
     * @param returning      fraction of players with a warm persistent cache
     * @param lodMix         what share of requests want LOD0 vs LOD1
     */
    /**
     * Time-stepped shard-hour. One tick per simulated second.
     *
     * Interleaving matters: an earlier version of this model applied every edit
     * before any traversal, which meant invalidation never hit a warm cache and
     * the persistent-cache benefit read as ~4%. That was a simulation artifact,
     * not a property of the architecture. Order of operations is not a detail
     * in a cost model — it is the result.
     *
     * @param quiescenceSec  how long a chunk must be unedited before it gets a
     *   full splat bake. While hot, clients render it procedurally (LOD2, zero
     *   bytes) from truth they already hold. This is the single most important
     *   tuning knob in a worldbuilding game, because edits are what destroy
     *   cache locality — a consumption game can cache for days, a game where
     *   everyone is constantly rewriting the world cannot.
     * @param bakeImmediately  disable quiescence gating (bake on every edit) for
     *   A/B comparison.
     */
    runHour({ players = 100, chunksPerPlayer = 240, editsPerHour = 900,
              returning = 0.6, lodMix = { [LOD.SPLAT]: 0.8, [LOD.PROXY]: 0.2 },
              styleHash = 'vanilla', uniqueChunks = 900,
              deviceMix = { desktop: 0.55, mobile: 0.45 },
              quiescenceSec = 45, bakeImmediately = false, ticks = 3600,
              bakeQuotaPerPlayer = Infinity, homeBias = 0, homeRadius = 6 } = {}) {

      const rng = mulberry32(0xC0FFEE);
      const side = Math.ceil(Math.sqrt(uniqueChunks));
      const pos = (cx, cy) => `${cx},${cy}`;

      const TIERS = {
        desktop: { budget: 2.0e9, rtt: [40, 110], mbps: [25, 90], wantLOD0: lodMix[LOD.SPLAT] ?? 0.8 },
        mobile:  { budget: 0.25e9, rtt: [90, 260], mbps: [3, 18], wantLOD0: Math.min(0.45, lodMix[LOD.SPLAT] ?? 0.8) }
      };

      // --- vanilla world set, baked up front
      for (let i = 0; i < uniqueChunks; i++) {
        const cx = i % side, cy = (i / side) | 0;
        this.bake(cx, cy, 0, styleHash, LOD.SPLAT);
        this.bake(cx, cy, 0, styleHash, LOD.PROXY);
      }

      // --- clients
      const pick = a => a[0] + rng() * (a[1] - a[0]);
      const caches = [];
      for (let p = 0; p < players; p++) {
        const tierName = rng() < (deviceMix.desktop ?? 0.55) ? 'desktop' : 'mobile';
        const t = TIERS[tierName];
        const c = new ClientCache(this.store, {
          budgetBytes: t.budget, rttMs: pick(t.rtt), throughputMBps: pick(t.mbps)
        });
        c.tier = tierName; c.wantLOD0 = t.wantLOD0;
        c.cx = (rng() * side) | 0; c.cy = (rng() * side) | 0;
        // `homeBias` is a GAME DESIGN parameter with a direct infra cost:
        // players who return to a home region re-hit their warm cache, so the
        // same persistent-cache code saves 13% for wanderers and far more for
        // settlers. Whether your game has home bases changes the CDN bill.
        c.hx = c.cx; c.hy = c.cy;
        c.here = pos(c.cx, c.cy);
        c.lastVersion = -1;
        c.pid = p;
        if (rng() < returning && this.budget.persistentAcrossSessions) {
          // Warm cache from a previous session, clustered around where they play.
          let wx = c.cx, wy = c.cy;
          const warm = Math.floor(chunksPerPlayer * 0.9);
          for (let i = 0; i < warm; i++) {
            if (rng() < homeBias) {
              wx = (c.hx + ((rng() * (homeRadius * 2 + 1)) | 0) - homeRadius + side) % side;
              wy = (c.hy + ((rng() * (homeRadius * 2 + 1)) | 0) - homeRadius + side) % side;
            } else {
              wx = (wx + ((rng() * 3) | 0) - 1 + side) % side;
              wy = (wy + ((rng() * 3) | 0) - 1 + side) % side;
            }
            const want = rng() < c.wantLOD0 ? LOD.SPLAT : LOD.PROXY;
            const key = chunkKey(wx, wy, 0, styleHash, want);
            const obj = this.store.objects.get(key);
            if (obj && c.usedBytes + obj.bytes <= c.budgetBytes) {
              c._insert(key, pos(wx, wy), obj.bytes, obj.lod);
              c.truthSeen.add(`${pos(wx, wy)}|0`);
            }
          }
        }
        caches.push(c);
      }

      // --- world mutation state
      const lastEdit = new Map();     // pos -> tick of most recent edit
      const pendingBake = new Map();  // pos -> { v, readyTick }
      const versions = this.feed.versions;

      const moveProb = chunksPerPlayer / ticks;
      const editProb = editsPerHour / players / ticks;

      let invalidations = 0, hotServed = 0, truthBytes = 0, truthFetches = 0, bakesScheduled = 0;
      let bakesGranted = 0, bakesRefused = 0;
      // Per-player bake quota. This is the governor that makes the economics
      // close: a full splat bake costs real GPU money, and in a worldbuilding
      // game editing IS the gameplay, so bake demand scales with player
      // activity rather than with world size. Without a quota, cost is
      // unbounded in exactly the dimension the player is encouraged to push.
      const quota = new Map();
      let servedL0 = 0, servedL1 = 0, servedL2 = 0;

      // Single gate for every bake, so the immediate and quiescent paths are
      // priced identically. An earlier version only budgeted the quiescent
      // path, which made "bake immediately" look free and inverted the result.
      const tryBake = (cx, cy, v, owner) => {
        const used = quota.get(owner) || 0;
        if (used >= bakeQuotaPerPlayer) { bakesRefused++; return false; }
        quota.set(owner, used + 1);
        bakesGranted++;
        this.bake(cx, cy, v, styleHash, LOD.SPLAT);
        this.bake(cx, cy, v, styleHash, LOD.PROXY);
        return true;
      };

      const doRequest = (c, tick) => {
        const v = this.feed.versionOf(c.cx, c.cy);
        const le = lastEdit.get(c.here);
        const hot = le !== undefined && (tick - le) < quiescenceSec;
        // While a chunk is hot, do not pay for a splat that is about to be
        // wrong. Render it procedurally from truth the client already holds.
        const want = hot ? LOD.PROCEDURAL : (rng() < c.wantLOD0 ? LOD.SPLAT : LOD.PROXY);
        if (hot) hotServed++;
        const r = c.request(c.cx, c.cy, v, styleHash, want);
        if (r.served === LOD.SPLAT) servedL0++;
        else if (r.served === LOD.PROXY) servedL1++;
        else servedL2++;
        if (c.needsTruth(c.cx, c.cy, v)) { truthBytes += this.budget.truthChunkBytes; truthFetches++; }
        c.lastVersion = v;
        return r;
      };

      for (let tick = 0; tick < ticks; tick++) {
        // 1. bakes that have gone quiet — subject to the editor's quota
        for (const [p, info] of [...pendingBake]) {
          if (info.readyTick > tick) continue;
          // Over quota the chunk stays procedural: zero GPU, zero egress,
          // still correct and still interactive — just without splat fidelity.
          tryBake(info.cx, info.cy, info.v, info.owner);
          pendingBake.delete(p);
        }

        for (const c of caches) {
          // 2. movement (coherent walk; rare fast-travel; optional home gravity)
          const moved = rng() < moveProb;
          if (moved) {
            if (rng() < 0.03) { c.cx = (rng() * side) | 0; c.cy = (rng() * side) | 0; }
            else if (rng() < homeBias) {
              // orbit the home region instead of wandering the whole shard
              c.cx = (c.hx + ((rng() * (homeRadius * 2 + 1)) | 0) - homeRadius + side) % side;
              c.cy = (c.hy + ((rng() * (homeRadius * 2 + 1)) | 0) - homeRadius + side) % side;
            } else {
              c.cx = (c.cx + ((rng() * 3) | 0) - 1 + side) % side;
              c.cy = (c.cy + ((rng() * 3) | 0) - 1 + side) % side;
            }
            const np = pos(c.cx, c.cy);
            if (np !== c.here) { c.here = np; c.lastVersion = -1; }
          }

          // 3. editing, near where the player is
          if (rng() < editProb) {
            const ex = (c.cx + ((rng() * 5) | 0) - 2 + side) % side;
            const ey = (c.cy + ((rng() * 5) | 0) - 2 + side) % side;
            const ep = pos(ex, ey);
            const v = this.feed.bump(ex, ey);
            lastEdit.set(ep, tick);
            bakesScheduled++;
            if (bakeImmediately) {
              tryBake(ex, ey, v, c.pid);
            } else {
              pendingBake.set(ep, { cx: ex, cy: ey, v, owner: c.pid, readyTick: tick + quiescenceSec });
            }
            // Fan-out invalidation: O(clients that actually hold it).
            for (const o of caches) invalidations += o.invalidatePosition(ex, ey);
            this.feed.observeStaleness(this.feed.broadcastMs * (0.5 + rng()));
          }

          // 4. request on entry, or when the chunk underfoot changed version
          const curV = this.feed.versionOf(c.cx, c.cy);
          if (moved || curV !== c.lastVersion) doRequest(c, tick);
        }
      }
      // flush any bakes still pending at the end of the hour (still budgeted)
      for (const [, info] of pendingBake) tryBake(info.cx, info.cy, info.v, info.owner);
      truthBytes += editsPerHour * this.budget.truthEditBytes * players;

      // --- aggregate
      let downloaded = 0, hits = 0, reqs = 0, waitMs = 0, proc = 0, downgrades = 0, evictions = 0;
      const perTier = {};
      for (const c of caches) {
        downloaded += c.stats.bytesDownloaded;
        hits += c.stats.hits; reqs += c.stats.requests;
        waitMs += c.stats.msWaiting;
        proc += c.stats.proceduralFallbacks;
        downgrades += c.stats.lodDowngrades;
        evictions += c.stats.evictions;
        const t = perTier[c.tier] || (perTier[c.tier] = { reqs: 0, hits: 0, bytes: 0, evictions: 0, n: 0 });
        t.reqs += c.stats.requests; t.hits += c.stats.hits;
        t.bytes += c.stats.bytesDownloaded; t.evictions += c.stats.evictions; t.n++;
      }
      for (const t of Object.values(perTier)) t.hitRate = t.reqs ? t.hits / t.reqs : 0;

      const cost = {
        clientEgress: downloaded / 1e9 * this.cdn.egressPerGB,
        originPull: this.store.stats.originBytes / 1e9 * this.cdn.originFetchPerGB,
        bakeUpload: this.store.stats.putBytes / 1e9 * this.cdn.putsPerGB,
        truthStream: truthBytes / 1e9 * this.cdn.egressPerGB
      };
      cost.total = cost.clientEgress + cost.originPull + cost.bakeUpload + cost.truthStream;

      return {
        players, hours: 1, ticks,
        requests: reqs, cacheHits: hits,
        hitRate: reqs ? hits / reqs : 0,
        bytesToClients: downloaded,
        mbPerPlayerSession: downloaded / players / 1e6,
        uniqueObjects: this.store.uniqueObjects,
        storedGB: this.store.storedBytes / 1e9,
        meanWaitMs: (reqs - hits) ? waitMs / (reqs - hits) : 0,
        proceduralFallbacks: proc, hotServed, lodDowngrades: downgrades,
        evictions, invalidations, bakesScheduled, bakesGranted, bakesRefused,
        bakesPerPlayerHour: bakesGranted / players,
        bakeCost: bakesGranted * BAKE.costPerBake,
        quotaRefusalRate: bakesScheduled ? bakesRefused / bakesScheduled : 0,
        servedL0, servedL1, servedL2,
        // fraction of chunk-visits that got real baked splat fidelity
        splatCoverage: (servedL0 + servedL1 + servedL2) ? servedL0 / (servedL0 + servedL1 + servedL2) : 0,
        meanStalenessMs: this.feed.meanStalenessMs,
        truthStreamMB: truthBytes / 1e6, truthFetches,
        perTier, cost,
        costPerPlayerHour: cost.total / players,
        pixelStreamingCostPerPlayerHour: 0.55
      };
    }
  }

  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ==========================================================================
     exports
     ====================================================================== */

  const SPLAT = {
    LOD, DEFAULT_BUDGET, CDN, BAKE, bytesForLOD, bakesAffordable,
    chunkKey, styleHashOf,
    BakeStore, ClientCache, VersionFeed, DistributionModel,
    mulberry32
  };

  root.NEBULA_SPLAT = SPLAT;
  if (typeof module !== 'undefined' && module.exports) module.exports = SPLAT;

})(typeof globalThis !== 'undefined' ? globalThis : this);
