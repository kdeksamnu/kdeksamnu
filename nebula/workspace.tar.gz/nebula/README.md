# Project NEBULA — MLAOS Worldbuilding Prototype

A working prototype of the corrected architecture, plus the negative control.

**Read `ARCHITECTURE.md` first.** This README is just how to run things.

---

## Quick start

```bash
cd nebula
node test_core.js         # 44 assertions: kernel, composition, materializer, economics  (~7 s)
node test_splatcache.js   # 39 assertions: distribution layer, bake-cost frontier        (~8 s)
node bench.js             # native performance numbers                                   (~8 s)
node harness.js           # headless demo run, drives every probe            (~45 s, VM overhead)
```

190 assertions total across eight suites:

| suite | assertions | covers |
|---|---|---|
| `test_core.js` | 44 | kernel, composition algebra, materializer, hierarchy, economics |
| `test_splatcache.js` | 39 | content addressing, CDN, device tiers, bake-cost frontier |
| `sprint_review.js` | 23 | executable verification of the 5-sprint plan → `SPRINT_REVIEW.md` |
| `orch/verify_orchestrator.py` | 31 | the submitted integrated runtime → `ARCHITECTURE.md` §5c |
| `bake/verify_harness.py` | 7 | the submitted 256³ voxel harness → `ARCHITECTURE.md` §5d |
| `test_splat_emit.js` | 21 | gaussian emitter: determinism, layer placement, wire round-trip |
| `cam_test.js` | 14 | camera math used by the viewer |
| `sort_test.js` | 11 | depth radix sort used for splat blend order |

`ARCHITECTURE.md` §5 and §5b carry the cost analysis, including a correction to an earlier
figure in that same document. `sprint_review.js` has no Rust/CUDA/Postgres toolchain available,
so it ports the three quantitatively checkable subsystems to JS and runs them; every number in
`SPRINT_REVIEW.md` is measured rather than estimated.

### The thing that answers the open question

Open **`nebula-viewer.html`** — a WebGL2 splat viewer, self-contained, no server.
It emits gaussians from symbolic truth in your browser and renders them. That is
the whole §5c path A pipeline, live. Drag to orbit, scroll to zoom, push `density`
up and watch fidelity arrive. `download .splat` writes a real artifact; `load a
.splat file` reads one back through the identical path.

### The rest

Then open **`nebula-standalone.html`** in Chrome or Edge — a single self-contained file, no
dependencies, no network, works from `file://`, a USB stick, or a sandboxed preview.

`demo.html` is the same thing but loads `core.js` separately, so the kernel stays a single
source of truth shared with the tests. Rebuild the bundle after editing either file:

```bash
node build.js
```

First load spends ~3.5 s baking the neural materializer. That is deliberate — it is the
"bake heavy, run light" argument happening in front of you, with an honest progress bar.

---

## What the three panels are

| Panel | What it shows |
|---|---|
| **Neural Canvas** | The corrected architecture. Symbolic truth underneath, neural materializer on top, chunk-level progressive refinement. Amber squares are chunks still baking; the blue bar is bake progress. |
| **Symbolic Truth** | The source of truth, raw. Switch channels to inspect elevation, moisture, rock, vegetation, structure, water. Pink pixels are settlements — discrete, attributable facts. |
| **Latent-as-Truth** | The original roadmap's §4.2, "consensus via vector averaging", implemented faithfully and fed **the identical intent stream**. This is a control group, not a strawman. |

---

## Things worth doing in the demo

**Drag with the river tool across a mountain.** Watch a canyon form in the left panel. Watch the
right panel produce neither a river nor a mountain.

**Press ⛰ conflict test.** Player A raises a mountain, Player B carves a river through the same
cells. The log prints the outcome in both worlds — last run was **89 canyon cells vs 0**.

**Press ↻ redeliver all events.** Simulates an at-least-once broker. The symbolic fingerprint
stays identical; all 24 latent planes drift permanently. Kafka does this in production daily.

**Press ⟲ replay from log.** Rebuilds the world from the event stream alone and compares
fingerprints. It also replays *without* the interleaved simulation, so you can see the desync
that the regression test now guards against.

**Swap regional weights** (style dropdown). Appearance re-bakes; the fingerprint does not move.
That is §6.2's marketplace thesis falling out of the architecture for free.

**Clear forest next to a settlement.** Triggers the negotiation resolver. Read the log — the
compromise is composed of concrete symbolic operations and narrated in prose, not sampled from
a distribution.

**Switch the truth panel to `elevation` and hit `reset`, then watch it erode.** Mass drift in the
HUD should stay at ~0.00 ppm. That readout is the argument against neural physics.

---

## Layout

```
nebula/
├── ARCHITECTURE.md        the corrected spec, with measured evidence   ← read this
├── README.md              this file
├── core.js                the kernel; dependency-free, Node + browser
├── test_core.js           44 assertions across C1–C5 + economics
├── splat_emit.js          procedural gaussian emission from symbolic truth (§5c path A)
├── viewer.html            WebGL2 splat viewer (loads core.js + splat_emit.js)
├── nebula-viewer.html     viewer + kernel + emitter bundled — open this one
├── test_splat_emit.js     21 assertions on the emitter
├── cam_test.js            14 assertions on the camera math
├── sort_test.js           11 assertions on the depth radix sort
├── splatcache.js          client-side splat caching, CDN model, bake governor
├── test_splatcache.js     39 assertions on the distribution layer
├── SPRINT_REVIEW.md       review of the 5-sprint latent-substrate plan
├── sprint_review.js       executable verification behind that review (23 assertions)
├── demo.html              interactive Neural Canvas + latent control (loads core.js)
├── nebula-standalone.html demo + core.js bundled into one file — open this
├── build.js               regenerates the standalone bundle
├── harness.js             headless DOM/canvas harness; drives every demo probe
└── bench.js               native perf numbers
```

`core.js` is organised by architectural claim:

| Section | Claim |
|---|---|
| 0. Deterministic primitives | seeded RNG, value noise, stable hash, state fingerprint |
| 1. `MLP` | tiny net with explicit backprop, Adam, optional leaky activation |
| 2. `World` | symbolic truth: channels, intents, micro/macro tiers |
| 3. `OPS` | the composition algebra — the replacement for vector averaging |
| 4. `LatentWorld` | the negative control (§4.2 verbatim) |
| 5. `Materializer` | two-tower conditional decoder; appearance as cache |
| 6. `RefinementScheduler` | chunk cache + progressive refinement |
| 7. `SettlerAgent`, `NegotiationResolver` | macro tier, budgeted and explainable |
| 8. `CostModel` | unit economics for both architectures |

`splatcache.js` covers the distribution layer:

| Section | What it establishes |
|---|---|
| Byte budgets | the assumptions every cost figure rests on — replace with measured values |
| Content addressing | `key = f(position, truthVersion, styleHash, lod)`: stale renders become impossible by construction |
| `BakeStore` | origin + CDN edge, with dedup so a shared world is fetched once |
| `ClientCache` | LRU under a hard byte budget, with an LOD ladder that degrades fidelity but never correctness |
| `VersionFeed` | bounds staleness to one broadcast hop instead of a cache TTL |
| `DistributionModel` | time-stepped shard-hour: movement, editing, invalidation, quiescence-gated baking, quota |
| `bakesAffordable` | the number that decides the business: ~1.6 bakes/player-hr at a $0.05 ceiling |

---

## Notes on the harness

`harness.js` runs the demo's inline script inside a Node `vm` context against a stub DOM and
canvas. It exists because untested UI code is how prototypes die quietly.

It earned its keep: it caught the interleaved-replay desync that `test_core.js` did not cover,
because that bug only appears once micro-simulation and authored edits are actually interleaved
in a live session. It is now a permanent regression test.

The ~45 s runtime is cross-realm `vm` overhead on typed-array math, not the demo's real speed.
Native numbers are in `bench.js`; a browser lands close to those.

It can target either file:

```bash
node harness.js                        # demo.html + external core.js
node harness.js nebula-standalone.html # the bundle, verified self-contained
```

---

## Known limits of the prototype

Deliberately simplified, so the architecture is visible without noise:

- 2D heightfield, not 3D. The channel model and intent algebra carry over unchanged.
- The macro tier is a utility function, not an LLM. Same position in the hierarchy, same token
  budget discipline — swapping in a real model does not change the architecture.
- The materializer is a 3,896-param two-tower MLP, not a splat decoder or SIREN. It stands in for
  one; what matters is its *position* (consumes features, emits appearance, never emits state).
- The latent control uses a fixed pseudo-random embedding basis and a ridge-regression decoder,
  not a learned VAE. It is a faithful model of *averaging* behaviour, which is the claim under
  test. A learned encoder would degrade the same way, for the same reason.
- Single process, no networking. CRDT properties (idempotency, order tolerance) are tested
  directly rather than over a wire.
