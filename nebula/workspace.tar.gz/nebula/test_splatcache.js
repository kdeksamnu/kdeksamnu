/* Client-side splat caching: assertions + the numbers that decide feasibility.
   Run: node nebula/test_splatcache.js                                      */

const S = require('./splatcache.js');

let pass = 0, fail = 0;
function ok(name, cond, detail = '') {
  if (cond) { pass++; console.log(`  \x1b[32mPASS\x1b[0m  ${name}${detail ? '  \x1b[90m' + detail + '\x1b[0m' : ''}`); }
  else { fail++; console.log(`  \x1b[31mFAIL\x1b[0m  ${name}  ${detail}`); }
}
function hdr(s) { console.log(`\n\x1b[1m${s}\x1b[0m`); }
const fmtMB = b => (b / 1e6).toFixed(1) + ' MB';

/* ------------------------------------------------- 1. content addressing */
hdr('1 — Content addressing makes stale renders impossible');

const store = new S.BakeStore();
const style = S.styleHashOf([0.5, 0.5, 0.25, 0.5]);

store.put(S.chunkKey(3, 4, 0, style, S.LOD.SPLAT), S.LOD.SPLAT);
const cache = new S.ClientCache(store, { budgetBytes: 50e6, rttMs: 80, throughputMBps: 20 });

const r1 = cache.request(3, 4, 0, style, S.LOD.SPLAT);
const r2 = cache.request(3, 4, 0, style, S.LOD.SPLAT);
ok('first request downloads', !r1.fromCache && r1.bytes > 0, fmtMB(r1.bytes));
ok('second request is a cache hit at zero bytes', r2.fromCache && r2.bytes === 0);

// An edit bumps the truth version -> a DIFFERENT key -> the old blob is unreachable.
store.put(S.chunkKey(3, 4, 1, style, S.LOD.SPLAT), S.LOD.SPLAT);
const r3 = cache.request(3, 4, 1, style, S.LOD.SPLAT);
ok('a new truth version produces a new key (never serves the old bake as current)',
  !r3.fromCache && r3.key !== r1.key, `${r1.key} -> ${r3.key}`);
ok('the old blob is now garbage, not incorrect data',
  cache.entries.has(r1.key) && r1.key.includes('|v0|') && r3.key.includes('|v1|'));

// Swapping regional weights must invalidate appearance but not truth.
const style2 = S.styleHashOf([0.86, 0.30, 0.55, 0.66]);
ok('different style code hashes differently', style2 !== style);
store.put(S.chunkKey(3, 4, 1, style2, S.LOD.SPLAT), S.LOD.SPLAT);
const r4 = cache.request(3, 4, 1, style2, S.LOD.SPLAT);
ok('style swap re-fetches appearance (weights are part of the key)', !r4.fromCache);

// Near-identical style packs should share a hash — otherwise every tiny
// tweak re-bakes and re-downloads the entire world.
const styleNear = S.styleHashOf([0.5, 0.5, 0.2501, 0.5]);
ok('near-identical style packs collide to the same hash (no spurious re-bake)',
  styleNear === style, `${style} vs ${styleNear}`);

/* ------------------------------------------------------ 2. device floor */
hdr('2 — The device floor: LOD2 must never require a download');

const emptyStore = new S.BakeStore();       // nothing baked at all
const poorCache = new S.ClientCache(emptyStore, { budgetBytes: 1e6 });
const r5 = poorCache.request(9, 9, 0, style, S.LOD.SPLAT);
ok('with zero bakes available, the client still renders',
  r5.served === S.LOD.PROCEDURAL && r5.bytes === 0 && r5.procedural === true,
  `served LOD${r5.served}, ${r5.bytes} bytes`);

const tight = new S.ClientCache(store, { budgetBytes: S.DEFAULT_BUDGET.lod0Bytes * 1.5 });
let downgraded = 0;
for (let i = 0; i < 40; i++) {
  store.put(S.chunkKey(i, 0, 0, style, S.LOD.SPLAT), S.LOD.SPLAT);
  const rr = tight.request(i, 0, 0, style, S.LOD.SPLAT);
  if (rr.served !== S.LOD.SPLAT) downgraded++;
}
ok('cache never exceeds its byte budget', tight.usedBytes <= tight.budgetBytes + 1,
  `${fmtMB(tight.usedBytes)} of ${fmtMB(tight.budgetBytes)}`);
ok('pressure degrades by LOD, not by correctness',
  tight.stats.evictions > 0 || downgraded > 0,
  `${tight.stats.evictions} evictions, ${downgraded} downgrades`);

/* --------------------------------------------------- 3. edge deduplication */
hdr('3 — Shared world => shared bytes (edge dedup)');

const dedup = new S.BakeStore();
dedup.put(S.chunkKey(1, 1, 0, style, S.LOD.SPLAT), S.LOD.SPLAT);
const clients = [];
for (let p = 0; p < 100; p++) clients.push(new S.ClientCache(dedup, { budgetBytes: 50e6 }));
let clientBytes = 0;
for (const c of clients) clientBytes += c.request(1, 1, 0, style, S.LOD.SPLAT).bytes;
ok('100 clients each download the chunk (egress is real, not zero)',
  clientBytes > 0, `${fmtMB(clientBytes)} to clients`);
ok('...but the origin serves it exactly ONCE (edge dedup)',
  dedup.stats.originFetches === 1, `${dedup.stats.originFetches} origin fetch, ${dedup.stats.edgeHits} edge hits`);

/* --------------------------------------------------------- 4. staleness */
hdr('4 — Staleness is bounded by the version feed');

const feed = new S.VersionFeed({ broadcastMs: 120 });
const v0 = feed.versionOf(5, 5);
const v1 = feed.bump(5, 5);
const v2 = feed.bump(5, 5);
ok('versions increment monotonically per chunk', v0 === 0 && v1 === 1 && v2 === 2);
feed.observeStaleness(120); feed.observeStaleness(60);
ok('mean staleness is one broadcast hop, not a cache TTL',
  feed.meanStalenessMs === 90, `${feed.meanStalenessMs}ms`);

// A client holding a stale bake must not be able to assert it as current.
const sc = new S.ClientCache(dedup, { budgetBytes: 50e6 });
dedup.put(S.chunkKey(5, 5, 0, style, S.LOD.SPLAT), S.LOD.SPLAT);
sc.request(5, 5, 0, style, S.LOD.SPLAT);
const dropped = sc.invalidatePosition(5, 5, style);
ok('position invalidation drops every cached version of that chunk', dropped > 0, `${dropped} entries dropped`);
ok('after invalidation the client cannot serve the stale bake',
  !sc.entries.has(S.chunkKey(5, 5, 0, style, S.LOD.SPLAT)));

/* ------------------------------------------------- 5. the shard-hour model */
hdr('5 — What a shard-hour actually costs (distribution only)');

const model = new S.DistributionModel();
const res = model.runHour({
  players: 100, chunksPerPlayer: 240, editsPerHour: 900,
  returning: 0.6, uniqueChunks: 900, quiescenceSec: 300, bakeQuotaPerPlayer: 1
});

console.log(`  \x1b[90mrequests=${res.requests.toLocaleString()}  hit rate=${(res.hitRate * 100).toFixed(1)}%  splat coverage=${(res.splatCoverage * 100).toFixed(1)}%\x1b[0m`);
console.log(`  \x1b[90megress to clients=${fmtMB(res.bytesToClients)}  (${res.mbPerPlayerSession.toFixed(0)} MB/player-hr)\x1b[0m`);
console.log(`  \x1b[90mLOD served: splat=${res.servedL0.toLocaleString()} proxy=${res.servedL1.toLocaleString()} procedural=${res.servedL2.toLocaleString()}\x1b[0m`);
console.log(`  \x1b[90mmean wait on miss=${res.meanWaitMs.toFixed(0)} ms   mean staleness=${res.meanStalenessMs.toFixed(0)} ms\x1b[0m`);
console.log(`  \x1b[90mtruth stream (unavoidable)=${res.truthStreamMB.toFixed(0)} MB/hr over ${res.truthFetches.toLocaleString()} fetches\x1b[0m`);
console.log('');
console.log(`  \x1b[90m  client splat egress   $${res.cost.clientEgress.toFixed(4)}/hr\x1b[0m`);
console.log(`  \x1b[90m  origin pulls          $${res.cost.originPull.toFixed(4)}/hr\x1b[0m`);
console.log(`  \x1b[90m  bake uploads          $${res.cost.bakeUpload.toFixed(4)}/hr\x1b[0m`);
console.log(`  \x1b[90m  truth stream          $${res.cost.truthStream.toFixed(4)}/hr\x1b[0m`);
console.log(`  \x1b[1m  TOTAL distribution    $${res.cost.total.toFixed(4)}/hr  = $${(res.cost.total / 100).toFixed(5)}/player-hr\x1b[0m`);
console.log(`  \x1b[90m  (pixel streaming alternative: $${res.pixelStreamingCostPerPlayerHour.toFixed(2)}/player-hr)\x1b[0m`);

ok('client-side caching beats pixel streaming by a wide margin',
  res.cost.total / 100 < res.pixelStreamingCostPerPlayerHour * 0.05,
  `${(res.pixelStreamingCostPerPlayerHour / (res.cost.total / 100)).toFixed(0)}x cheaper`);
ok('the device floor holds under real load', res.proceduralFallbacks <= res.requests,
  `${res.proceduralFallbacks.toLocaleString()} procedural of ${res.requests.toLocaleString()}`);
ok('staleness stays inside a co-op-acceptable window', res.meanStalenessMs < 500,
  `${res.meanStalenessMs.toFixed(0)} ms`);
ok('no device tier evicts under a realistic cache budget', res.evictions === 0,
  `${res.evictions} evictions (desktop 2GB / mobile 256MB)`);

// THE correction to "zero runtime server cost"
ok('runtime server cost is NOT zero — the truth stream is unavoidable',
  res.truthStreamMB > 1 && res.cost.truthStream > 0,
  `${res.truthStreamMB.toFixed(0)} MB/hr, $${res.cost.truthStream.toFixed(4)}`);
ok('...and egress to clients is a real, budgeted line item',
  res.cost.clientEgress > 0, `$${res.cost.clientEgress.toFixed(4)}/hr`);
ok('mobile egress is materially lower than desktop (LOD tiering works)',
  res.perTier.mobile.bytes / res.perTier.mobile.n < res.perTier.desktop.bytes / res.perTier.desktop.n,
  `${(res.perTier.mobile.bytes / res.perTier.mobile.n / 1e6).toFixed(0)} vs ${(res.perTier.desktop.bytes / res.perTier.desktop.n / 1e6).toFixed(0)} MB/player`);

/* ------------------------------------------- 6. edits destroy cache locality */
hdr('6 — Edit rate is what destroys cache locality (not traversal)');

console.log('  \x1b[90medits/hr   hit rate   invalidations   MB/player\x1b[0m');
const locality = [];
for (const e of [0, 900, 3600, 14400]) {
  const r = new S.DistributionModel().runHour({
    players: 100, chunksPerPlayer: 240, editsPerHour: e, returning: 0.6,
    uniqueChunks: 900, quiescenceSec: 300, bakeQuotaPerPlayer: 1
  });
  locality.push({ e, r });
  console.log(`  \x1b[90m${String(e).padStart(8)}   ${(r.hitRate * 100).toFixed(1).padStart(7)}%   ${String(r.invalidations).padStart(13)}   ${r.mbPerPlayerSession.toFixed(0).padStart(9)}\x1b[0m`);
}
ok('a read-only world caches well', locality[0].r.hitRate > 0.30,
  `${(locality[0].r.hitRate * 100).toFixed(1)}% with zero edits`);
ok('heavy editing roughly halves cache hit rate',
  locality[3].r.hitRate < locality[0].r.hitRate * 0.5,
  `${(locality[0].r.hitRate * 100).toFixed(1)}% -> ${(locality[3].r.hitRate * 100).toFixed(1)}%`);
// Invalidations plateau rather than scaling: once the cache is mostly empty
// there is nothing left to drop. Hit rate is the metric that actually degrades.
ok('invalidation count is bounded by cache contents, not by edit rate',
  locality[3].r.invalidations <= locality[1].r.invalidations * 1.5,
  `${locality[1].r.invalidations} -> ${locality[3].r.invalidations} while edits rose 16x`);
ok('egress per player FALLS as editing rises (hot chunks render procedurally, free)',
  locality[3].r.mbPerPlayerSession < locality[0].r.mbPerPlayerSession * 0.5,
  `${locality[0].r.mbPerPlayerSession.toFixed(0)} -> ${locality[3].r.mbPerPlayerSession.toFixed(0)} MB/player`);

/* --------------------------------------------- 7. THE binding constraint:
      bake frequency, not rendering, not distribution. */
hdr('7 — The binding constraint is BAKE FREQUENCY');

console.log(`  \x1b[90mone full chunk bake = ${S.BAKE.gpuSecPerChunk} GPU-s = $${S.BAKE.costPerBake.toFixed(5)}\x1b[0m`);
console.log(`  \x1b[90mbakes affordable at $0.05/player-hr: ${S.bakesAffordable(0.05).toFixed(2)} per player-hour\x1b[0m\n`);

console.log('  \x1b[90medits/p-hr  quota   bakes/p-hr  bake $/hr  dist $/hr  TOTAL $/p-hr  splat cov\x1b[0m');
const frontier = [];
for (const editsTotal of [900, 3600, 14400]) {
  for (const quota of [Infinity, 2, 1]) {
    const r = new S.DistributionModel().runHour({
      players: 100, chunksPerPlayer: 240, editsPerHour: editsTotal, returning: 0.6,
      uniqueChunks: 900, quiescenceSec: 300, bakeQuotaPerPlayer: quota
    });
    const total = (r.bakeCost + r.cost.total) / 100 + 0.0029; // + compute from ARCHITECTURE.md
    frontier.push({ eph: editsTotal / 100, quota, r, total });
    console.log(`  \x1b[90m${(editsTotal / 100).toFixed(0).padStart(10)}  ${String(quota === Infinity ? 'none' : quota).padStart(5)}   ${r.bakesPerPlayerHour.toFixed(2).padStart(10)}  ${('$' + r.bakeCost.toFixed(2)).padStart(10)}  ${('$' + r.cost.total.toFixed(2)).padStart(9)}  ${('$' + total.toFixed(4)).padStart(12)}  ${(r.splatCoverage * 100).toFixed(1).padStart(8)}%\x1b[0m`);
  }
}

const unbounded = frontier.filter(x => x.quota === Infinity);
const governed = frontier.filter(x => x.quota === 1);
ok('ungoverned edit-driven baking breaches the F2P ceiling at EVERY edit rate',
  unbounded.every(x => x.total > 0.05),
  `$${Math.min(...unbounded.map(x => x.total)).toFixed(3)} to $${Math.max(...unbounded.map(x => x.total)).toFixed(2)} per player-hr`);
ok('and at realistic edit rates it is not marginal — it is an order of magnitude out',
  Math.max(...unbounded.map(x => x.total)) > 0.05 * 20,
  `worst case $${Math.max(...unbounded.map(x => x.total)).toFixed(2)}/player-hr`);
ok('a 1-bake/player-hour governor brings it under the ceiling at every edit rate',
  governed.every(x => x.total < 0.05),
  governed.map(x => `$${x.total.toFixed(4)}`).join(', '));
ok('the governor holds the quota even under a 16x edit-rate increase',
  Math.max(...governed.map(x => x.r.bakesPerPlayerHour)) <= 1.01,
  `max ${Math.max(...governed.map(x => x.r.bakesPerPlayerHour)).toFixed(2)} bakes/player-hr`);
ok('...but the price is splat coverage — heavy editors see a mostly procedural world',
  governed[governed.length - 1].r.splatCoverage < 0.15,
  `${(governed[governed.length - 1].r.splatCoverage * 100).toFixed(1)}% coverage at 144 edits/player-hr`);
ok('light editors keep meaningfully more baked fidelity',
  governed[0].r.splatCoverage > governed[2].r.splatCoverage * 2,
  `${(governed[0].r.splatCoverage * 100).toFixed(1)}% vs ${(governed[2].r.splatCoverage * 100).toFixed(1)}%`);

/* ------------------------------------------------- 8. chunk size sensitivity */
hdr('8 — Distribution cost scales linearly with bytes per chunk');

console.log('  \x1b[90mLOD0 bytes/chunk   MB/player-hr   $/player-hr   vs pixel-stream\x1b[0m');
const sweep = [];
for (const lod0 of [0.3e6, 0.6e6, 1.2e6, 2.5e6, 5.0e6]) {
  const m = new S.DistributionModel({ budget: { lod0Bytes: lod0, lod1Bytes: lod0 * 0.15 } });
  const r = m.runHour({ players: 100, chunksPerPlayer: 240, editsPerHour: 900, returning: 0.6, uniqueChunks: 900, quiescenceSec: 300, bakeQuotaPerPlayer: 1 });
  sweep.push({ lod0, per: r.cost.total / 100 });
  console.log(`  \x1b[90m${(lod0 / 1e6).toFixed(1).padStart(9)} MB      ${r.mbPerPlayerSession.toFixed(0).padStart(6)}      $${(r.cost.total / 100).toFixed(5).padStart(8)}      ${(r.pixelStreamingCostPerPlayerHour / (r.cost.total / 100)).toFixed(0).padStart(5)}x cheaper\x1b[0m`);
}
ok('cost is linear in chunk size (no cliff, so it is a tunable dial)',
  sweep[4].per / sweep[0].per > 8 && sweep[4].per / sweep[0].per < 25,
  `${(sweep[4].per / sweep[0].per).toFixed(1)}x cost for ${(sweep[4].lod0 / sweep[0].lod0).toFixed(1)}x the bytes`);

/* ------------------------------- 9. warm cache, and the home-base effect */
hdr('9 — Persistent caching pays only if players have a place to return to');

function f0(x) { return x.toFixed(0); }
function warmTest(label, homeBias, editsPerHour) {
  const base = { players: 100, chunksPerPlayer: 240, editsPerHour, uniqueChunks: 900,
                 quiescenceSec: 300, bakeQuotaPerPlayer: 1, homeBias };
  const cold = new S.DistributionModel().runHour(Object.assign({ returning: 0.0 }, base));
  const warm = new S.DistributionModel().runHour(Object.assign({ returning: 1.0 }, base));
  const saved = 1 - warm.mbPerPlayerSession / cold.mbPerPlayerSession;
  console.log(`  \x1b[90m${label.padEnd(38)} cold ${f0(cold.mbPerPlayerSession).padStart(4)} MB -> warm ${f0(warm.mbPerPlayerSession).padStart(4)} MB  ${f0(saved * 100).padStart(4)}% saved   hit ${f0(warm.hitRate * 100)}%\x1b[0m`);
  return { cold, warm, saved };
}

const wanderQuiet = warmTest('wanderer, read-only world', 0.0, 0);
const wanderEdit  = warmTest('wanderer, 900 edits/hr', 0.0, 900);
const settleQuiet = warmTest('settler (homeBias 0.85), read-only', 0.85, 0);
const settleEdit  = warmTest('settler (homeBias 0.85), 900 edits/hr', 0.85, 900);

ok('a warm cache helps a wanderer only marginally',
  wanderQuiet.saved > 0.03 && wanderQuiet.saved < 0.30,
  `${f0(wanderQuiet.saved * 100)}% — a random walk barely revisits itself`);
ok('a warm cache helps a settler dramatically', settleQuiet.saved > 0.40,
  `${f0(settleQuiet.saved * 100)}% saved, hit rate ${f0(settleQuiet.warm.hitRate * 100)}%`);
ok('home bias beats every CDN tuning knob measured in this file',
  settleQuiet.saved > wanderQuiet.saved * 3,
  `${f0(settleQuiet.saved * 100)}% vs ${f0(wanderQuiet.saved * 100)}%`);
ok('editing erodes the settler advantage but does not erase it',
  settleEdit.saved > wanderEdit.saved && settleEdit.saved > 0.30,
  `${f0(settleEdit.saved * 100)}% vs ${f0(wanderEdit.saved * 100)}%`);
ok('cold-start first session is survivable even for wanderers',
  wanderQuiet.cold.cost.total / 100 < 0.05, `$${(wanderQuiet.cold.cost.total / 100).toFixed(4)}/player-hr`);

console.log(`\n  \x1b[1mDesign consequence: whether players have a home base is a CDN line item.\x1b[0m`);
console.log(`  \x1b[90msettler ${settleEdit.warm.mbPerPlayerSession.toFixed(0)} MB/player-hr vs wanderer ${wanderEdit.warm.mbPerPlayerSession.toFixed(0)} MB/player-hr at 900 edits/hr\x1b[0m`);

/* ------------------------------------------------------------------ */
console.log(`\n\x1b[1m${pass} passed, ${fail} failed\x1b[0m\n`);
process.exit(fail ? 1 : 0);
