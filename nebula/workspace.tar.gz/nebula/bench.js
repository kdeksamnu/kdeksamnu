/* Native perf numbers — what a browser should actually see (no VM overhead). */
const N = require('./core.js');
const W = 128, H = 80, CW = 16, CHH = 10;
const t = (label, fn) => { const a = performance.now(); const r = fn(); const b = performance.now(); console.log(`${label.padEnd(46)} ${(b - a).toFixed(1).padStart(8)} ms   ${r ?? ''}`); return b - a; };

const world = new N.World(W, H, 1337);
const mat = t('materializer bake (1700 steps)', () => { const m = new N.Materializer(42); m.train(world, 1700); return `loss ${m.trainLoss.toFixed(5)}, ${m.paramCount} params`; });
const m2 = new N.Materializer(42); m2.train(world, 1700);

const fin = new Float32Array(N.MAT_IN), out = new Float32Array(N.MAT_OUT);
const style = new Float32Array(N.STYLE_DIM).fill(0.5);

t('single neural decode (2 towers)', () => { for (let i = 0; i < 10000; i++) { N.featuresAt(world, i % W, (i / W) | 0, fin, style); m2.decode(fin, out); } return `${(10000).toLocaleString()} cells`; });
const perCell = (() => { const a = performance.now(); for (let i = 0; i < 20000; i++) { N.featuresAt(world, i % W, (i / W) | 0, fin, style); m2.decode(fin, out); } return (performance.now() - a) / 20000; })();
console.log(`${'  → per cell'.padEnd(46)} ${(perCell * 1000).toFixed(2).padStart(8)} µs`);
console.log(`${'  → per 16x10 chunk'.padEnd(46)} ${(perCell * 160).toFixed(2).padStart(8)} ms`);

t('micro-sim tick (10,240 cells)', () => { for (let i = 0; i < 100; i++) world.microStep(1); return '100 ticks'; });
t('full lo-fi repaint (all 10,240 cells)', () => { for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { N.featuresAt(world, x, y, fin, null); m2.decodeLoFi(fin, out); } return ''; });
t('event-log replay (200 intents + 400 ticks)', () => {
  const w = new N.World(W, H, 99);
  for (let i = 0; i < 200; i++) { w.apply(w.makeIntent('raise', { x: (i * 7) % W, y: (i * 13) % H, r: 4, amount: 0.3 })); if (i % 2 === 0) for (let k = 0; k < 2; k++) w.microStep(1); }
  for (let i = 0; i < 400; i++) w.microStep(1);
  const r = N.World.replay(w.events, W, H, 99, w.microTick);
  return r.fingerprint() === w.fingerprint() ? '✓ identical' : '✗ MISMATCH';
});
const agent = new N.SettlerAgent(1, { cooldown: 1, seed: 3 });
t('40 macro decisions (agent utility search)', () => { let n = 0; for (let i = 0; i < 40; i++) n += world.macroStep([agent]).length; return `${n} settlements`; });
