"""
Real 3D chunk bake — measured, not assumed.

Produces actual artifacts on disk and measures them:
  bake_ply.py         -> standard 3DGS .ply (loadable in real viewers)
  bake.splat          -> quantized 32 B/gaussian streaming format
  frame_qpsi.bin      -> the submission's 32-byte-header Q/Psi stream, validated
  bake_report.json    -> every number below, machine-readable

Two bake strategies are measured separately, because the architecture only
needs one of them and the 45 GPU-second figure in ARCHITECTURE.md §5b silently
assumed the other:

  A. PROCEDURAL EMISSION — symbolic channels -> gaussians, no optimization.
     This is what a symbolic-first world actually needs: the geometry is
     ground truth you already own, not something to reconstruct from photos.

  B. OPTIMIZATION FIT — real differentiable splat rasterization + Adam,
     the classic 3DGS pipeline. This is where "45 GPU-seconds" comes from.

Everything here runs on CPU (2x Xeon @ 2.90 GHz, torch 2.14.0+cpu). There is
no GPU in this environment; GPU figures are labelled EXTRAPOLATED and the
arithmetic is shown so you can substitute your own measured throughput.
"""
import json, math, os, struct, sys, time
import numpy as np

OUT = os.path.dirname(os.path.abspath(__file__))
CHUNK = 64                 # 64 x 64 cell heightfield per chunk
RNG = np.random.default_rng(1337)

def t_now(): return time.perf_counter()
class Clock:
    def __init__(self): self.t = t_now()
    def lap(self, label):
        n = t_now(); d = n - self.t; self.t = n
        return label, d

REPORT = {"environment": {}, "chunk": {}, "pathA_procedural": {}, "pathB_optimization": {},
          "artifacts": {}, "stream": {}, "economics": {}}

# ===========================================================================
# 0. Symbolic truth — the same channel model as nebula/core.js
# ===========================================================================
def value_noise(seed, size=512):
    r = np.random.default_rng(seed)
    g = r.standard_normal((size, size)).astype(np.float32)
    return g

def fbm_field(seed, n, freq, octaves=5, gain=0.5):
    """Cheap deterministic fbm via bilinear-sampled value noise."""
    base = value_noise(seed, 256)
    out = np.zeros((n, n), np.float32); amp = 1.0; norm = 0.0; f = freq
    for _ in range(octaves):
        # bilinear sample of the noise lattice at frequency f
        xs = (np.arange(n) * f / n) % 256.0
        x0 = xs.astype(np.int32); x1 = (x0 + 1) % 256; tx = (xs - x0).astype(np.float32)
        A = base[np.ix_(x0, x0)] * (1-tx[:,None])*(1-tx[None,:]) + base[np.ix_(x1,x0)]*tx[:,None]*(1-tx[None,:]) \
          + base[np.ix_(x0,x1)]*(1-tx[:,None])*tx[None,:] + base[np.ix_(x1,x1)]*tx[:,None]*tx[None,:]
        out += amp * A; norm += amp; amp *= gain; f *= 2.0
    return (out / norm)

def generate_chunk(seed=1337):
    n = CHUNK
    e = fbm_field(seed, n, 4.0, 5, 0.5)
    e = (e - e.min()) / (np.ptp(e) + 1e-6)
    xx, yy = np.meshgrid(np.linspace(-1,1,n), np.linspace(-1,1,n), indexing='xy')
    d = np.sqrt(xx**2 + yy**2)
    e = np.clip(e**1.4 * np.clip(1 - (d*1.1)**3, 0, 1), 0, 1)
    ridge = np.exp(-((yy - 0.1*np.sin(xx*6)) * 6.0)**2)
    elev = np.clip(e*0.7 + ridge*0.35, 0, 1).astype(np.float32)

    m = fbm_field(seed ^ 0x9e37, n, 3.0, 4, 0.5)
    m = (m - m.min())/(np.ptp(m)+1e-6)
    moist = np.clip(m*0.7 + (1-elev)*0.35, 0, 1).astype(np.float32)
    rock  = np.clip(elev**2.2 * 1.2, 0, 1).astype(np.float32)
    water = np.where(elev < 0.30, np.clip((0.30-elev)/0.30, 0, 1), 0).astype(np.float32)
    habit = (elev > 0.32) & (elev < 0.78)
    v = fbm_field(seed ^ 0x5bf0, n, 7.0, 3, 0.5); v = (v-v.min())/(np.ptp(v)+1e-6)
    veg = np.where(habit, np.clip(v*moist*1.7, 0, 1), 0).astype(np.float32)

    gy, gx = np.gradient(elev)
    slope = np.clip(np.hypot(gx, gy)*6.0, 0, 1).astype(np.float32)
    return {"elev": elev, "moist": moist, "rock": rock, "veg": veg,
            "water": water, "slope": slope, "n": n}

def biome_color(elev, moist, rock, veg, water, slope):
    """Vectorised port of core.js biomeTarget — the curated symbolic truth."""
    def ss(e0, e1, x): 
        t = np.clip((x-e0)/(e1-e0+1e-9), 0, 1); return t*t*(3-2*t)
    lush = np.clip(veg*0.75 + moist*0.35, 0, 1)
    r = 172.0 + (66-172)*lush; g = 154.0 + (118-154)*lush; b = 96.0 + (52-96)*lush
    sand = (1-ss(0.30,0.40,elev))*(1-ss(0.15,0.40,water))
    r = r+(208-r)*sand; g = g+(192-g)*sand; b = b+(146-b)*sand
    barren = 1-ss(0.10,0.38,veg)
    rockT = ss(0.42,0.72,rock)*barren*(0.55+slope*0.45)
    r = r+(128-r)*rockT; g = g+(124-g)*rockT; b = b+(120-b)*rockT
    snow = ss(0.74,0.88,elev)
    r = r+(244-r)*snow; g = g+(247-g)*snow; b = b+(252-b)*snow
    deep = ss(0.18,0.55,water); shallow = ss(0.02,0.20,water)
    r = r+((84+(16-84)*deep)-r)*shallow; g = g+((136+(52-136)*deep)-g)*shallow; b = b+((164+(104-164)*deep)-b)*shallow
    return np.clip(np.stack([r,g,b],-1)/255.0, 0, 1).astype(np.float32)

# ===========================================================================
# A. PROCEDURAL EMISSION
# ===========================================================================
def bake_procedural(ch, cell_metres=1.0, veg_density=0.35, density=1):
    """Emit gaussians directly from symbolic truth. No optimization loop."""
    n = ch["n"]
    elev, veg, water = ch["elev"], ch["veg"], ch["water"]
    col = biome_color(elev, ch["moist"], ch["rock"], veg, water, ch["slope"])

    xs, ys = np.meshgrid(np.arange(n, dtype=np.float32), np.arange(n, dtype=np.float32), indexing='xy')
    land = water < 0.35
    # --- terrain surface gaussians: `density` sub-samples per land cell.
    # density=1 -> one gaussian per cell (coarse LOD). Production splat chunks
    # run 50k-500k gaussians, so we sweep density and report the scaling curve.
    tx0, ty0 = xs[land], ys[land]
    if density > 1:
        side = int(round(math.sqrt(density)))
        off = (np.arange(side) + 0.5) / side - 0.5
        ox, oy = np.meshgrid(off, off, indexing='xy')
        tx = (tx0[:, None] + ox.ravel()[None, :]).ravel()
        ty = (ty0[:, None] + oy.ravel()[None, :]).ravel()
        # bilinear sample of elevation and colour at the sub-cell position
        txi = np.clip(tx.astype(np.float64), 0, n - 1.001)
        tyi = np.clip(ty.astype(np.float64), 0, n - 1.001)
        x0 = txi.astype(np.int32); y0 = tyi.astype(np.int32)
        x1 = np.minimum(x0 + 1, n - 1); y1 = np.minimum(y0 + 1, n - 1)
        fx = txi - x0; fy = tyi - y0          # both shape (M,) — no broadcasting
        def bilerp(arr):
            a = arr[y0, x0]; b = arr[y0, x1]; c = arr[y1, x0]; d = arr[y1, x1]
            top = a * (1 - fx) + b * fx
            bot = c * (1 - fx) + d * fx
            return (top * (1 - fy) + bot * fy).astype(np.float32)
        tz = bilerp(elev) * 12.0
        tc = np.stack([bilerp(col[:, :, k]) for k in range(3)], -1).astype(np.float32)
        sub = cell_metres / side
    else:
        tx, ty = tx0, ty0
        tz = elev[land] * 12.0
        tc = col[land]
        sub = cell_metres
    # --- vegetation instances: stochastic, density from the veg channel
    draw = RNG.random((n, n)) < (veg * veg_density)
    vx, vy = xs[draw], ys[draw]
    vz = elev[draw]*12.0 + 0.35 + RNG.random(vx.shape)*0.9
    vc = col[draw] * np.array([0.55, 0.95, 0.55], np.float32)
    # --- water surface
    wl = (~land) & (water > 0.05)
    wx, wy = xs[wl], ys[wl]
    wz = np.full(wx.shape, 0.30*12.0, np.float32)
    wc = col[wl]

    pos = np.concatenate([np.stack([tx,ty,tz],-1), np.stack([vx,vy,vz],-1), np.stack([wx,wy,wz],-1)]).astype(np.float32)
    rgb = np.concatenate([tc, vc, wc]).astype(np.float32)
    kinds = np.concatenate([np.zeros(tx.size,np.int8), np.ones(vx.size,np.int8), np.full(wx.size,2,np.int8)])

    # per-kind scale (isotropic-ish, metres) and opacity
    scale = np.empty((pos.shape[0], 3), np.float32)
    scale[kinds==0] = np.array([sub*0.62, sub*0.62, 0.16], np.float32)
    scale[kinds==1] = np.array([0.30, 0.30, 0.55], np.float32)
    scale[kinds==2] = np.array([cell_metres*0.75, cell_metres*0.75, 0.05], np.float32)
    opacity = np.where(kinds==2, 0.72, np.where(kinds==1, 0.90, 1.0)).astype(np.float32)
    # identity rotation quaternions (terrain is axis-aligned; vegetation jitter)
    rot = np.tile(np.array([1,0,0,0],np.float32), (pos.shape[0],1))
    jit = (RNG.random((int((kinds==1).sum()),4)).astype(np.float32)-0.5)*0.35
    rot[kinds==1] += jit
    rot /= (np.linalg.norm(rot,axis=1,keepdims=True)+1e-9)
    return {"pos":pos, "rgb":rgb, "scale":scale, "rot":rot, "opacity":opacity, "kinds":kinds}

def write_ply(path, g, sh_degree=0):
    """Standard 3DGS .ply. sh_degree=0 -> f_dc only; 3 -> full 45 f_rest."""
    n = g["pos"].shape[0]
    # 3DGS convention: f_rest holds 3 channels x ((degree+1)^2 - 1) coefficients.
    # degree 3 -> 3 x 15 = 45, which is the standard full-SH .ply.
    n_rest = 0 if sh_degree == 0 else 3 * ((sh_degree + 1) ** 2 - 1)
    props = ["x","y","z","nx","ny","nz","f_dc_0","f_dc_1","f_dc_2"]
    props += [f"f_rest_{i}" for i in range(n_rest)]
    props += ["opacity","scale_0","scale_1","scale_2","rot_0","rot_1","rot_2","rot_3"]
    hdr = ["ply","format binary_little_endian 1.0", f"element vertex {n}"]
    hdr += [f"property float {p}" for p in props]
    hdr += ["end_header",""]
    head = "\n".join(hdr).encode()
    C0 = 0.28209479177387814
    rec = np.zeros((n, len(props)), np.float32)
    rec[:,0:3] = g["pos"]
    rec[:,6:9] = (g["rgb"] - 0.5) / C0            # RGB -> SH DC
    o = np.clip(g["opacity"], 1e-6, 1 - 1e-6)
    rec[:, 9+n_rest] = np.log(o / (1 - o))            # logit, as 3DGS stores it
    rec[:,10+n_rest:13+n_rest] = np.log(np.clip(g["scale"],1e-7,None))
    rec[:,13+n_rest:17+n_rest] = g["rot"]
    with open(path,"wb") as f:
        f.write(head); f.write(rec.tobytes())
    return os.path.getsize(path), n, len(props)

def write_splat(path, g):
    """antimatter15/splat streaming format: exactly 32 bytes per gaussian.
       pos 3xf32 (12) | scale 3xf32 (12) | rgba 4xu8 (4) | quat 4xu8 (4)"""
    n = g["pos"].shape[0]
    buf = bytearray(n*32)
    pos = g["pos"].astype("<f4"); sc = np.log(np.clip(g["scale"],1e-7,None)).astype("<f4")
    rgba = np.clip(g["rgb"],0,1); rgba = (rgba*255).astype(np.uint8)
    op = (np.clip(g["opacity"],0,1)*255).astype(np.uint8)
    q = np.clip((g["rot"]+1.0)*0.5*255, 0, 255).astype(np.uint8)
    arr = np.frombuffer(bytes(buf), dtype=np.uint8).reshape(n,32).copy()
    arr[:,0:12]  = pos.view(np.uint8).reshape(n,12)
    arr[:,12:24] = sc.view(np.uint8).reshape(n,12)
    arr[:,24] = rgba[:,0]; arr[:,25] = rgba[:,1]; arr[:,26] = rgba[:,2]; arr[:,27] = op
    arr[:,28:32] = q
    with open(path,"wb") as f: f.write(arr.tobytes())
    return os.path.getsize(path), n

# ===========================================================================
# The submission's binary egress protocol — actually written, then validated
# ===========================================================================
MAGIC = b"CLAE"; VERSION = 1
def pack_frame(tick, cells, gov_tokens_micro, merkle_prefix, q_records, psi_records):
    """32-byte header exactly as documented:
       magic 4 | version u16 2 | tick u64 8 | cell_count u32 4 | gov u32 4 |
       merkle char[8] 8 | reserved 2   == 32"""
    hdr = bytearray()
    hdr += MAGIC
    hdr += struct.pack("<H", VERSION)
    hdr += struct.pack("<Q", tick)
    hdr += struct.pack("<I", cells)
    hdr += struct.pack("<I", gov_tokens_micro)
    mp = merkle_prefix.encode()[:8].ljust(8, b"\x00")
    hdr += mp
    hdr += b"\x00\x00"
    assert len(hdr) == 32, len(hdr)
    return bytes(hdr) + q_records + psi_records

def parse_frame_like_client(buf):
    """Uses the exact offsets from client/render_app.js."""
    if len(buf) < 32: return None
    magic = buf[0:4]
    version = int.from_bytes(buf[4:6], "little")
    tick = int.from_bytes(buf[6:14], "little")          # getBigUint64(6)
    cells = int.from_bytes(buf[14:18], "little")        # getUint32(14)
    gov = int.from_bytes(buf[18:22], "little")          # getUint32(18)
    merkle = bytes(b for b in buf[22:30] if b).decode() # Uint8Array(buf,22,8)
    q_off, q_size = 32, cells*16
    psi_off, psi_size = 32+q_size, cells*16
    return {"magic":magic,"version":version,"tick":tick,"cells":cells,"gov":gov,
            "merkle":merkle,"q_off":q_off,"q_size":q_size,
            "psi_off":psi_off,"psi_size":psi_size,
            "total":len(buf),"expected":32+q_size+psi_size}

# ===========================================================================
def main():
    print("="*78); print("REAL 3D CHUNK BAKE — measured"); print("="*78)
    import platform
    REPORT["environment"] = {
        "cpu": platform.processor() or "unknown", "cores": os.cpu_count(),
        "python": platform.python_version(),
        "gpu": "NONE AVAILABLE — no CUDA, no Vulkan, no /dev/dri",
        "note": "All timings are CPU. GPU figures are labelled EXTRAPOLATED."
    }
    print(f"  cpu cores      : {os.cpu_count()}")
    print(f"  gpu            : NONE (no CUDA / Vulkan / /dev/dri in this sandbox)")
    print(f"  python         : {platform.python_version()}")

    # ---------------- symbolic truth
    clk = Clock(); ch = generate_chunk(1337); _, dt = clk.lap("gen")
    REPORT["chunk"] = {"cells": int(ch["n"]**2), "edge": ch["n"], "channels": 6,
                       "symbolic_gen_seconds": dt,
                       "symbolic_bytes_raw": int(ch["n"]**2*6*4)}
    print(f"\n  chunk          : {ch['n']}x{ch['n']} = {ch['n']**2} cells, 6 channels")
    print(f"  symbolic truth : {ch['n']**2*6*4/1024:.0f} KB raw, generated in {dt*1000:.1f} ms")

    # ---------------- PATH A: procedural emission
    print("\n" + "-"*78); print("PATH A — PROCEDURAL EMISSION (symbolic truth -> gaussians)"); print("-"*78)
    clk = Clock(); g = bake_procedural(ch); _, dtA = clk.lap("emit")
    N = g["pos"].shape[0]
    kinds = g["kinds"]
    print(f"  gaussians      : {N:,}  (terrain {int((kinds==0).sum()):,} / vegetation {int((kinds==1).sum()):,} / water {int((kinds==2).sum()):,})")
    print(f"  emit wall time : {dtA*1000:.1f} ms   <-- MEASURED, single core numpy")

    ply0 = os.path.join(OUT,"bake_dc0.ply"); s0,n0,p0 = write_ply(ply0, g, sh_degree=0)
    ply3 = os.path.join(OUT,"bake_dc3.ply"); s3,n3,p3 = write_ply(ply3, g, sh_degree=3)
    spl  = os.path.join(OUT,"bake.splat");   ss,ns  = write_splat(spl, g)
    print(f"\n  artifact sizes (this is the CDN egress number):")
    print(f"    .ply SH0  ({p0:>2} props) : {s0/1024/1024:7.2f} MB   {s0/N:6.1f} B/gaussian")
    print(f"    .ply SH3  ({p3:>2} props) : {s3/1024/1024:7.2f} MB   {s3/N:6.1f} B/gaussian")
    print(f"    .splat    (quantized)   : {ss/1024/1024:7.2f} MB   {ss/N:6.1f} B/gaussian")

    # validate the .ply parses back
    with open(ply0,"rb") as f: raw = f.read()
    hend = raw.index(b"end_header\n")+len(b"end_header\n")
    hdr_txt = raw[:hend].decode()
    nvert = int([l for l in hdr_txt.split("\n") if l.startswith("element vertex")][0].split()[-1])
    body = np.frombuffer(raw[hend:], dtype="<f4").reshape(nvert, p0)
    pos_err = float(np.abs(body[:,0:3]-g["pos"]).max())
    print(f"\n  .ply round-trip: header parsed, {nvert} vertices, max position error {pos_err:.2e}")

    # validate the .splat round-trips
    sb = np.frombuffer(open(spl,"rb").read(), dtype=np.uint8).reshape(ns,32)
    spos = np.frombuffer(sb[:,0:12].tobytes(), dtype="<f4").reshape(ns,3)
    splat_err = float(np.abs(spos-g["pos"]).max())
    print(f"  .splat round-trip: {ns} gaussians x 32 B, max position error {splat_err:.2e}")

    REPORT["pathA_procedural"] = {
        "gaussians": int(N), "emit_wall_seconds_cpu": dtA,
        "ply_sh0_bytes": int(s0), "ply_sh3_bytes": int(s3), "splat_bytes": int(ss),
        "bytes_per_gaussian": {"ply_sh0": s0/N, "ply_sh3": s3/N, "splat": ss/N},
        "roundtrip_max_position_error": max(pos_err, splat_err),
        "measured_on": "CPU, single node, numpy vectorised"
    }
    REPORT["artifacts"] = {"ply_sh0": ply0, "ply_sh3": ply3, "splat": spl}

    # ---------------- density sweep: the real scaling curve
    print("\n  density sweep (gaussians per land cell) — production splat chunks run 50k-500k:")
    print(f"    {'density':>8} {'gaussians':>11} {'emit ms':>9} {'.splat KB':>10} {'.ply SH0 KB':>12} {'ms/10k gauss':>13}")
    sweep = []
    for dens in (1, 4, 9, 16, 25):
        c2 = Clock(); gg = bake_procedural(ch, density=dens); _, dt2 = c2.lap("e")
        nn = gg["pos"].shape[0]
        p = os.path.join(OUT, f"_sweep_{dens}.splat"); sb, _ = write_splat(p, gg)
        p2 = os.path.join(OUT, f"_sweep_{dens}.ply"); pb, _, _ = write_ply(p2, gg, 0)
        sweep.append({"density": dens, "gaussians": int(nn), "emit_seconds_cpu": dt2,
                      "splat_bytes": int(sb), "ply_sh0_bytes": int(pb),
                      "ms_per_10k_gaussians": dt2*1000/(nn/10000)})
        print(f"    {dens:>8} {nn:>11,} {dt2*1000:>9.1f} {sb/1024:>10.1f} {pb/1024:>12.1f} {dt2*1000/(nn/10000):>13.2f}")
        if dens == 25:
            os.replace(p, os.path.join(OUT, "bake_production.splat"))
            REPORT["artifacts"]["splat_production"] = os.path.join(OUT, "bake_production.splat")
        else:
            os.remove(p)
        os.remove(p2)
    # linear scaling check
    r = sweep[-1]["emit_seconds_cpu"]/sweep[0]["emit_seconds_cpu"]
    gr = sweep[-1]["gaussians"]/sweep[0]["gaussians"]
    print(f"    scaling: {gr:.1f}x gaussians cost {r:.1f}x time -> {'LINEAR' if 0.7 < r/gr < 1.4 else 'SUPERLINEAR'} ({r/gr:.2f})")
    REPORT["pathA_procedural"]["density_sweep"] = sweep
    REPORT["pathA_procedural"]["scaling_exponent"] = math.log(r)/math.log(gr)
    prod = sweep[-1]
    print(f"\n  at production density ({prod['gaussians']:,} gaussians):")
    print(f"    emit            : {prod['emit_seconds_cpu']*1000:.1f} ms on 1 CPU core")
    print(f"    .splat payload  : {prod['splat_bytes']/1024:.0f} KB")
    print(f"    cost per bake   : ${prod['emit_seconds_cpu']/3600*0.05:.3e} (CPU @ $0.05/hr)")

    # ---------------- the binary egress stream
    print("\n" + "-"*78); print("BINARY EGRESS STREAM — the 32-byte header nobody was writing"); print("-"*78)
    cells = int(ch["n"]**2)
    # Q record: <Ifff  = q_state u32, permanence f32, nx f32, ny f32   (16 B)
    q_bytes = np.zeros((cells, 16), np.uint8)
    qv = q_bytes.view("<u4"); qf = q_bytes.view("<f4")
    qv[:, 0] = 0                 # q_state
    qf[:, 1] = 1.0               # permanence
    qf[:, 2] = 0.0               # nx
    qf[:, 3] = 1.0               # ny
    # Psi record: <fffI = variance f32, phase f32, entropy f32, spectral u32 (16 B)
    psi_bytes = np.zeros((cells, 16), np.uint8)
    pf = psi_bytes.view("<f4"); pv = psi_bytes.view("<u4")
    pf[:, 0] = ch["elev"].ravel()                       # variance
    pf[:, 1] = 0.3                                      # phase (uniform: see defect note)
    pf[:, 2] = math.log(8.0) * ch["elev"].ravel()       # entropy as the engine computes it
    pv[:, 3] = 3                                        # spectral_constant_idx
    frame = pack_frame(tick=42, cells=cells, gov_tokens_micro=49999,
                       merkle_prefix="7deef44e", q_records=q_bytes.tobytes(), psi_records=psi_bytes.tobytes())
    fpath = os.path.join(OUT,"frame_qpsi.bin"); open(fpath,"wb").write(frame)
    parsed = parse_frame_like_client(frame)
    print(f"  frame size     : {len(frame):,} bytes  ({len(frame)/1024:.1f} KB) for {cells} cells")
    print(f"  header         : 32 bytes  magic={parsed['magic']}  version={parsed['version']}")
    print(f"  client offsets : tick@6={parsed['tick']}  cells@14={parsed['cells']}  gov@18=${parsed['gov']/1e6:.5f}  merkle@22={parsed['merkle']}")
    print(f"  payload        : Q @{parsed['q_off']} ({parsed['q_size']:,} B)  Psi @{parsed['psi_off']} ({parsed['psi_size']:,} B)")
    ok_stream = (parsed["magic"]==MAGIC and parsed["tick"]==42 and parsed["cells"]==cells
                 and parsed["gov"]==49999 and parsed["merkle"]=="7deef44e"
                 and parsed["total"]==parsed["expected"])
    print(f"  round-trip     : {'OK — every documented offset parses correctly' if ok_stream else 'MISMATCH'}")
    # demonstrate the phase-in-per-cell defect costs real bytes
    per_frame = len(frame)
    hz = 20
    gb_hr = per_frame*hz*3600/1e9
    print(f"\n  at 20 Hz full-state: {per_frame*hz/1e6:.2f} MB/s = {gb_hr:.2f} GB/hr/client = ${gb_hr*0.085:.4f}/player-hr")
    print(f"  delta-only (Q changed cells + uniform phase): ~{(cells*16*0.02+64)/1024:.1f} KB/frame = ${ (cells*16*0.02+64)*hz*3600/1e9*0.085:.6f}/player-hr")
    REPORT["stream"] = {"frame_bytes": int(per_frame), "header_bytes": 32,
                        "client_offsets_verified": bool(ok_stream), "file": fpath,
                        "full_state_gb_per_hr_per_client": gb_hr,
                        "full_state_usd_per_player_hr": gb_hr*0.085}

    # ---------------- PATH B: optimization fit
    print("\n" + "-"*78); print("PATH B — OPTIMIZATION FIT (real differentiable splat rasterizer)"); print("-"*78)
    try:
        import torch
        bench_path_b(g, ch, torch)
    except Exception as e:
        import traceback; traceback.print_exc()
        REPORT["pathB_optimization"] = {"error": str(e)}

    # ---------------- economics with MEASURED numbers
    print("\n" + "-"*78); print("REVISED ECONOMICS — measured bytes substituted into §5b"); print("-"*78)
    econ = recompute_economics(REPORT)
    REPORT["economics"] = econ

    with open(os.path.join(OUT,"bake_report.json"),"w") as f:
        json.dump(REPORT, f, indent=2, default=str)
    print(f"\nreport written to {os.path.join(OUT,'bake_report.json')}")
    print("="*78)

def bench_path_b(g, ch, torch, RES=64, NG=1024, TILE=256, iters=6):
    """A real (if simplified) differentiable gaussian splatting fit.

    Rasterizes gaussians to an image, backprops L1 against a target, times
    per-iteration cost. Pixel-tiled so the accumulation matrix stays small —
    this box has 1 GB RAM, and an untiled 128^2 x 4096 tensor alone is 268 MB.

    The reference rasterizer here is O(pixels x gaussians) with no tiling/culling
    acceleration, so measured throughput is a LOWER bound on what a real CUDA
    3DGS rasterizer achieves. Treat extrapolations accordingly.
    """
    torch.set_num_threads(os.cpu_count() or 2)
    dev = torch.device("cpu")
    idx = np.linspace(0, g["pos"].shape[0] - 1, min(NG, g["pos"].shape[0])).astype(np.int64)
    NG = idx.size
    pos = torch.tensor(g["pos"][idx], dtype=torch.float32, requires_grad=True)
    logscale = torch.tensor(np.log(g["scale"][idx]), dtype=torch.float32, requires_grad=True)
    rgb = torch.tensor(g["rgb"][idx], dtype=torch.float32, requires_grad=True)
    opac = torch.tensor(g["opacity"][idx], dtype=torch.float32, requires_grad=True)
    opt = torch.optim.Adam([pos, logscale, rgb, opac], lr=2e-3)

    gy_all = torch.arange(RES, dtype=torch.float32)
    gx_all = torch.arange(RES, dtype=torch.float32)

    def project():
        depth = (pos[:, 2] + 1.0).clamp(min=0.05)
        focal = RES * 0.9
        cx = (pos[:, 0] / ch["n"] * 2 - 1) * 1.6
        cy = (pos[:, 1] / ch["n"] * 2 - 1) * 1.6
        px = (cx * 0.5 + 0.5) * RES
        py = (cy * 0.5 + 0.5) * RES
        sx = torch.exp(logscale[:, 0]) * focal / depth
        sy = torch.exp(logscale[:, 1]) * focal / depth
        return px, py, sx.clamp(min=1e-3), sy.clamp(min=1e-3)

    def render_tile(px, py, sx, sy, y0, y1):
        yy = gy_all[y0:y1].reshape(-1, 1)
        xx = gx_all.reshape(1, -1).expand(y1 - y0, -1).reshape(-1, 1)
        yy = yy.expand(-1, RES).reshape(-1, 1)
        dx = (xx - px.reshape(1, -1)) / sx.reshape(1, -1)
        dy = (yy - py.reshape(1, -1)) / sy.reshape(1, -1)
        w = torch.exp(-0.5 * (dx * dx + dy * dy)) * opac.reshape(1, -1)
        denom = w.sum(1, keepdim=True) + 1e-6
        img = (w.unsqueeze(2) * rgb.reshape(1, -1, 3)).sum(1) / denom
        return img

    def full_render():
        px, py, sx, sy = project()
        return torch.cat([render_tile(px, py, sx, sy, y, min(y + TILE, RES))
                          for y in range(0, RES, TILE)], 0).reshape(RES, RES, 3)

    with torch.no_grad():
        target = full_render().clamp(0, 1).detach()
    with torch.no_grad():
        pos.add_(torch.randn_like(pos) * 0.6); rgb.mul_(0.7)

    weight = TILE * RES / (RES * RES)   # tile loss weighting so the sum == mean
    times = []
    for it in range(iters):
        t0 = t_now()
        opt.zero_grad(set_to_none=True)
        px, py, sx, sy = project()
        loss = 0.0
        for y in range(0, RES, TILE):
            img = render_tile(px, py, sx, sy, y, min(y + TILE, RES))
            rows = min(y + TILE, RES) - y
            tl = (img - target.reshape(-1, 3)[y * RES:(y + rows) * RES]).abs().mean()
            (tl * (rows / RES)).backward()      # accumulate grads, frees the tile graph
            loss = loss + float(tl) * (rows / RES)
        opt.step()
        times.append(t_now() - t0)
        if it == 0 or it == iters - 1:
            print(f"    iter {it}: loss={loss:.5f}  {times[-1]*1000:.0f} ms")

    per_iter = float(np.median(times[1:])) if len(times) > 1 else times[0]
    work = RES * RES * NG              # pixel-gaussian pairs per forward pass
    fwd_bwd = 3.0                      # backward ~2x forward
    macs = work * 12 * fwd_bwd
    print(f"\n  config         : {RES}x{RES} render, {NG} gaussians, tile={TILE}, Adam")
    print(f"  per iteration  : {per_iter*1000:.1f} ms  (median of {len(times)-1}, CPU, {os.cpu_count()} threads)")
    print(f"  throughput     : {macs/per_iter/1e9:.2f} GMAC/s   ({work/per_iter/1e6:.1f} M pixel-gaussian pairs/s)")
    pair_rate = work / per_iter
    for K in (1000, 7000, 30000):
        print(f"  {K:>6,} iters at THIS config -> CPU {per_iter*K/60:8.1f} min")

    print(f"\n  EXTRAPOLATED — stated assumptions, not measurements:")
    print(f"  a production chunk at 256x256 render x 100k gaussians is")
    prod_pairs = 256 * 256 * 100_000
    print(f"  {prod_pairs/pair_rate:.0f}x this workload per iteration.")
    cpu_prod_iter = prod_pairs / pair_rate
    print(f"    CPU (this box)          : {cpu_prod_iter:.2f} s/iter -> 7,000 iters = {cpu_prod_iter*7000/3600:.0f} h")
    # GPU: a tiled CUDA rasterizer only touches pixels within 3 sigma of each
    # gaussian, so effective work is far below res^2 x N. Assume 20x fewer
    # pairs AND 100x higher throughput than this 2-core CPU reference.
    for name, eff in [("naive dense (no culling)", 1.0), ("tiled+culled (real 3DGS)", 1/20.0)]:
        gpu_iter = cpu_prod_iter * eff / 100.0
        print(f"    GPU {name:24}: {gpu_iter*1000:7.1f} ms/iter -> 7,000 iters = {gpu_iter*7000:7.1f} s = {gpu_iter*7000/60:.1f} min")
        REPORT.setdefault("pathB_optimization", {})["gpu_seconds_7000_iters_" + name.split()[0]] = gpu_iter * 7000

    REPORT["pathB_optimization"].update({
        "resolution": RES, "gaussians": NG, "tile": TILE, "iterations_measured": iters,
        "per_iteration_seconds_cpu": per_iter,
        "pixel_gaussian_pairs_per_sec": pair_rate,
        "macs_per_sec": macs / per_iter,
        "cpu_threads": os.cpu_count(), "ram_limit_gb": 1,
        "production_workload_multiplier": prod_pairs / work,
        "cpu_seconds_per_prod_iter": cpu_prod_iter,
        "status": "MEASURED on CPU; all GPU figures EXTRAPOLATED from stated assumptions",
        "caveat": "dense O(res^2 x N) reference rasterizer; real 3DGS tiles and culls, so this over-states work per iteration"})
    return per_iter

def recompute_economics(R):
    A = R["pathA_procedural"]; B = R.get("pathB_optimization", {})
    # use the PRODUCTION-density bake, not the coarse default
    prod = A["density_sweep"][-1] if A.get("density_sweep") else A
    splat_bytes = prod["splat_bytes"]; N = prod["gaussians"]
    bake_seconds = prod["emit_seconds_cpu"]
    print(f"  measured .splat chunk size       : {splat_bytes/1024:.1f} KB  ({N:,} gaussians)")
    print(f"  measured procedural bake (CPU)   : {bake_seconds*1000:.0f} ms for {N:,} gaussians")
    print(f"  §5b ASSUMED chunk size           : {1.2e6/1024/1024:.2f} MB")
    print(f"  ratio assumed/measured           : {1.2e6/splat_bytes:.1f}x  <-- the assumption was this far off")
    print('')
    # egress with measured bytes
    EGRESS = 0.085
    # recompute: players touch ~240 chunks/hr; cache hit ~30%; so ~168 fetches
    fetches = 240*0.682
    gb = fetches*splat_bytes/1e9
    print(f"  egress with MEASURED chunk bytes : {fetches:.0f} fetches x {splat_bytes/1024:.0f} KB = {gb*1000:.1f} MB/player-hr")
    old_gb = fetches * 1.2e6 / 1e9
    print(f"                                     = ${gb*EGRESS:.5f}/player-hr")
    print(f"  at the §5b ASSUMED 1.2 MB chunk    : {fetches:.0f} fetches = {old_gb*1000:.0f} MB/player-hr = ${old_gb*EGRESS:.5f}/player-hr")
    # bake cost: procedural on CPU is free-ish; optimization fit is not
    cpu_hr_price = 0.05
    proc_cost = bake_seconds/3600*cpu_hr_price
    print(f"\n  procedural bake cost (CPU)       : ${proc_cost:.8f} per chunk")
    print(f"  bakes affordable at $0.05/p-hr   : {0.05/proc_cost:,.0f} per player-hour")
    if B.get("extrapolated_gpu_seconds_7000_iters"):
        g = B["extrapolated_gpu_seconds_7000_iters"]["A100_10pct"]
        cost = g/3600*2.50
        print(f"\n  optimization fit (EXTRAPOLATED A100 @10% peak): {g:.1f} s = ${cost:.4f}/chunk")
        print(f"  bakes affordable at $0.05/p-hr   : {0.05/cost:.1f} per player-hour")
        print(f"  ratio procedural:optimization    : {cost/proc_cost:,.0f}x")
    return {"measured_splat_bytes_per_chunk": int(splat_bytes),
            "assumed_bytes_per_chunk": 1200000,
            "assumption_error_factor": 1.2e6/splat_bytes,
            "procedural_bake_seconds_cpu": bake_seconds,
            "procedural_gaussians": int(N),
            "procedural_bake_usd": proc_cost,
            "bakes_affordable_procedural": 0.05/proc_cost,
            "egress_mb_per_player_hr": gb*1000,
            "egress_usd_per_player_hr": gb*EGRESS,
            "optimization_fit": B.get("extrapolated_gpu_seconds_7000_iters")}

if __name__ == "__main__":
    main()
