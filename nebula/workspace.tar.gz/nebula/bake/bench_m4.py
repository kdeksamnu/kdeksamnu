#!/usr/bin/env python3
"""
bench_m4.py — measure the numbers that actually decide this architecture,
on the machine you are actually building on.

Run it on the MacBook Air M4:

    conda activate base        # or whichever env has torch
    pip install numpy torch lz4 zstandard
    python3 bench_m4.py

It takes ~60-120 s and writes bench_m4_report.json. Send that file back and
every EXTRAPOLATED figure in ARCHITECTURE.md §5b/§5c/§5d gets replaced with a
measurement.

What it measures, and why each one matters:

  1. procedural emission rate      -> the runtime bake cost (§5c path A)
  2. differentiable fit rate       -> the authoring bake cost (§5c path B)
  3. compression throughput        -> the §5d CPU-vs-Metal question
  4. splat payload sizes           -> CDN egress (§5b)
  5. sustained-load thermal drift  -> fanless chassis reality check
  6. memory headroom               -> 16 GB unified, shared with everything

Nothing here needs a discrete GPU. MPS is used where available and skipped
where not, so the same script is comparable across machines.
"""
import json, math, os, platform, subprocess, sys, time
from datetime import datetime

import numpy as np

try:
    import torch
    HAVE_TORCH = True
except ImportError:
    HAVE_TORCH = False

try:
    import lz4.frame as lz4f
except ImportError:
    lz4f = None
try:
    import zstandard as zstd
except ImportError:
    zstd = None

# reuse the real baker rather than reimplementing it
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from bake_chunk import generate_chunk, bake_procedural, write_splat, write_ply, CHUNK
    HAVE_BAKER = True
except Exception as e:
    HAVE_BAKER = False
    BAKER_IMPORT_ERROR = str(e)

R = {"meta": {}, "environment": {}, "emission": {}, "fit": {}, "compression": {},
     "payload": {}, "thermal": {}, "memory": {}, "derived": {}}


def banner(s): print(f"\n\033[1m{'='*72}\n{s}\n{'='*72}\033[0m")
def line(k, v, unit=""): print(f"  {k:<42} {v:>14}  {unit}")
def note(s): print(f"  \033[90m{s}\033[0m")


# ==========================================================================
def environment():
    banner("1. ENVIRONMENT")
    e = R["environment"]
    e["platform"] = platform.platform()
    e["machine"] = platform.machine()
    e["processor"] = platform.processor() or "unknown"
    e["python"] = sys.version.split()[0]
    e["physical_cores"] = os.cpu_count()
    try:
        e["cpu_brand"] = subprocess.check_output(
            ["sysctl", "-n", "machdep.cpu.brand_string"], text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        try:
            e["cpu_brand"] = open("/proc/cpuinfo").read().split("model name\t: ")[1].split("\n")[0]
        except Exception:
            e["cpu_brand"] = "unknown"
    # total RAM
    total = None
    try:
        total = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True).strip())
    except Exception:
        try:
            total = int(open("/proc/meminfo").read().split("MemTotal:")[1].split()[0]) * 1024
        except Exception:
            pass
    e["ram_bytes"] = total
    e["ram_gb"] = round(total / 1e9, 2) if total else None

    if HAVE_TORCH:
        e["torch"] = torch.__version__
        e["mps_available"] = bool(torch.backends.mps.is_available())
        e["mps_built"] = bool(torch.backends.mps.is_built())
        e["cuda_available"] = bool(torch.cuda.is_available())
        e["torch_threads"] = torch.get_num_threads()
        if e["mps_available"]:
            try:
                e["mps_recommended_max_memory_gb"] = round(
                    torch.mps.recommended_max_memory() / 1e9, 2)
            except Exception:
                pass
    else:
        e["torch"] = None
    e["lz4"] = lz4f is not None
    e["zstandard"] = zstd is not None
    e["baker_importable"] = HAVE_BAKER

    for k, v in e.items():
        line(k, v)
    if not HAVE_BAKER:
        note(f"WARNING: could not import bake_chunk ({BAKER_IMPORT_ERROR}); emission tests will be skipped")
    return e


# ==========================================================================
def measure_emission(env):
    """§5c path A — the RUNTIME bake. This is the number that decides whether
    a per-player bake quota is needed at all."""
    banner("2. PROCEDURAL EMISSION  (runtime bake, §5c path A)")
    if not HAVE_BAKER:
        note("skipped: baker not importable"); return
    E = R["emission"]

    t0 = time.perf_counter(); ch = generate_chunk(1337); gen_s = time.perf_counter() - t0
    E["symbolic_gen_ms"] = gen_s * 1000
    line("symbolic chunk generation", f"{gen_s*1000:.1f}", "ms")

    rows = []
    print()
    note(f"  {'density':>8} {'gaussians':>11} {'emit ms':>9} {'M gauss/s':>10} {'.splat KB':>10}")
    for dens in (1, 4, 9, 16, 25, 36):
        # warm
        bake_procedural(ch, density=dens)
        ts = []
        for _ in range(5):
            t = time.perf_counter(); g = bake_procedural(ch, density=dens); ts.append(time.perf_counter() - t)
        dt = min(ts)
        n = g["pos"].shape[0]
        tmp = f"_tmp_{dens}.splat"
        sb, _ = write_splat(tmp, g)
        pb, _, _ = write_ply(f"_tmp_{dens}.ply", g, 0)
        os.remove(tmp); os.remove(f"_tmp_{dens}.ply")
        rows.append({"density": dens, "gaussians": int(n), "emit_seconds": dt,
                     "gaussians_per_second": n / dt, "splat_bytes": int(sb), "ply_bytes": int(pb)})
        print(f"  {dens:>10} {n:>11,} {dt*1000:>9.2f} {n/dt/1e6:>10.2f} {sb/1024:>10.1f}")
    E["sweep"] = rows

    # scaling exponent
    a, b = rows[0], rows[-1]
    if b["gaussians"] > a["gaussians"]:
        E["scaling_exponent"] = math.log(b["emit_seconds"] / a["emit_seconds"]) / math.log(b["gaussians"] / a["gaussians"])
        line("scaling exponent (1.0 = linear)", f"{E['scaling_exponent']:.2f}")
    prod = rows[-2] if len(rows) > 1 else rows[-1]
    E["production"] = prod
    line("production-density gaussians", f"{prod['gaussians']:,}")
    line("production-density emit", f"{prod['emit_seconds']*1000:.2f}", "ms")
    line("production-density .splat", f"{prod['splat_bytes']/1024:.0f}", "KB")

    # how many bakes/sec could this machine sustain, single process?
    E["bakes_per_second_single_core"] = 1.0 / prod["emit_seconds"]
    line("sustainable bakes/sec (1 core)", f"{1.0/prod['emit_seconds']:.0f}")
    note("")
    note(f"  §5c baseline (2x Xeon @2.9 GHz, single unwarmed run): 30,460 gaussians in 6.5 ms.")
    note(f"  This machine (min of 5 warm runs): {prod['gaussians']:,} in {prod['emit_seconds']*1000:.2f} ms.")
    note("  Divide the two for a real cross-machine ratio; do not compare a warm")
    note("  min-of-5 against a cold single run and call it a speedup.")


# ==========================================================================
def measure_fit(env):
    """§5c path B — the AUTHORING bake. Decides whether optimization fitting is
    an overnight job or a publish-time job on this hardware."""
    banner("3. DIFFERENTIABLE FIT  (authoring bake, §5c path B)")
    if not HAVE_TORCH:
        note("skipped: torch not installed"); return
    F = R["fit"]

    def build(device, res, ng):
        pos = (torch.rand(ng, 3, device=device) * 2 - 1).requires_grad_(True)
        logs = torch.zeros(ng, 3, device=device).requires_grad_(True)
        rgb = torch.rand(ng, 3, device=device).requires_grad_(True)
        op = torch.rand(ng, device=device).requires_grad_(True)
        return [pos, logs, rgb, op], pos, logs, rgb, op

    def run(device_name, res, ng, iters=6, tile=256):
        try:
            dev = torch.device(device_name)
            params, pos, logs, rgb, op = build(dev, res, ng)
            opt = torch.optim.Adam(params, lr=2e-3)
            tgt = torch.rand(res * res, 3, device=dev)

            def one_iter():
                opt.zero_grad(set_to_none=True)
                loss = 0.0
                px = (pos[:, 0] * 0.5 + 0.5) * res
                py = (pos[:, 1] * 0.5 + 0.5) * res
                sx = torch.exp(logs[:, 0]).clamp(min=1e-3) * res * 0.9
                sy = torch.exp(logs[:, 1]).clamp(min=1e-3) * res * 0.9
                for y in range(0, res, tile):
                    rows = min(tile, res - y)
                    # both must be (rows*res, 1): yy varies down the tile, xx across it
                    yy = torch.arange(y, y + rows, device=dev, dtype=torch.float32).reshape(-1, 1).expand(-1, res).reshape(-1, 1)
                    xx = torch.arange(res, device=dev, dtype=torch.float32).reshape(1, -1).expand(rows, -1).reshape(-1, 1)
                    dx = (xx - px.reshape(1, -1)) / sx.reshape(1, -1)
                    dy = (yy - py.reshape(1, -1)) / sy.reshape(1, -1)
                    w = torch.exp(-0.5 * (dx * dx + dy * dy)) * op.reshape(1, -1)
                    img = (w.unsqueeze(2) * rgb.reshape(1, -1, 3)).sum(1) / (w.sum(1, keepdim=True) + 1e-6)
                    t = tgt[y * res:(y + rows) * res]
                    ((img - t).abs().mean() * (rows / res)).backward()
                    loss += float((img - t).abs().mean()) * (rows / res)
                opt.step()
                return loss

            one_iter()  # warm / compile
            if device_name == "mps": torch.mps.synchronize()
            ts = []
            for _ in range(iters):
                t = time.perf_counter(); one_iter()
                if device_name == "mps": torch.mps.synchronize()
                elif device_name == "cuda": torch.cuda.synchronize()
                ts.append(time.perf_counter() - t)
            per = min(ts)
            pairs = res * res * ng
            return {"device": device_name, "res": res, "gaussians": ng, "per_iter_s": per,
                    "pairs_per_sec": pairs / per, "loss": ts and None}
        except Exception as e:
            return {"device": device_name, "res": res, "gaussians": ng, "error": f"{type(e).__name__}: {str(e)[:120]}"}

    note("  small config first (fits in memory anywhere), then scale up")
    results = []
    # A tile of (res, ng) costs ~res^2*ng*4 bytes per live intermediate, and the
    # backward pass holds several. Size the configs to the RAM actually present
    # so this script cannot OOM the machine it is measuring.
    ram_gb = env.get("ram_gb") or 8
    budget_bytes = ram_gb * 1e9 * 0.25
    configs = [("cpu", 64, 1024)]
    if 64 * 64 * 4096 * 4 * 6 < budget_bytes:
        configs.append(("cpu", 128, 4096))
    if env.get("mps_available"):
        configs += [("mps", 64, 1024)]
        if 128 * 128 * 4096 * 4 * 6 < budget_bytes:
            configs.append(("mps", 128, 4096))
        if 256 * 256 * 16384 * 4 * 6 < budget_bytes:
            configs.append(("mps", 256, 16384))
    note(f"  RAM {ram_gb:.1f} GB -> intermediate budget {budget_bytes/1e9:.2f} GB -> configs {[(d, r, n) for d, r, n in configs]}")
    for dev, res, ng in configs:
        r = run(dev, res, ng, tile=min(64, res))
        results.append(r)
        if "error" in r:
            print(f"  {dev:>4} {res}x{res} ng={ng:<7,} ERROR {r['error']}")
        else:
            print(f"  {dev:>4} {res}x{res} ng={ng:<7,} {r['per_iter_s']*1000:8.1f} ms/iter   {r['pairs_per_sec']/1e6:8.1f} M pairs/s")
    F["measurements"] = results

    good = [r for r in results if "error" not in r]
    if good:
        best = max(good, key=lambda r: r["pairs_per_sec"])
        F["best_device"] = best["device"]
        F["best_pairs_per_sec"] = best["pairs_per_sec"]
        # production workload: 256x256 render, 100k gaussians, 7000 iterations
        prod_pairs = 256 * 256 * 100_000
        F["production_pairs_per_iter"] = prod_pairs
        F["production_seconds_per_iter"] = prod_pairs / best["pairs_per_sec"]
        F["production_7000_iters_minutes"] = prod_pairs / best["pairs_per_sec"] * 7000 / 60
        print()
        line("best device for this workload", best["device"])
        line("throughput", f"{best['pairs_per_sec']/1e6:.1f}", "M pixel-gaussian pairs/s")
        line("production chunk = 256^2 x 100k gaussians", f"{prod_pairs/best['pairs_per_sec']:.2f}", "s/iter")
        line("7,000 iterations", f"{F['production_7000_iters_minutes']:.0f}", "minutes")
        note("")
        note(f"  §5c EXTRAPOLATED 28.4 min for this on an A100 (tiled+culled, 100x this CPU).")
        note(f"  Measured here: {F['production_7000_iters_minutes']:.0f} min on {best['device']}.")
        note("  If this is hours, path B is an OFFLINE AUTHORING job only — never in the live loop.")


# ==========================================================================
def measure_compression(env):
    """§5d — the CPU-vs-Metal question, answered with throughput on real bytes."""
    banner("4. COMPRESSION THROUGHPUT  (§5d CPU vs Metal)")
    if not HAVE_BAKER:
        note("skipped: baker not importable"); return
    if lz4f is None and zstd is None:
        note("skipped: install lz4 and/or zstandard"); return
    C = R["compression"]

    ch = generate_chunk(1337)
    g = bake_procedural(ch, density=25)
    tmp = "_tmp_comp.splat"
    sb, n = write_splat(tmp, g)
    raw = open(tmp, "rb").read(); os.remove(tmp)
    C["splat_bytes"] = len(raw); C["gaussians"] = n
    line("payload: real .splat bytes", f"{len(raw)/1024:.0f}", "KB")

    # Also a dense voxel payload, for the §5d comparison. It must be a genuinely
    # SPATIALLY COHERENT 3D field — not noise (incompressible by construction, which
    # would unfairly flatter the sparse format) and not a 2D slice extruded along z
    # (degenerate, compresses ~200x and unfairly condemns the dense format).
    # Trilinear upsample of a coarse random lattice gives real 3D structure at a
    # correlation length similar to solved voxel world data.
    D = 128
    coarse = np.random.default_rng(0).standard_normal((9, 9, 9)).astype(np.float32)
    gz = np.linspace(0, 8, D).astype(np.float32)
    i0 = gz.astype(np.int32); i1 = np.minimum(i0 + 1, 8); t = (gz - i0)[:, None, None]
    gy = np.linspace(0, 8, D).astype(np.float32)
    j0 = gy.astype(np.int32); j1 = np.minimum(j0 + 1, 8); u = (gy - j0)[None, :, None]
    gx = np.linspace(0, 8, D).astype(np.float32)
    k0 = gx.astype(np.int32); k1 = np.minimum(k0 + 1, 8); v = (gx - k0)[None, None, :]
    c000 = coarse[i0][:, j0][:, :, k0]; c100 = coarse[i1][:, j0][:, :, k0]
    c010 = coarse[i0][:, j1][:, :, k0]; c110 = coarse[i1][:, j1][:, :, k0]
    c001 = coarse[i0][:, j0][:, :, k1]; c101 = coarse[i1][:, j0][:, :, k1]
    c011 = coarse[i0][:, j1][:, :, k1]; c111 = coarse[i1][:, j1][:, :, k1]
    x00 = c000 * (1 - v) + c100 * v; x10 = c010 * (1 - v) + c110 * v
    x01 = c001 * (1 - v) + c101 * v; x11 = c011 * (1 - v) + c111 * v
    y0 = x00 * (1 - u) + x10 * u; y1 = x01 * (1 - u) + x11 * u
    field = y0 * (1 - t) + y1 * t
    field = (field - field.min()) / (np.ptp(field) + 1e-9)
    dense = np.clip(field * 255, 0, 255).astype(np.uint8).tobytes()
    assert len(dense) == D ** 3, f"dense payload should be {D**3} bytes, got {len(dense)}"
    line("payload: dense 128^3 coherent voxels", f"{len(dense)/1e6:.2f}", "MB")

    def bench(fn, data, reps=3):
        ts = []
        out = None
        for _ in range(reps):
            t = time.perf_counter(); out = fn(data); ts.append(time.perf_counter() - t)
        return min(ts), len(out)

    print()
    note(f"  {'codec':<14} {'payload':<16} {'ms':>8} {'GB/s in':>9} {'ratio':>7}")
    rows = []
    codecs = []
    if lz4f:
        codecs += [("lz4 -1", lambda d: lz4f.compress(d, compression_level=1)),
                   ("lz4 -9", lambda d: lz4f.compress(d, compression_level=9))]
    if zstd:
        codecs += [("zstd -3", lambda d: zstd.ZstdCompressor(level=3).compress(d)),
                   ("zstd -9", lambda d: zstd.ZstdCompressor(level=9).compress(d)),
                   ("zstd -19", lambda d: zstd.ZstdCompressor(level=19).compress(d))]
    for name, fn in codecs:
        for label, data in (("splat", raw), ("dense voxels", dense)):
            t, outsz = bench(fn, data)
            ratio = len(data) / outsz
            rows.append({"codec": name, "payload": label, "bytes_in": len(data),
                         "seconds": t, "bytes_out": outsz, "ratio": ratio,
                         "gb_per_sec": len(data) / t / 1e9})
            print(f"  {name:<14} {label+' '+format(len(data)/1e6,'.2f')+'MB':<16} {t*1000:>8.1f} {len(data)/t/1e9:>9.2f} {ratio:>7.2f}x")
    C["measurements"] = rows

    splat_rows = [r for r in rows if r["payload"] == "splat"]
    if splat_rows:
        fastest = max(splat_rows, key=lambda r: r["gb_per_sec"])
        C["fastest_codec"] = fastest["codec"]
        C["fastest_gb_per_sec"] = fastest["gb_per_sec"]
        C["fastest_ratio"] = fastest["ratio"]
        # project to a 16.78 MB chunk (the §5d figure)
        C["seconds_for_16_78MB"] = 16.78e6 / (fastest["gb_per_sec"] * 1e9)
        print()
        line("fastest codec on splat bytes", fastest["codec"])
        line("throughput", f"{fastest['gb_per_sec']:.2f}", "GB/s")
        line("best ratio achieved", f"{max(r['ratio'] for r in splat_rows):.2f}", "x")
        line("time to compress 16.78 MB", f"{C['seconds_for_16_78MB']*1000:.1f}", "ms")
        note("")
        note("  §5d measured 0.46 GB/s for lz4-1 on 2x Xeon. Compare your number above.")
        note("  If splat payloads are ~1 MB, CPU compression is ~2 ms and the Metal")
        note("  shader question is moot. If you insist on dense voxels, it is not.")


# ==========================================================================
def measure_thermal(env):
    """Fanless chassis: does sustained baking throttle? This decides whether a
    local bake farm on the Air is viable or whether bakes must be batched."""
    banner("5. SUSTAINED LOAD / THERMAL DRIFT  (fanless chassis check)")
    if not HAVE_BAKER:
        note("skipped: baker not importable"); return
    T = R["thermal"]
    ch = generate_chunk(1337)
    note("  running procedural emission continuously for 20 s, reporting per-second rate")
    print()
    rates = []
    t_end = time.perf_counter() + 20.0
    sec_start = time.perf_counter(); count = 0
    while time.perf_counter() < t_end:
        bake_procedural(ch, density=16)
        count += 1
        now = time.perf_counter()
        if now - sec_start >= 1.0:
            rates.append(count / (now - sec_start))
            print(f"    second {len(rates):>2}: {rates[-1]:7.1f} bakes/s")
            count = 0; sec_start = now
    if len(rates) >= 4:
        first = sum(rates[:3]) / 3
        last = sum(rates[-3:]) / 3
        T["rates_per_second"] = rates
        T["first_3s_avg"] = first
        T["last_3s_avg"] = last
        T["throttle_pct"] = (1 - last / first) * 100
        print()
        line("first 3 s average", f"{first:.1f}", "bakes/s")
        line("last 3 s average", f"{last:.1f}", "bakes/s")
        line("throughput loss", f"{T['throttle_pct']:+.1f}", "%")
        note("")
        if T["throttle_pct"] > 15:
            note("  >15% loss: a sustained local bake farm on this chassis will throttle.")
            note("  Batch bakes with idle gaps, or bake on a plugged-in desktop / cloud job.")
        else:
            note("  Minimal throttling at this load. Sustained local baking looks viable.")
        note("  NOTE: this load is light (numpy, ~1 core). A real MPS bake farm will")
        note("  thermally saturate a fanless Air much harder. Re-run with the fit workload.")


# ==========================================================================
def measure_memory(env):
    banner("6. MEMORY HEADROOM  (16 GB unified, shared with everything)")
    M = R["memory"]
    if HAVE_TORCH and env.get("mps_available"):
        try:
            rec = torch.mps.recommended_max_memory()
            cur = torch.mps.current_allocated_memory()
            drv = torch.mps.driver_allocated_memory()
            M["mps_recommended_max_gb"] = round(rec / 1e9, 2)
            M["mps_driver_allocated_gb"] = round(drv / 1e9, 2)
            line("MPS recommended max", f"{rec/1e9:.2f}", "GB")
            line("MPS driver allocated", f"{drv/1e9:.2f}", "GB")
        except Exception as e:
            note(f"mps memory query failed: {e}")
    if env.get("ram_gb"):
        rec = M.get("mps_recommended_max_gb")
        if rec:
            line("headroom for macOS + browser + IDE", f"{env['ram_gb']-rec:.2f}", "GB")
        note("")
        note("  Client chunk cache budget (§5b) assumed 2 GB desktop / 256 MB mobile.")
        note("  On a 16 GB Air with a browser open, verify the cache fits alongside")
        note("  the WebGPU device, the decoder, and the OS. Browsers also enforce")
        note("  their own storage quota, which is usually tighter than you expect.")


# ==========================================================================
def derive(env):
    banner("7. WHAT THIS CHANGES IN THE ARCHITECTURE")
    D = R["derived"]
    E = R["emission"].get("production")
    if E:
        per_bake_usd_local = 0.0  # local machine: marginal cost is electricity
        D["runtime_bake_cost_usd"] = "effectively 0 — bakes run on your own machine"
        D["bakes_per_hour_this_machine"] = 3600 / E["emit_seconds"]
        line("bakes/hour this machine can sustain", f"{D['bakes_per_hour_this_machine']:,.0f}")
        note("")
        note("  §5c found 552,830 bakes/player-hour affordable on cloud CPU at $0.05/hr.")
        note("  On your own machine the marginal cost is electricity, so the bake quota")
        note("  governor is unnecessary for DEVELOPMENT and for a small self-hosted shard.")
        note("  It becomes necessary again the moment you run a bake farm for other")
        note("  people's worlds — that is a cloud-cost line, not a local one.")
    F = R["fit"]
    if F.get("production_7000_iters_minutes"):
        m = F["production_7000_iters_minutes"]
        D["authoring_bake_minutes"] = m
        line("authoring bake (7k iters, production chunk)", f"{m:.0f}", "min")
        verdict = ("overnight authoring job" if m > 60 else
                   "publish-time job (minutes)" if m > 10 else "fast enough to consider interactively")
        D["authoring_verdict"] = verdict
        line("verdict", verdict)
    C = R["compression"]
    if C.get("seconds_for_16_78MB"):
        line("compress 16.78 MB dense voxels", f"{C['seconds_for_16_78MB']*1000:.0f}", "ms")
        if C.get("splat_bytes"):
            est = C["seconds_for_16_78MB"] * C["splat_bytes"] / 16.78e6
            line("compress a real splat chunk instead", f"{est*1000:.1f}", "ms")
            D["compress_splat_ms"] = est * 1000
    print()
    note("  The three decisions that matter are unchanged by hardware:")
    note("    representation  dense voxels -> sparse gaussians      ~17.6x")
    note("    transport       full-state   -> delta + uniform phase  ~95x")
    note("    bake mechanism  optimization -> procedural emission   ~10^7x")
    note("  This machine changes the COST of each, not the RANKING.")


def main():
    R["meta"] = {"generated": datetime.now().isoformat(timespec="seconds"),
                 "script": "bench_m4.py", "version": 1}
    env = environment()
    measure_emission(env)
    measure_fit(env)
    measure_compression(env)
    measure_thermal(env)
    measure_memory(env)
    derive(env)
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bench_m4_report.json")
    with open(out, "w") as f:
        json.dump(R, f, indent=2, default=str)
    banner(f"report written to {out}")
    note("Send that file back and the extrapolations in §5b/§5c/§5d become measurements.")


if __name__ == "__main__":
    main()
