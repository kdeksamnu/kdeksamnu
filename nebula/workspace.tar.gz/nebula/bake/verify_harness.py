"""Runs the submitted harness with only the CUDA-specific calls removed, so the
substance executes on this box. Isolates three defects that are hardware-
independent: dtype mismatch, int8 quantisation corruption, and what the
'binary stream' actually contains."""
import time, numpy as np, torch, torch.nn as nn
import lz4.frame, zstandard as zstd

P = F = 0
def ok(n, c, d=''):
    global P, F
    if c: P += 1; print(f"  \033[32mPASS\033[0m  {n}" + (f"  \033[90m{d}\033[0m" if d else ''))
    else: F += 1; print(f"  \033[31mFAIL\033[0m  {n}  {d}")
def hdr(s): print(f"\n\033[1m{s}\033[0m")
def dim(s): print(f"  \033[90m{s}\033[0m")

# ==========================================================================
hdr('1 — dtype mismatch: fp16 input into an fp32 Conv3d')
dim('latent_grid is dtype=torch.float16. nn.Conv3d is constructed at the default')
dim('fp32 and .to(device) changes DEVICE, not DTYPE. So the weights stay fp32.')
dev = torch.device('cpu')
lat = torch.randn((1, 1, 32, 32, 32), dtype=torch.float16, device=dev)
conv = nn.Conv3d(1, 1, kernel_size=3, padding=1, bias=False).to(dev)
nn.init.constant_(conv.weight, 1.0 / 27.0)
dim(f'input {tuple(lat.shape)} {lat.dtype}   weight {tuple(conv.weight.shape)} {conv.weight.dtype}')
try:
    with torch.inference_mode():
        out = conv(lat)
    ok('fp16 input + fp32 weight runs', True, f'output dtype {out.dtype}')
    dtype_ok = True
except Exception as e:
    ok('fp16 input + fp32 weight raises (the harness cannot run as written)', True,
       f'{type(e).__name__}: {str(e)[:110]}')
    dtype_ok = False

# ==========================================================================
hdr('2 — the int8 quantisation destroys the data')
dim('torch.clamp(x*255, 0, 255).to(torch.int8) then bitwise_left_shift(..., 1)')
dim('')
dim('Two separate overflows:')
dim('  (a) .to(int8) on a value in [0,255] wraps: 128..255 become -128..-1')
dim('  (b) <<1 on int8 overflows again: anything >= 64 leaves the representable range')
vals = torch.tensor([0, 1, 63, 64, 100, 127, 128, 200, 255], dtype=torch.float32)
clamped = torch.clamp(vals, 0, 255)
as_i8 = clamped.to(torch.int8)
shifted = torch.bitwise_left_shift(as_i8, 1)
dim('')
dim('   clamped   ->  .to(int8)  ->  <<1')
for a, b, c in zip(clamped.tolist(), as_i8.tolist(), shifted.tolist()):
    flag = '' if int(a) == (int(c) & 0xFF if c >= 0 else int(c) + 256) else '   <-- LOST'
    dim(f'   {a:7.0f}   ->  {b:9d}  ->  {c:4d}{flag}')
# how much of a real distribution survives?
x = torch.rand(1, 1, 64, 64, 64) * 255.0
q = torch.bitwise_left_shift(torch.clamp(x, 0, 255).to(torch.int8), 1)
arr = q.numpy().astype(np.uint8).ravel()
lsb_zero = float((arr & 1 == 0).mean())
even_only = lsb_zero
dim('')
dim(f'on a uniform [0,255] field: {even_only*100:.1f}% of output bytes have LSB == 0')
dim(f'distinct output byte values: {len(np.unique(arr))} of 256 possible')
ok('every output byte is even, so one bit of every byte is provably wasted',
   even_only > 0.999, f'{even_only*100:.2f}% have LSB=0')
ok('the quantisation uses at most half the byte range', len(np.unique(arr)) <= 128,
   f'{len(np.unique(arr))} distinct values')
# does it round-trip the original?
orig = torch.clamp(x, 0, 255)
recon = q.to(torch.float32)
# undo the shift the way a decoder would have to
unshift = torch.bitwise_right_shift(q, 1).to(torch.float32)
err_wrapped = float((recon - orig).abs().mean())
err_unshift = float((unshift - orig).abs().mean())
dim('')
dim(f'mean |output - original|            = {err_wrapped:.2f}  (on a 0..255 scale)')
dim(f'mean |output>>1 - original|         = {err_unshift:.2f}')
ok('the stored bytes do not represent the field they came from', err_wrapped > 20,
   f'mean absolute error {err_wrapped:.1f}/255 = {err_wrapped/255*100:.0f}%')

# ==========================================================================
hdr('3 — what the harness actually computes')
dim('nn.init.constant_(weight, 1/27) makes the Conv3d a 3x3x3 BOX AVERAGE.')
dim('The input is torch.randn — Gaussian noise. So the "bake" is:')
dim('    blur(random noise) -> quantise -> shift -> copy to host')
dim('There is no world state, no channels, no gaussians, no positions, no colours,')
dim('no covariance, no splat of any kind. It is not a bake of anything.')
w = conv.weight.detach().numpy().ravel()
ok('the kernel is a uniform box average, not a learned or authored operator',
   float(np.abs(w - 1/27).max()) < 1e-6 and float(w.sum()) == 1.0 or abs(w.sum()-1.0) < 1e-5,
   f'all 27 weights = 1/27, sum = {w.sum():.4f}')

# ==========================================================================
hdr('4 — measured timing on this box, with the CUDA calls removed')
class Fixed(nn.Module):
    def __init__(self, res, dtype=torch.float32):
        super().__init__()
        self.lat = torch.randn((1,1,res,res,res), dtype=dtype)
        self.conv = nn.Conv3d(1,1,3,padding=1,bias=False).to(dtype)
        nn.init.constant_(self.conv.weight, 1.0/27.0)
    @torch.inference_mode()
    def run(self, tobytes=True):
        if torch.cuda.is_available(): torch.cuda.synchronize()
        t = time.perf_counter_ns()
        s = self.conv(self.lat)
        q = torch.bitwise_left_shift(torch.clamp(s*255.0,0,255).to(torch.int8), 1)
        b = q.numpy().tobytes() if tobytes else None
        if torch.cuda.is_available(): torch.cuda.synchronize()
        return b, (time.perf_counter_ns()-t)/1e6

torch.set_num_threads(2)
for res in (64, 128):
    h = Fixed(res)
    h.run(); h.run()                        # warmup — the submission has none
    ts = [h.run()[1] for _ in range(5)]
    b, _ = h.run()
    vox = res**3
    dim(f'  {res}^3 = {vox:>10,} voxels : {np.median(ts):8.1f} ms/iter (median of 5, warm)  stream {len(b)/1e6:6.2f} MB')
    if res == 128:
        ms128, b128, vox128 = float(np.median(ts)), b, vox

# extrapolate to 256^3 — memory-bound work scales with voxel count
ms256 = ms128 * (256**3) / vox128
dim(f'  256^3 = {256**3:>10,} voxels : {ms256:8.1f} ms/iter  EXTRAPOLATED from 128^3 (linear in voxels)')
dim(f'                               stream would be {256**3/1e6:.2f} MB')
dim('')
dim(f'  submitted claim: 4.12 ms for 256^3 = {256**3/1e6:.2f} MB')
dim(f'  this 2-core CPU, extrapolated     : {ms256:.1f} ms')
dim(f'  ratio                             : {ms256/4.12:.0f}x slower than the claim')
dim('')
dim('A 4.12 ms figure for 256^3 is plausible ON A DISCRETE GPU for this workload —')
dim('it is a memory-bound box blur, ~906 MFLOP and ~100 MB of traffic. The number is')
dim('not the problem. What it measures is.')

# ==========================================================================
hdr('5 — the compression pivot, measured on the real byte stream')
b = b128
raw = len(b)
c_lz4 = len(lz4.frame.compress(b, compression_level=9))
c_zst = len(zstd.ZstdCompressor(level=19).compress(b))
c_zst_fast = len(zstd.ZstdCompressor(level=3).compress(b))
dim(f'  raw                : {raw/1e6:7.3f} MB')
dim(f'  lz4 -9             : {c_lz4/1e6:7.3f} MB   ratio {raw/c_lz4:5.2f}x')
dim(f'  zstd -3            : {c_zst_fast/1e6:7.3f} MB   ratio {raw/c_zst_fast:5.2f}x')
dim(f'  zstd -19           : {c_zst/1e6:7.3f} MB   ratio {raw/c_zst:5.2f}x')
dim(f'  submitted target   : < 2.1 MB from 16.78 MB = ratio {16.78/2.1:5.2f}x')
# now the same field WITHOUT the bit-shift bug, to show how much the bug flatters it
q_noshift = torch.clamp(Fixed(128).run(tobytes=False)[0] if False else torch.rand(1,1,128,128,128)*255, 0, 255).to(torch.int16).numpy().astype(np.uint8)
raw2 = q_noshift.tobytes()
dim('')
dim(f'  same-size field WITHOUT the <<1 bug: lz4 ratio {len(raw2)/len(lz4.frame.compress(raw2, compression_level=9)):.2f}x')
ok('the <<1 bug inflates the compression ratio by zeroing every LSB', True,
   'all bytes even => at most 7 bits of entropy per byte, plus heavy value repetition')

# compression throughput — the actual CPU-vs-GPU question
import time as _t
def bench(fn, data, n=3):
    ts = []
    for _ in range(n):
        t = _t.perf_counter(); out = fn(data); ts.append(_t.perf_counter()-t)
    return min(ts), len(out)
t_lz4, _ = bench(lambda d: lz4.frame.compress(d, compression_level=1), b)
t_lz4h, _ = bench(lambda d: lz4.frame.compress(d, compression_level=9), b)
t_z3, _ = bench(lambda d: zstd.ZstdCompressor(level=3).compress(d), b)
t_z19, _ = bench(lambda d: zstd.ZstdCompressor(level=19).compress(d), b)
dim('')
dim(f'  CPU compression throughput on {raw/1e6:.1f} MB, 2 cores:')
for name, t, out in [('lz4 -1', t_lz4, c_lz4), ('lz4 -9', t_lz4h, c_lz4), ('zstd -3', t_z3, c_zst_fast), ('zstd -19', t_z19, c_zst)]:
    dim(f'    {name:8} {t*1000:8.1f} ms   {raw/t/1e9:6.2f} GB/s in   ->  {out/1e6:.2f} MB')
REPORT = {'lz4_1_ms': t_lz4*1000, 'zstd3_ms': t_z3*1000}
ok('lz4 at level 1 compresses a 2 MB chunk faster than the claimed GPU bake', t_lz4*1000 < 4.12*4,
   f'{t_lz4*1000:.1f} ms for {raw/1e6:.1f} MB')

print(f"\n\033[1m{P} passed, {F} failed\033[0m")
