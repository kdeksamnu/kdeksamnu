"""
budget_m4.py — turn the MLAOS-Prime doctrine into numbers.

The source document is a resource-governance design. It is sound, and it is
entirely qualitative: memory envelopes are ranges, the scheduler has four
unspecified weights, thermal states have no thresholds, and SSD longevity is a
doctrine rather than a budget.

This computes the four numbers the document needs before it can be implemented:

  A. the 60 Hz frame budget vs simulation cell count
  B. SSD write endurance under the 1.5 Hz persistence pulse
  C. the recovery point objective the 1.5 Hz pulse silently chooses
  D. whether the stated memory envelopes actually sum to 16 GB

Uses the measured per-cell simulation cost from nebula/bench.js rather than a
guess, and scales it to M4 with a stated, adjustable factor.
"""
import json, math

# ---------------------------------------------------------------- measured
# From nebula/bench.js on 2x Xeon @ 2.90 GHz:
#   micro-sim tick, 10,240 cells : 51.9 ms / 100 ticks = 0.519 ms/tick
#   => 50.7 ns per cell per tick
NS_PER_CELL_TICK_XEON = 51.9e6 / 100 / 10240          # ns
# M4 P-core vs Xeon @2.9GHz for scalar numpy-ish loops: conservatively 2.0x.
# Adjust this one constant when bench_m4.py reports a real number.
M4_SPEEDUP = 2.0
NS_PER_CELL_TICK_M4 = NS_PER_CELL_TICK_XEON / M4_SPEEDUP

FRAME_MS = 1000.0 / 60.0
GB = 1e9

def hdr(s): print(f"\n\033[1m{s}\033[0m")
def dim(s): print(f"  \033[90m{s}\033[0m")
def row(a, b, c=""): print(f"  {a:<44} {b:>14}  {c}")

print("=" * 78)
print("MLAOS-Prime: doctrine -> budget")
print("=" * 78)
dim(f"measured sim cost   : {NS_PER_CELL_TICK_XEON:.1f} ns/cell/tick (2x Xeon @2.9GHz)")
dim(f"assumed M4 speedup  : {M4_SPEEDUP:.1f}x  -> {NS_PER_CELL_TICK_M4:.1f} ns/cell/tick")
dim(f"                     SUBSTITUTE THE MEASURED VALUE FROM bench_m4.py")

# =========================================================================
hdr("A. THE 60 Hz FRAME BUDGET vs SIMULATION SIZE")
dim("LAW IX demands determinism; §V demands 60 Hz. Both are affordable only up to")
dim("a cell count the document never states. At 16.667 ms/frame the simulation is")
dim("competing with ECS, physics, Metal rendering, and the OS on 4P+6E cores.")
print()
dim(f"  {'budget for sim':>16} {'frame ms':>9} {'max cells':>12} {'cube edge':>10}   what fits")
budgets = [(0.50, "half the frame — leaves room for render+ECS"),
           (0.25, "a quarter — realistic with Metal rendering"),
           (0.10, "a tenth — comfortable")]
results_A = []
for frac, label in budgets:
    ms = FRAME_MS * frac
    cells = ms * 1e6 / NS_PER_CELL_TICK_M4
    edge = int(round(cells ** (1 / 3)))
    results_A.append({"fraction": frac, "ms": ms, "cells": cells, "edge": edge})
    print(f"  {frac*100:>15.0f}% {ms:>9.2f} {cells:>12,.0f} {edge:>10}^3   {label}")
print()
dim("  Reference points:")
for name, n in [("nebula prototype (128x80 2D)", 10240),
                ("12^3 sector (submitted orchestrator)", 12**3),
                ("32^3 sector", 32**3),
                ("64^3 sector", 64**3),
                ("256^3 volume (submitted harness)", 256**3)]:
    ms = n * NS_PER_CELL_TICK_M4 / 1e6
    pct = ms / FRAME_MS * 100
    verdict = "FITS" if pct < 25 else ("TIGHT" if pct < 100 else f"OVER BUDGET {ms/FRAME_MS:.0f}x")
    print(f"    {name:<38} {n:>10,} cells  {ms:>8.2f} ms  {pct:>6.1f}% of frame   {verdict}")
print()
q = results_A[1]
dim(f"  => At a realistic 25% budget the ceiling is ~{q['cells']:,.0f} cells = a {q['edge']}^3 sector.")
ms64 = 262144 * NS_PER_CELL_TICK_M4 / 1e6
dim(f"     A 64^3 sector (262,144 cells) costs {ms64:.1f} ms = {ms64/FRAME_MS*100:.0f}% of the frame,")
dim("     before ECS, physics, Metal rendering or the OS. That is survivable but it")
dim("     leaves ~10 ms for everything else, and it is 2.6x over a realistic 25%")
dim("     simulation budget. A 256^3 volume is 26x over the WHOLE frame — not close.")
dim("     So §V's 60 Hz target and large sectors are in direct tension. Either shrink")
dim("     the sector, or use the analytic jump-ahead from I4: unobserved regions do")
dim("     not need 60 Hz at all.")
dim("     analytic jump-ahead from I4: unobserved regions do not need 60 Hz at all.")
dim("     That is the single largest saving available and the document doesn't mention it.")

# =========================================================================
hdr("B. SSD WRITE ENDURANCE UNDER THE 1.5 Hz PERSISTENCE PULSE")
dim("§XII says 'avoid unnecessary high-frequency writes' but sets no budget.")
dim("This is computable. Apple does not publish TBW for the Air's SSD; 256 GB TLC")
dim("parts in this class are typically rated 150-300 TBW. We use 150 as the floor.")
TBW_RATED = 150e12
PULSE_HZ = 1.5
WAL_AMP = 2.0        # WAL mode rewrites pages; 2x is conservative, not worst case
print()
dim(f"  {'delta size':>12} {'raw/day':>11} {'w/ WAL x2':>11} {'TBW/yr':>9} {'% of 150TBW':>12} {'years to 100%':>14}")
results_B = []
for kb in (1, 4, 16, 64, 256, 1024):
    b = kb * 1024
    per_sec = b * PULSE_HZ
    per_day = per_sec * 86400
    with_wal = per_day * WAL_AMP
    per_year = with_wal * 365
    pct = per_year / TBW_RATED * 100
    years = TBW_RATED / per_year if per_year else float('inf')
    results_B.append({"delta_kb": kb, "gb_per_day": with_wal / GB, "tbw_per_year": per_year / 1e12,
                      "pct_of_rated_per_year": pct, "years_to_exhaust": years})
    print(f"  {kb:>9} KB {per_day/GB:>9.2f} GB {with_wal/GB:>9.2f} GB {per_year/1e12:>7.1f} TB {pct:>11.2f}% {years:>13.1f}")
print()
dim("  Assumes 24/7 operation, which is the worst case; a dev machine running 6 h/day")
dim("  divides every figure by 4.")
good = [r for r in results_B if r["pct_of_rated_per_year"] < 5]
dim(f"  => Deltas up to ~{max(r['delta_kb'] for r in good)} KB keep annual wear under 5% of a 150 TBW rating.")
dim(f"     At 64 KB deltas you consume {results_B[3]['pct_of_rated_per_year']:.1f}%/yr — fine for a decade.")
dim(f"     At 1 MB deltas it is {results_B[5]['pct_of_rated_per_year']:.1f}%/yr — the SSD becomes a")
dim("     consumable with a service life shorter than the project. LAW VII (delta")
dim("     before snapshot) is therefore not a preference, it is what keeps the")
dim("     machine alive. The document states the law but not the number that makes it a law.")
dim("")
dim("  Also unpriced: §XI cold archive + §XXX cloud replica re-write the same bytes.")
dim("  Every extra copy multiplies wear. Content-addressed dedup (§XII) is what stops")
dim("  that compounding; it is listed as a preference, but it is load-bearing here.")

# =========================================================================
hdr("C. THE RECOVERY POINT OBJECTIVE THE 1.5 Hz PULSE SILENTLY CHOOSES")
rpo_ms = 1000.0 / PULSE_HZ
rpo_ticks = rpo_ms / FRAME_MS
dim(f"§VI.3 commits at 1.5 Hz = one commit every {rpo_ms:.1f} ms.")
dim(f"At 60 Hz that is {rpo_ticks:.0f} simulation ticks of uncommitted work.")
print()
row("recovery point objective (RPO)", f"{rpo_ms:.0f}", "ms")
row("simulation ticks lost on crash", f"{rpo_ticks:.0f}", "ticks")
row("player edits lost at 1 edit/sec", f"{rpo_ms/1000:.2f}", "edits")
dim("")
dim("  §XXXI ranks State Integrity above everything else, and §XXVII assumes writes")
dim("  are interrupted. Those two together mean the RPO is the most important number")
dim("  in the document, and it is currently an accident of a pulse frequency chosen")
dim("  for throughput reasons.")
dim("")
dim("  This is a decision, not a constant:")
for hz, note in ((1.5, "as specified"), (5, "5x the write load"), (20, "20x the write load"), (60, "every tick — 40x the wear of 1.5 Hz")):
    ms = 1000 / hz
    print(f"    {hz:>5.1f} Hz  ->  RPO {ms:>6.1f} ms  ({ms/FRAME_MS:>4.0f} ticks)   {note}")
dim("")
dim("  => 667 ms RPO is almost certainly fine for a worldbuilding game and cheap on")
dim("     the SSD. But the intent log (§VIII deltas, LAW I ancestry) already gives you")
dim("     crash-safe recovery at zero extra write cost IF the log is fsync'd separately")
dim("     from the snapshot. Append the intent, fsync, then let the 1.5 Hz pulse do the")
dim("     expensive Merkle commit. RPO drops to ~0 without changing the pulse.")
dim("     That distinction — log durability vs snapshot cadence — is missing entirely.")

# =========================================================================
hdr("D. DO THE MEMORY ENVELOPES ACTUALLY SUM TO 16 GB?")
env = [
    ("macOS + WindowServer + IDE + shell", 4.0, 4.5, "Critical"),
    ("Cathedral runtime", 2.0, 3.0, "Critical"),
    ("Local LLM inference", 4.0, 6.0, "High"),
    ("Docker / services", 1.5, 3.0, "Medium"),
    ("Metal / GPU transient buffers", 1.0, 2.0, "High"),
]
headroom = (1.5, 2.0)
lo = sum(e[1] for e in env); hi = sum(e[2] for e in env)
print()
dim(f"  {'domain':<40} {'low':>6} {'high':>6}  priority")
for name, l, h, p in env:
    dim(f"  {name:<40} {l:>5.1f}G {h:>5.1f}G  {p}")
dim(f"  {'runtime headroom (mandatory)':<40} {headroom[0]:>5.1f}G {headroom[1]:>5.1f}G  Mandatory")
print()
row("sum of targets (low)", f"{lo + headroom[0]:.1f}", "GB")
row("sum of targets (high)", f"{hi + headroom[1]:.1f}", "GB")
row("physical unified memory", "16.0", "GB")
row("slack at low targets", f"{16 - (lo + headroom[0]):+.1f}", "GB")
row("overcommit at high targets", f"{(hi + headroom[1]) - 16:+.1f}", "GB")
print()
over = (hi + headroom[1]) - 16
if over > 0:
    dim(f"  => The HIGH column overcommits by {over:.1f} GB. That is not a documentation")
    dim("     error, it is the whole point of §2.1: these are soft envelopes and the")
    dim("     high ends are mutually exclusive. But the document never says WHICH")
    dim("     combinations are legal. Without that, the admission controller (§XXV)")
    dim("     has nothing to admit against.")
    dim("")
    dim("     The four runtime modes (§XXXII) are implicitly the answer, so make them")
    dim("     explicit as envelope sets and let the admission controller enforce them:")
    modes = {
        "A Development": [("macOS+IDE", 4.5), ("Cathedral", 3.0), ("LLM 7-8B Q4", 5.0), ("Docker", 1.5), ("Metal", 1.0)],
        "B Simulation":  [("macOS+IDE", 4.0), ("Cathedral", 3.0), ("LLM 7B Q4", 4.5), ("Docker", 0.0), ("Metal", 2.0)],
        "C Generation":  [("macOS", 3.5), ("Cathedral", 0.5), ("Diffusion", 8.0), ("Docker", 0.0), ("Metal", 2.0)],
        "D Archive":     [("macOS", 3.5), ("Cathedral", 0.5), ("LLM", 0.0), ("DuckDB+zstd", 4.0), ("Metal", 0.5)],
    }
    dim("")
    for m, parts in modes.items():
        tot = sum(v for _, v in parts) + 1.5   # + mandatory headroom
        flag = "OK" if tot <= 16 else f"OVER by {tot-16:.1f}G"
        detail = " + ".join(f"{k} {v:g}" for k, v in parts)
        dim(f"     MODE {m:<13} {detail:<52} = {tot:>5.1f}G  {flag}")
    dim("")
    dim("     Mode C is the binding one: an 8 GB diffusion model plus Metal plus headroom")
    dim("     leaves ~3 GB for macOS, which will swap. Either the diffusion model is")
    dim("     smaller than 8 GB resident, or Mode C must also close the IDE. §XIV says")
    dim("     'load one heavy system at a time' — this is the arithmetic that proves it.")

# =========================================================================
hdr("E. THE MISSING NUMBER: WHAT IS THE PAYLOAD?")
dim("Everything above governs resources around a workload the document never sizes.")
dim("The three measured decisions from §5b-§5d determine that workload:")
print()
dim("    decision                                     factor    in this document?")
dim("    bake mechanism: optimization -> emission     ~10^7x    NO")
dim("    transport: full-state -> delta+uniform         ~95x    LAW VII (yes)")
dim("    representation: dense voxels -> gaussians    ~17.6x    NO")
dim("    compression: zstd-3 on splats                 ~3.85x   §XI (zstd named, not sized)")
print()
dim("  LAW VII is the only one of the four that appears, and it appears as a law")
dim("  rather than a number. The other three decide whether the Cathedral runtime's")
dim("  2-3 GB envelope is enough, whether the 1.5 Hz pulse writes 4 KB or 1 MB, and")
dim("  whether Mode C is ever reachable. They are upstream of every figure above.")
print()
dim("  Concrete consequences of leaving them unspecified:")
dim("    - §II's '2.0-3.0 GB Cathedral runtime' cannot be validated without a cell")
dim("      count and a gaussian count. At 262,144 cells x 6 channels x 4 B the")
dim("      symbolic state alone is 6.3 MB; the chunk cache beside it is what actually")
dim("      consumes gigabytes, and its size is the representation decision.")
dim("    - §XII's SSD doctrine cannot be budgeted without a delta size (section B).")
dim("    - §XXI's thermal states cannot be triggered without knowing whether the")
dim("      sustained load is a 6 ms procedural bake or a 28 minute optimization fit.")
print()
dim("  On a fanless Air the sustained power envelope is roughly 8-12 W for the whole")
dim("  SoC before throttling. A 60 Hz sim plus Metal rendering plus resident LLM")
dim("  inference is plausibly inside that. A 28-minute optimization fit is not — it")
dim("  will hit ΩT2/ΩT3 within minutes and stay there. So the bake mechanism decision")
dim("  is also a thermal decision, and §XXI governs a load it never names.")

# =========================================================================
hdr("F. WHAT TO REPLACE WITH REAL APIs")
dim("The document invents two state machines that macOS already provides, with")
dim("better information than a self-estimated proxy:")
print()
dim("  §III  Memory pressure Ω0-Ω3   ->  os_proc_available_memory()")
dim("                                    + task_info(MACH_TASK_BASIC_INFO) resident size")
dim("                                    + mach task_info pressure level")
dim("                                    + DISPATCH_SOURCE_TYPE_MEMORYPRESSURE")
dim("       Four discrete states map 1:1 onto Ω0-Ω3. Use the kernel's opinion, not")
dim("       a heuristic; it sees compressed-page and swap activity you cannot.")
print()
dim("  §XXI  Thermal ΩT0-ΩT3         ->  ProcessInfo.thermalState")
dim("                                    .nominal / .fair / .serious / .critical")
dim("       Exactly four states, exactly the semantics described, delivered by the OS")
dim("       from real sensor data. Observe it with a KVO/notification rather than")
dim("       polling. This also fixes §XXII: you cannot pin to E-cores, but you CAN")
dim("       set QoS classes (.userInteractive / .utility / .background) and the")
dim("       scheduler does honour those as hints — which is precisely the 'request")
dim("       lower priority, do not assume confinement' doctrine, with a real API.")
print()
dim("  §XXIV S = w_m·M + w_t·T + w_c·C + w_r·R")
dim("       Four weights, no values, no normalisation, and a linear form for what is")
dim("       really a lexicographic policy: §XXXI already says State > Historical >")
dim("       Responsiveness > Generation > Background. A weighted sum can violate a")
dim("       strict hierarchy (enough generation urgency outvotes state integrity).")
dim("       Encode the hierarchy as ordered comparisons and use the weighted sum only")
dim("       to break ties WITHIN a tier. Otherwise LAW II is advisory, not enforced.")

out = {"frame_budget": results_A, "ssd": results_B,
       "rpo_ms": rpo_ms, "rpo_ticks": rpo_ticks,
       "memory_low_gb": lo + headroom[0], "memory_high_gb": hi + headroom[1],
       "assumed_m4_speedup": M4_SPEEDUP,
       "ns_per_cell_tick_measured_xeon": NS_PER_CELL_TICK_XEON}
with open("budget_m4.json", "w") as f:
    json.dump(out, f, indent=2)
print()
dim("written to budget_m4.json")
print("=" * 78)
