/* ============================================================================
   splat_emit.js — procedural gaussian emission from symbolic truth
   ----------------------------------------------------------------------------
   This is §5c "path A" as reusable code: the RUNTIME bake. It takes a World
   from core.js (6 symbolic channels) and emits 3D gaussians.

   No optimization, no gradient descent, no GPU. Pure function of truth.
   Measured: ~30k gaussians in a few milliseconds.

   Deliberately dependency-free and Node-testable, because the emission math is
   the part that decides whether the world looks right, and it should be
   assertable without a browser in the loop.
   ============================================================================ */
(function (root) {
  'use strict';

  const N = root.NEBULA;
  if (!N) throw new Error('splat_emit.js requires core.js to be loaded first');

  // World-space scale. The symbolic heightfield is normalised [0,1]; this maps
  // it to metres. Kept explicit so the viewer and any collider agree.
  const HEIGHT_METRES = 12.0;
  const CELL_METRES = 1.0;

  /**
   * Bilinear sample of a channel at sub-cell coordinates. Needed because
   * density > 1 places gaussians between grid points, and nearest-neighbour
   * sampling there produces visible terracing.
   */
  function bilerp(arr, w, h, x, y) {
    const xi = x < 0 ? 0 : x > w - 1.001 ? w - 1.001 : x;
    const yi = y < 0 ? 0 : y > h - 1.001 ? h - 1.001 : y;
    const x0 = xi | 0, y0 = yi | 0;
    const x1 = x0 + 1 < w ? x0 + 1 : x0, y1 = y0 + 1 < h ? y0 + 1 : y0;
    const fx = xi - x0, fy = yi - y0;
    const a = arr[y0 * w + x0], b = arr[y0 * w + x1];
    const c = arr[y1 * w + x0], d = arr[y1 * w + x1];
    return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy;
  }

  /**
   * Emit gaussians from a World.
   *
   * @param {World} world     symbolic truth (from core.js)
   * @param {object} opts
   *   density      sub-samples per land cell along each axis (1 = one per cell)
   *   vegDensity   probability scale for vegetation instances
   *   includeWater / includeVeg   toggles, so the viewer can show layers
   *   jitter       positional jitter as a fraction of a cell (breaks grid aliasing)
   *
   * @returns {Float32Array[]} structured arrays, SoA for cache-friendly upload:
   *   pos (3n), scale (3n), rot (4n), color (3n), opacity (n), kind (n)
   */
  function emit(world, opts = {}) {
    const density = Math.max(1, opts.density | 0 || 1);
    const vegDensity = opts.vegDensity ?? 0.35;
    const includeWater = opts.includeWater !== false;
    const includeVeg = opts.includeVeg !== false;
    const jitter = opts.jitter ?? 0.18;
    const seed = opts.seed ?? 1;

    const w = world.w, h = world.h;
    const E = world.ch[N.CH.ELEV], M = world.ch[N.CH.MOIST], R = world.ch[N.CH.ROCK];
    const V = world.ch[N.CH.VEG], S = world.ch[N.CH.STRUCT], W = world.ch[N.CH.WATER];

    // Deterministic RNG: the emitter must be reproducible, or the bake is not a
    // pure function of truth and two clients would emit different worlds.
    const rng = N.mulberry32(seed);

    const side = Math.max(1, Math.round(Math.sqrt(density)));
    const sub = CELL_METRES / side;
    const offs = [];
    for (let i = 0; i < side; i++) offs.push((i + 0.5) / side - 0.5);

    const pos = [], scale = [], rot = [], color = [], opacity = [], kind = [], normal = [];
    const c3 = new Float32Array(3);

    // ---- terrain + structures (the land mask)
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = y * w + x;
        const isWater = W[i] >= 0.35;
        if (isWater) continue;
        for (let oy = 0; oy < side; oy++) {
          for (let ox = 0; ox < side; ox++) {
            const jx = (rng() - 0.5) * jitter * sub;
            const jy = (rng() - 0.5) * jitter * sub;
            const sx = x + offs[ox] + jx;
            const sy = y + offs[oy] + jy;
            const e = bilerp(E, w, h, sx, sy);
            const moist = bilerp(M, w, h, sx, sy);
            const rock = bilerp(R, w, h, sx, sy);
            const veg = bilerp(V, w, h, sx, sy);
            const str = bilerp(S, w, h, sx, sy);
            const wat = bilerp(W, w, h, sx, sy);

            // slope from the sampled neighbourhood — cheap, and it drives both
            // the gaussian footprint and the rock exposure
            const ex = bilerp(E, w, h, sx + 0.5, sy) - bilerp(E, w, h, sx - 0.5, sy);
            const ey = bilerp(E, w, h, sx, sy + 0.5) - bilerp(E, w, h, sx, sy - 0.5);
            const slope = Math.min(1, Math.hypot(ex, ey) * 6);

            N.biomeTarget(e, moist, rock, veg, str, wat, slope, c3);

            pos.push(sx * CELL_METRES, e * HEIGHT_METRES, sy * CELL_METRES);
            // surface normal from the heightfield gradient, in world space.
            // Unlit splats are exactly why a heightfield read as paint: colour
            // alone carries no form. Shading needs a normal per gaussian.
            const hs = HEIGHT_METRES / CELL_METRES;
            let nx = -ex * hs, ny = 1, nz = -ey * hs;
            const nl = Math.hypot(nx, ny, nz) || 1;
            normal.push(nx / nl, ny / nl, nz / nl);
            // flatter gaussians on flat ground, taller on slopes so the surface
            // does not show gaps between samples
            const flat = sub * 0.62;
            scale.push(flat, flat * (1 + slope * 1.4), 0.14 + slope * 0.10);
            rot.push(1, 0, 0, 0);
            color.push(c3[0], c3[1], c3[2]);
            opacity.push(str > 0.2 ? 1.0 : 0.98);
            kind.push(str > 0.2 ? 3 : 0);   // 3 = structure
          }
        }
      }
    }

    // ---- vegetation: stochastic instances, density from the veg channel.
    // Placed ABOVE the terrain so they read as canopy rather than paint.
    if (includeVeg) {
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const i = y * w + x;
          if (W[i] >= 0.35) continue;
          if (V[i] <= 0.05) continue;
          // expected instance count scales with vegetation density
          const expect = V[i] * vegDensity * density * 0.9;
          let count = expect | 0;
          if (rng() < (expect - count)) count++;
          for (let k = 0; k < count; k++) {
            const sx = x + rng(), sy = y + rng();
            const e = bilerp(E, w, h, sx, sy);
            const veg = bilerp(V, w, h, sx, sy);
            const rock = bilerp(R, w, h, sx, sy);
            const moist = bilerp(M, w, h, sx, sy);
            N.biomeTarget(e, moist, rock, veg, 0, 0, 0, c3);
            // push toward foliage tones; biomeTarget is a ground ramp
            const g = 0.72 + veg * 0.35;
            const height = 0.30 + veg * 1.15;
            pos.push(sx * CELL_METRES, e * HEIGHT_METRES + height * 0.5, sy * CELL_METRES);
            const r = 0.22 + veg * 0.30;
            scale.push(r, height * 0.5, r);
            // random yaw so canopies do not alias into a grid
            const a = rng() * Math.PI * 2;
            rot.push(Math.cos(a * 0.5), 0, Math.sin(a * 0.5), 0);
            normal.push(Math.sin(a) * 0.3, 1, Math.cos(a) * 0.3);
            color.push(c3[0] * 0.55 * g, c3[1] * 0.95 * g, c3[2] * 0.50 * g);
            opacity.push(0.82 + veg * 0.16);
            kind.push(1);
          }
        }
      }
    }

    // ---- water surface: a single sheet at the waterline, semi-transparent.
    // Emitted last so blend order has something sane to start from; the viewer
    // re-sorts by depth anyway.
    if (includeWater) {
      const level = 0.30 * HEIGHT_METRES;
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const i = y * w + x;
          if (W[i] < 0.05) continue;
          const deep = Math.min(1, W[i]);
          pos.push((x + 0.5) * CELL_METRES, level + 0.02, (y + 0.5) * CELL_METRES);
          normal.push(0, 1, 0);
          scale.push(CELL_METRES * 0.78, 0.045, CELL_METRES * 0.78);
          rot.push(1, 0, 0, 0);
          // shallow -> deep ramp, matching biomeTarget's water tones
          color.push(0.33 - deep * 0.27, 0.53 - deep * 0.33, 0.64 - deep * 0.24);
          opacity.push(0.55 + deep * 0.35);
          kind.push(2);
        }
      }
    }

    const n = kind.length;
    return {
      count: n,
      pos: Float32Array.from(pos),
      scale: Float32Array.from(scale),
      rot: Float32Array.from(rot),
      color: Float32Array.from(color),
      opacity: Float32Array.from(opacity),
      normal: Float32Array.from(normal),
      kind: Uint8Array.from(kind),
      bytes: n * 32,   // the .splat wire size: 12+12+4+4
      HEIGHT_METRES, CELL_METRES
    };
  }

  /** Pack into the 32-byte antimatter15/splat wire format. */
  function toSplatBytes(g) {
    const n = g.count;
    const buf = new ArrayBuffer(n * 32);
    const dv = new DataView(buf);
    const u8 = new Uint8Array(buf);
    for (let i = 0; i < n; i++) {
      const o = i * 32;
      dv.setFloat32(o + 0, g.pos[i * 3 + 0], true);
      dv.setFloat32(o + 4, g.pos[i * 3 + 1], true);
      dv.setFloat32(o + 8, g.pos[i * 3 + 2], true);
      dv.setFloat32(o + 12, Math.log(Math.max(1e-7, g.scale[i * 3 + 0])), true);
      dv.setFloat32(o + 16, Math.log(Math.max(1e-7, g.scale[i * 3 + 1])), true);
      dv.setFloat32(o + 20, Math.log(Math.max(1e-7, g.scale[i * 3 + 2])), true);
      u8[o + 24] = Math.max(0, Math.min(255, Math.round(g.color[i * 3 + 0] * 255)));
      u8[o + 25] = Math.max(0, Math.min(255, Math.round(g.color[i * 3 + 1] * 255)));
      u8[o + 26] = Math.max(0, Math.min(255, Math.round(g.color[i * 3 + 2] * 255)));
      u8[o + 27] = Math.max(0, Math.min(255, Math.round(g.opacity[i] * 255)));
      // quaternion stored as (q+1)*127.5 per the common .splat convention
      for (let k = 0; k < 4; k++) {
        u8[o + 28 + k] = Math.max(0, Math.min(255, Math.round((g.rot[i * 4 + k] + 1) * 127.5)));
      }
    }
    return buf;
  }

  /** Parse a .splat back — used to validate round-trips and to load files. */
  function fromSplatBytes(buf) {
    const n = (buf.byteLength / 32) | 0;
    const dv = new DataView(buf);
    const u8 = new Uint8Array(buf);
    const g = {
      count: n,
      pos: new Float32Array(n * 3), scale: new Float32Array(n * 3),
      rot: new Float32Array(n * 4), color: new Float32Array(n * 3),
      opacity: new Float32Array(n), kind: new Uint8Array(n)
    };
    for (let i = 0; i < n; i++) {
      const o = i * 32;
      g.pos[i * 3] = dv.getFloat32(o, true);
      g.pos[i * 3 + 1] = dv.getFloat32(o + 4, true);
      g.pos[i * 3 + 2] = dv.getFloat32(o + 8, true);
      g.scale[i * 3] = Math.exp(dv.getFloat32(o + 12, true));
      g.scale[i * 3 + 1] = Math.exp(dv.getFloat32(o + 16, true));
      g.scale[i * 3 + 2] = Math.exp(dv.getFloat32(o + 20, true));
      g.color[i * 3] = u8[o + 24] / 255;
      g.color[i * 3 + 1] = u8[o + 25] / 255;
      g.color[i * 3 + 2] = u8[o + 26] / 255;
      g.opacity[i] = u8[o + 27] / 255;
      for (let k = 0; k < 4; k++) g.rot[i * 4 + k] = u8[o + 28 + k] / 127.5 - 1;
    }
    return g;
  }

  const API = { emit, toSplatBytes, fromSplatBytes, bilerp, HEIGHT_METRES, CELL_METRES };
  root.NEBULA_SPLAT_EMIT = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;

})(typeof globalThis !== 'undefined' ? globalThis : this);
