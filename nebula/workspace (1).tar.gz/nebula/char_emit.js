/* ============================================================================
   char_emit.js — procedural humanoid characters as gaussian splats
   ----------------------------------------------------------------------------
   Characters are emitted through the SAME pipeline as terrain: a pure function
   of (skeleton, pose, seed) -> gaussians. No meshes, no rigged assets, no
   skinning matrix — a mini forward-kinematics chain sampled into capsules.

   Why this shape:
     - deterministic: same seed + phase == identical character, so a character
       is reproducible from the event log like everything else in this codebase
     - consistent: renders through the same splat path as the world, so there is
       exactly one renderer
     - cheap: ~200 gaussians per figure; 50 figures is 10k gaussians

   The skeleton is a chain of segments in the sagittal plane (pitch about X),
   rotated by a root yaw and translated to a world position. That is enough for
   a readable walk cycle and keeps the FK small enough to assert against.
   ============================================================================ */
(function (root) {
  'use strict';
  const N = root.NEBULA;
  if (!N) throw new Error('char_emit.js requires core.js');

  // Proportions in metres, roughly adult human.
  const PROP = {
    hipH: 0.95, torsoLen: 0.50, torsoR: 0.155,
    neckLen: 0.08, headR: 0.115, headC: 0.115,
    thighLen: 0.44, shinLen: 0.43, legR: 0.075, footLen: 0.22,
    upperArmLen: 0.30, foreArmLen: 0.27, armR: 0.052,
    shoulderW: 0.19, hipW: 0.10
  };

  /** Walk-cycle joint angles (radians) for a phase in [0, 2pi). */
  function poseWalk(phase, speed = 1) {
    const s = Math.sin(phase), c = Math.sin(phase + Math.PI);
    return {
      hipL: 0.55 * s * speed, kneeL: -0.85 * Math.max(0, -s) * speed - 0.12,
      hipR: 0.55 * c * speed, kneeR: -0.85 * Math.max(0, -c) * speed - 0.12,
      shoL: -0.45 * s * speed, elbL: -0.55 - 0.25 * Math.max(0, s),
      shoR: -0.45 * c * speed, elbR: -0.55 - 0.25 * Math.max(0, c),
      bob: 0.035 * Math.abs(Math.cos(phase)),
      lean: 0.06 * speed
    };
  }

  const IDLE = { hipL: 0, kneeL: -0.05, hipR: 0, kneeR: -0.05, shoL: -0.08, elbL: -0.35, shoR: -0.08, elbR: -0.35, bob: 0, lean: 0 };

  // rotate about X (pitch) then place; sagittal-plane FK
  function seg(px, py, pz, dirx, diry, dirz, len, pitch) {
    // rotate direction (in the Y-Z... we swing in Z-Y plane about X)
    const cp = Math.cos(pitch), sp = Math.sin(pitch);
    const dy = diry * cp - dirz * sp;
    const dz = diry * sp + dirz * cp;
    return [px, py + dy * len, pz + dz * len, dy, dz];
  }

  /**
   * Build one character in LOCAL space (root at origin, facing +Z).
   * @returns arrays like splat_emit: pos, scale, color, opacity, normal, part
   */
  function buildCharacter(opts = {}) {
    const seed = opts.seed ?? 1;
    const pose = opts.pose || IDLE;
    const density = opts.density ?? 1;      // gaussians-per-unit-length multiplier
    const rng = N.mulberry32(seed);

    const pos = [], scale = [], color = [], opacity = [], normal = [], part = [];

    // palette per character: clothing + skin, varied by seed
    const hue = rng();
    const cloth = palette(hue);
    const cloth2 = palette((hue + 0.45) % 1);
    const skin = [0.72 + rng() * 0.15, 0.55 + rng() * 0.15, 0.42 + rng() * 0.12];

    const hipY = PROP.hipH + pose.bob;

    function capsule(x0, y0, z0, x1, y1, z1, rad, col, partId, taper = 1) {
      const len = Math.hypot(x1 - x0, y1 - y0, z1 - z0);
      const n = Math.max(3, Math.round(len * 46 * density));
      const nx = (x1 - x0) / (len || 1), ny = (y1 - y0) / (len || 1), nz = (z1 - z0) / (len || 1);
      for (let i = 0; i < n; i++) {
        const t = (i + 0.5) / n;
        const rr = rad * (1 - 0.25 * t * (1 - taper));
        const cx = x0 + (x1 - x0) * t, cy = y0 + (y1 - y0) * t, cz = z0 + (z1 - z0) * t;
        // a few samples across the cross-section so limbs read as volumes
        const rings = 3;
        for (let k = 0; k < rings; k++) {
          const a = rng() * Math.PI * 2;
          const off = rr * 0.62 * Math.sqrt(rng());
          // perpendicular basis to the segment
          let ux = 1, uy = 0, uz = 0;
          if (Math.abs(nx) > 0.9) { ux = 0; uy = 1; }
          const vx = ny * uz - nz * uy, vy = nz * ux - nx * uz, vz = nx * uy - ny * ux;
          const px = cx + (ux * Math.cos(a) + vx * Math.sin(a)) * off;
          const py = cy + (uy * Math.cos(a) + vy * Math.sin(a)) * off;
          const pz = cz + (uz * Math.cos(a) + vz * Math.sin(a)) * off;
          pos.push(px, py, pz);
          scale.push(rr * 0.9, rr * 0.9, rr * 0.9);
          const nl = Math.hypot(px - cx, py - cy, pz - cz) || 1;
          normal.push((px - cx) / nl, (py - cy) / nl, (pz - cz) / nl);
          color.push(col[0], col[1], col[2]);
          opacity.push(0.95);
          part.push(partId);
        }
      }
    }

    function sphere(cx, cy, cz, rad, col, partId) {
      const n = Math.max(8, Math.round(rad * 260 * density));
      for (let i = 0; i < n; i++) {
        const u = rng() * 2 - 1, th = rng() * Math.PI * 2;
        const r = rad * Math.cbrt(rng());
        const s = Math.sqrt(1 - u * u);
        const px = cx + r * s * Math.cos(th), py = cy + r * u, pz = cz + r * s * Math.sin(th);
        pos.push(px, py, pz);
        scale.push(rad * 0.55, rad * 0.55, rad * 0.55);
        const nl = r || 1;
        normal.push((px - cx) / nl, (py - cy) / nl, (pz - cz) / nl);
        color.push(col[0], col[1], col[2]);
        opacity.push(0.96);
        part.push(partId);
      }
    }

    // ---- legs (root at pelvis, swing about X)
    for (const side of [-1, 1]) {
      const hipA = side < 0 ? pose.hipL : pose.hipR;
      const kneeA = side < 0 ? pose.kneeL : pose.kneeR;
      const hx = side * PROP.hipW, hy = hipY, hz = 0;
      const [kx, ky, kz] = seg(hx, hy, hz, 0, -1, 0, PROP.thighLen, hipA);
      const [fx, fy, fz] = seg(kx, ky, kz, 0, -1, 0, PROP.shinLen, hipA + kneeA);
      capsule(hx, hy, hz, kx, ky, kz, PROP.legR, cloth2, 4);          // thigh
      capsule(kx, ky, kz, fx, fy, fz, PROP.legR * 0.85, cloth2, 5);    // shin
      capsule(fx, fy, fz, fx, fy + 0.02, fz + PROP.footLen, PROP.legR * 0.7, [0.15, 0.13, 0.12], 6); // foot
    }

    // ---- torso + head
    const chestY = hipY + PROP.torsoLen;
    capsule(0, hipY, 0, 0, chestY, -pose.lean * 0.3, PROP.torsoR, cloth, 1, 0.8);
    capsule(0, chestY, -pose.lean * 0.3, 0, chestY + PROP.neckLen, -pose.lean * 0.4, PROP.torsoR * 0.42, skin, 2);
    sphere(0, chestY + PROP.neckLen + PROP.headC, -pose.lean * 0.4, PROP.headR, skin, 3);

    // ---- arms
    for (const side of [-1, 1]) {
      const shoA = side < 0 ? pose.shoL : pose.shoR;
      const elbA = side < 0 ? pose.elbL : pose.elbR;
      const sx = side * PROP.shoulderW, sy = chestY - 0.03, sz = -pose.lean * 0.3;
      const [ex, ey, ez] = seg(sx, sy, sz, 0, -1, 0, PROP.upperArmLen, shoA);
      const [wx, wy, wz] = seg(ex, ey, ez, 0, -1, 0, PROP.foreArmLen, shoA + elbA);
      capsule(sx, sy, sz, ex, ey, ez, PROP.armR, cloth, 7);
      capsule(ex, ey, ez, wx, wy, wz, PROP.armR * 0.85, skin, 8);
    }

    return {
      count: part.length,
      pos: Float32Array.from(pos), scale: Float32Array.from(scale),
      color: Float32Array.from(color), opacity: Float32Array.from(opacity),
      normal: Float32Array.from(normal), part: Uint8Array.from(part),
      height: chestY + PROP.neckLen + PROP.headC * 2
    };
  }

  function palette(h) {
    // simple hue -> rgb, muted so figures sit inside the world's palette
    const i = Math.floor(h * 6), f = h * 6 - i;
    const p = 0.25, q = 0.55 + 0.25 * f, t = 0.45 + 0.2 * (1 - f);
    const base = [[0.55, 0.28, 0.25], [0.55, 0.42, 0.22], [0.35, 0.5, 0.28],
                  [0.25, 0.45, 0.45], [0.28, 0.32, 0.52], [0.45, 0.28, 0.45]][i % 6];
    return [base[0] * (0.8 + 0.3 * f), base[1] * (0.8 + 0.3 * (1 - f)), base[2] * (0.85 + 0.2 * t)];
  }

  /**
   * Transform a local-space character into world space: uniform scale, yaw
   * about Y, then translate. `scale` defaults to 1 (true 1.7 m human); the
   * viewer uses a stylized ~1.6 because a true-scale human in a 128 m world is
   * ~19 px of muted colour at default zoom and simply cannot be seen. That is a
   * readability decision, not a physical one, and it is called out in the UI.
   */
  function place(local, wx, wy, wz, yaw, out, scale = 1) {
    const cy = Math.cos(yaw), sy = Math.sin(yaw);
    const n = local.count;
    for (let i = 0; i < n; i++) {
      const x = local.pos[i * 3] * scale, y = local.pos[i * 3 + 1] * scale, z = local.pos[i * 3 + 2] * scale;
      out.pos[i * 3] = wx + x * cy + z * sy;
      out.pos[i * 3 + 1] = wy + y;
      out.pos[i * 3 + 2] = wz - x * sy + z * cy;
      const nx = local.normal[i * 3], ny = local.normal[i * 3 + 1], nz = local.normal[i * 3 + 2];
      out.normal[i * 3] = nx * cy + nz * sy;
      out.normal[i * 3 + 1] = ny;
      out.normal[i * 3 + 2] = -nx * sy + nz * cy;
      out.scale[i * 3] = local.scale[i * 3] * scale;
      out.scale[i * 3 + 1] = local.scale[i * 3 + 1] * scale;
      out.scale[i * 3 + 2] = local.scale[i * 3 + 2] * scale;
      out.color[i * 3] = local.color[i * 3];
      out.color[i * 3 + 1] = local.color[i * 3 + 1];
      out.color[i * 3 + 2] = local.color[i * 3 + 2];
      out.opacity[i] = local.opacity[i];
    }
    return out;
  }

  function allocLike(local) {
    const n = local.count;
    return { count: n, pos: new Float32Array(n * 3), scale: new Float32Array(n * 3),
             color: new Float32Array(n * 3), opacity: new Float32Array(n),
             normal: new Float32Array(n * 3), part: local.part };
  }

  const API = { PROP, poseWalk, IDLE, buildCharacter, place, allocLike, palette };
  root.NEBULA_CHAR = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
