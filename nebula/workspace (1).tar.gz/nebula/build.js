/* Build a single self-contained HTML file from demo.html + core.js.
 *
 * demo.html references core.js via <script src> so that core.js stays the single
 * source of truth shared with the tests and the benchmark. This bundler exists
 * because some viewers (sandboxed iframes, email, a USB stick at a meetup) will
 * not resolve a relative script tag. Run it after editing either file:
 *
 *     node build.js
 */
const fs = require('fs');
const path = require('path');

const dir = __dirname;
const demo = fs.readFileSync(path.join(dir, 'demo.html'), 'utf8');
const core = fs.readFileSync(path.join(dir, 'core.js'), 'utf8');

const TAG = '<script src="core.js"></script>';
if (!demo.includes(TAG)) {
  console.error('build.js: could not find the core.js script tag in demo.html');
  process.exit(1);
}
// Guard against a premature </script> inside core.js breaking the inline block.
if (/<\/script/i.test(core)) {
  console.error('build.js: core.js contains </script>, which would break inlining');
  process.exit(1);
}

const stamp = new Date().toISOString().slice(0, 16).replace('T', ' ');
const inline = `<script>\n/* core.js inlined by build.js — do not edit here; edit core.js and rebuild.\n` +
  `   bundled ${stamp} · ${(core.length / 1024).toFixed(0)} KB */\n` + core + `\n</script>`;

const out = demo.replace(TAG, inline)
  .replace('<title>Project NEBULA — MLAOS Architecture Prototype</title>',
    '<title>Project NEBULA — MLAOS Architecture Prototype (standalone)</title>');

const dest = path.join(dir, 'nebula-standalone.html');
fs.writeFileSync(dest, out);
console.log(`built ${path.basename(dest)}  ${(out.length / 1024).toFixed(0)} KB  (core.js ${(core.length / 1024).toFixed(0)} KB inlined)`);

// ---- the splat viewer: core.js + splat_emit.js + viewer.html in one file.
// This is the artifact that answers "does procedural emission look like a bake",
// so it must open with zero setup, from file://, on a machine with no server.
const emit = fs.readFileSync(path.join(dir, 'splat_emit.js'), 'utf8');
const charSrc = fs.readFileSync(path.join(dir, 'char_emit.js'), 'utf8');
const viewer = fs.readFileSync(path.join(dir, 'viewer.html'), 'utf8');
for (const [name, src] of [['core.js', core], ['splat_emit.js', emit], ['char_emit.js', charSrc]]) {
  if (/<\/script/i.test(src)) {
    console.error(`build.js: ${name} contains </script>, which would break inlining`);
    process.exit(1);
  }
}
const VTAGS = '<script src="core.js"></script>\n<script src="splat_emit.js"></script>\n<script src="char_emit.js"></script>';
if (!viewer.includes(VTAGS)) {
  console.error('build.js: could not find the viewer script tags');
  process.exit(1);
}
const inlineAll =
  `<script>\n/* core.js inlined by build.js — edit core.js and rebuild.\n   bundled ${stamp} */\n` + core + `\n</script>\n` +
  `<script>\n/* splat_emit.js inlined by build.js */\n` + emit + `\n</script>\n` +
  `<script>\n/* char_emit.js inlined by build.js */\n` + charSrc + `\n</script>`;
const vout = viewer.replace(VTAGS, inlineAll)
  .replace('<title>NEBULA — Procedural Splat Viewer</title>',
           '<title>NEBULA — Procedural Splat Viewer (standalone)</title>');
const vdest = path.join(dir, 'nebula-viewer.html');
fs.writeFileSync(vdest, vout);
console.log(`built ${path.basename(vdest)}  ${(vout.length / 1024).toFixed(0)} KB  (core.js + splat_emit.js inlined)`);
