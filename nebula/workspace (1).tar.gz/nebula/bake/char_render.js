/* char_render.js — render procedural characters in software to inspect them.
   Usage: node bake/char_render.js [out.png] [phase] [yawDeg] [zoom]        */
const fs = require('fs');
const writePNG = require('./png.js');
require('../core.js');
const C = require('../char_emit.js');

const OUTP = process.argv[2] || 'char.png';
const PHASE = +(process.argv[3] || 0);
const YAW = +(process.argv[4] || 25) * Math.PI / 180;
const ZOOM = +(process.argv[5] || 1);

const VW = 420, VH = 520;

// build one walking character
const pose = C.poseWalk(PHASE, 1);
const local = C.buildCharacter({ seed: 7, pose, density: 1.4 });
const placed = C.allocLike(local);
C.place(local, 0, 0, 0, YAW, placed);
console.log(`character: ${placed.count} gaussians, height ${local.height.toFixed(2)} m, phase ${PHASE.toFixed(2)}`);

// orthographic-ish camera: place eye in front, look at chest
const eyeH = 1.1;
const dist = 4.2 / ZOOM;
const yawC = 0.0;
const eye = [Math.sin(yawC) * dist, eyeH, Math.cos(yawC) * dist];
const target = [0, 0.95, 0];

const CAM = require('../cam_test.js');
const FOV = 40 * Math.PI / 180;
const view = CAM.lookAt(new Float64Array(16), eye, target, [0, 1, 0]);
const proj = CAM.perspective(new Float64Array(16), FOV, VW / VH, 0.05, 100);
const vp = CAM.multiply(new Float64Array(16), proj, view);
const TAN = Math.tan(FOV / 2);

// ground shadow disc for grounding
const items = [];
for (let i = 0; i < placed.count; i++) {
  const p = [placed.pos[i*3], placed.pos[i*3+1], placed.pos[i*3+2]];
  const c = CAM.transformPoint(vp, p);
  if (c[3] <= 0) continue;
  const nx = c[0]/c[3], ny = c[1]/c[3], nz = c[2]/c[3];
  if (nz < -1 || nz > 1 || Math.abs(nx) > 1.05 || Math.abs(ny) > 1.05) continue;
  const d = Math.hypot(eye[0]-p[0], eye[1]-p[1], eye[2]-p[2]);
  const r = placed.scale[i*3];
  let px = (r * 1.0) / d * (VH*0.5) / TAN;
  px = Math.max(1.0, Math.min(400, px));
  items.push({ sx:(nx*0.5+0.5)*VW, sy:(1-(ny*0.5+0.5))*VH, r:px, depth:d, i });
}

// simple ground plane: dark disc
const fb = new Float32Array(VW*VH*3);
for (let i=0;i<VW*VH;i++){ fb[i*3]=0.10; fb[i*3+1]=0.11; fb[i*3+2]=0.13; }
// ground: project a grid
for (let gz=-1.2; gz<=1.2; gz+=0.02) for (let gx=-1.2; gx<=1.2; gx+=0.02) {
  const c = CAM.transformPoint(vp, [gx,0,gz]);
  if (c[3]<=0) continue;
  const sx=(c[0]/c[3]*0.5+0.5)*VW, sy=(1-(c[1]/c[3]*0.5+0.5))*VH;
  const xi=sx|0, yi=sy|0;
  if(xi<0||yi<0||xi>=VW||yi>=VH) continue;
  const o=(yi*VW+xi)*3;
  const shade = 0.16 + 0.10*Math.max(0,1-Math.hypot(gx,gz));
  fb[o]=shade*0.9; fb[o+1]=shade; fb[o+2]=shade*1.05;
}

items.sort((a,b)=>b.depth-a.depth);
const SUN=[0.4,0.7,0.4]; const sl=Math.hypot(...SUN); SUN.forEach((v,i)=>SUN[i]=v/sl);
for (const it of items) {
  const R=Math.ceil(it.r);
  const x0=Math.max(0,Math.floor(it.sx-R)), x1=Math.min(VW-1,Math.ceil(it.sx+R));
  const y0=Math.max(0,Math.floor(it.sy-R)), y1=Math.min(VH-1,Math.ceil(it.sy+R));
  const n=[placed.normal[it.i*3],placed.normal[it.i*3+1],placed.normal[it.i*3+2]];
  const ndl=Math.max(0,n[0]*SUN[0]+n[1]*SUN[1]+n[2]*SUN[2]);
  const lum=0.38+0.85*ndl;
  const cr=Math.min(1,placed.color[it.i*3]*lum), cg=Math.min(1,placed.color[it.i*3+1]*lum), cb=Math.min(1,placed.color[it.i*3+2]*lum);
  const op=placed.opacity[it.i];
  for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
    const ux=(x-it.sx)/it.r, uy=(y-it.sy)/it.r; const r2=ux*ux+uy*uy;
    if(r2>1)continue;
    const a=op*Math.exp(-0.5*r2*4.0);
    if(a<1/255)continue;
    const o=(y*VW+x)*3;
    fb[o]=cr*a+fb[o]*(1-a); fb[o+1]=cg*a+fb[o+1]*(1-a); fb[o+2]=cb*a+fb[o+2]*(1-a);
  }
}
const rgb=Buffer.alloc(VW*VH*3);
for(let i=0;i<VW*VH*3;i++) rgb[i]=Math.max(0,Math.min(255,Math.round(fb[i]*255)));
writePNG(OUTP,VW,VH,rgb);
console.log(`wrote ${OUTP} (${VW}x${VH}), ${items.length} splats drawn`);
