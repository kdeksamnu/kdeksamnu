/* soft_render.js — a CPU reference implementation of viewer.html's shader math.
   Renders the same vertex/fragment equations to a PNG so the pipeline can be
   debugged without a GPU. This exists because the GLSL was the one component
   that could not be executed in the sandbox, and the first real screenshot
   showed gaussians rendering as 2px points instead of filled splats.

   Usage: node soft_render.js [density] [out.png] [pxwidth]
*/
const fs = require('fs');
const zlib = require('zlib');
require('../core.js');
const E = require('../splat_emit.js');
const CAM = require('../cam_test.js');   // the tested camera math
const N = globalThis.NEBULA;

const DENS = +(process.argv[2] || 9);
const OUTP = process.argv[3] || 'soft_render.png';
const VW = +(process.argv[4] || 800);
const VH = Math.round(VW * 0.48);
// visual-experiment knobs: vertical exaggeration, camera pitch (rad), distance mult
const HSCALE = +(process.argv[5] || 1);
const PITCH  = +(process.argv[6] || 0.62);
const DMULT  = +(process.argv[7] || 1.15);

const writePNG = require('./png.js');

/* ------------------------------------------------------------ scene build */
const W = 128, H = 80;
const world = new N.World(W, H, 1337);
for (let i = 0; i < 40; i++) world.microStep(1);
const g = E.emit(world, { density: DENS, vegDensity: 0.35, jitter: 0.18, seed: 1337 });
console.log(`emitted ${g.count.toLocaleString()} gaussians (density ${DENS})`);

/* camera exactly as viewer.html */
const FOV = 48 * Math.PI / 180, NEAR = 0.1, FAR = 5000;
for (let i = 0; i < g.count * 3; i += 3) g.pos[i + 1] *= HSCALE;   // vertical exaggeration
const cam = { yaw: 0.6, pitch: PITCH, dist: Math.max(W, H) * DMULT, tx: W / 2, ty: 5 * HSCALE, tz: H / 2 };
const eye = CAM.orbitEye([cam.tx, cam.ty, cam.tz], cam.yaw, cam.pitch, cam.dist);
const view = CAM.lookAt(new Float64Array(16), eye, [cam.tx, cam.ty, cam.tz], [0, 1, 0]);
const proj = CAM.perspective(new Float64Array(16), FOV, VW / VH, NEAR, FAR);
const vp = CAM.multiply(new Float64Array(16), proj, view);

/* ------------------------------------------------------- vertex stage */
const TAN = Math.tan(FOV / 2);
const items = [];
let clampedMin = 0, clampedMax = 0;
for (let i = 0; i < g.count; i++) {
  const p = [g.pos[i * 3], g.pos[i * 3 + 1], g.pos[i * 3 + 2]];
  const c = CAM.transformPoint(vp, p);
  if (c[3] <= 0) continue;
  const ndcX = c[0] / c[3], ndcY = c[1] / c[3], ndcZ = c[2] / c[3];
  if (ndcZ < -1 || ndcZ > 1) continue;
  const dist = Math.hypot(eye[0] - p[0], eye[1] - p[1], eye[2] - p[2]);
  const radius = Math.max(g.scale[i * 3], g.scale[i * 3 + 2]) * 1.6;

  // ---- the exact line from the vertex shader under test:
  let pxRadius = (radius * 1.0) / dist * (VH * 0.5) / TAN;
  pxRadius = Math.max(1.0, Math.min(512.0, pxRadius));
  if (pxRadius <= 1.0001) clampedMin++;
  if (pxRadius >= 511.99) clampedMax++;

  const sx = (ndcX * 0.5 + 0.5) * VW;
  const sy = (1 - (ndcY * 0.5 + 0.5)) * VH;
  items.push({ sx, sy, r: pxRadius, depth: dist, i });
}
console.log(`projected ${items.length.toLocaleString()} visible`);
console.log(`pxRadius clamped to MIN (1px): ${clampedMin.toLocaleString()}  to MAX: ${clampedMax}`);

// distribution of pxRadius — this is the diagnostic that finds a sizing bug
const radii = items.map(x => x.r).sort((a, b) => a - b);
const q = f => radii[Math.min(radii.length - 1, Math.floor(f * radii.length))];
console.log(`pxRadius percentiles  p1=${q(0.01).toFixed(2)}  p25=${q(0.25).toFixed(2)}  p50=${q(0.5).toFixed(2)}  p75=${q(0.75).toFixed(2)}  p99=${q(0.99).toFixed(2)}`);

// expected screen spacing between neighbouring terrain gaussians
const side = Math.max(1, Math.round(Math.sqrt(DENS)));
const worldSpacing = E.CELL_METRES / side;
const pxPerWorld = (VH * 0.5) / (cam.dist * TAN);
console.log(`terrain spacing: ${worldSpacing.toFixed(3)} world units = ${(worldSpacing * pxPerWorld).toFixed(2)} px between gaussians`);
console.log(`median quad diameter = ${(q(0.5) * 2).toFixed(2)} px`);
console.log(`=> coverage ratio (quad diameter / spacing) = ${(q(0.5) * 2 / (worldSpacing * pxPerWorld)).toFixed(2)}`);

/* ------------------------------------------------- optional characters */
// canopy gaussians carry ~1.5 m radii and spill past their cell, so a single-cell
// veg test parks characters under the forest where nothing can see them
function clearingAt(cx, cz, r){
  for(let dz=-r; dz<=r; dz++) for(let dx=-r; dx<=r; dx++){
    const x=cx+dx, z=cz+dz;
    if(x<0||z<0||x>=W||z>=H) continue;
    if(world.ch[N.CH.VEG][z*W+x] > 0.55) return false;
  }
  return true;
}
const NCHAR = +(process.argv[8] || 0);
if (NCHAR > 0) {
  let realAdded=0, skipWater=0, skipVeg=0;
  const CH = require('../char_emit.js');
  const HM = g.HEIGHT_METRES;
  for (let k = 0; k < NCHAR; k++) {
    // search outward for a clearing: the island is mostly forest, so a single
    // rejection test strands most characters in the canopy or the sea
    let x=-1, z=-1, xi=-1, zi=-1, y=0, yawA=0;
    for (let t=0; t<28; t++) {
      const a2 = k*2.39996 + t*0.83;
      const rr2 = 5 + (t % 7) * 4.5;
      const cx = W/2 + Math.cos(a2)*rr2, cz = H/2 + Math.sin(a2)*rr2;
      const cxi = Math.max(0,Math.min(W-1,Math.round(cx))), czi = Math.max(0,Math.min(H-1,Math.round(cz)));
      if (world.ch[N.CH.WATER][czi*W+cxi] > 0.30) { if(t===0) skipWater++; continue; }
      if (world.ch[N.CH.ELEV][czi*W+cxi] < 0.34) { if(t===0) skipWater++; continue; }  // above waterline
      if (!clearingAt(cxi, czi, 2)) { if(t===0) skipVeg++; continue; }   // a real clearing
      x=cx; z=cz; xi=cxi; zi=czi; y=world.ch[N.CH.ELEV][czi*W+cxi]*HM; yawA=a2; break;
    }
    if (xi < 0) continue;
    realAdded++;
    const local = CH.buildCharacter({seed:1000+k*7, pose:CH.poseWalk(k*1.3, 1), density:1.2});
    const placed = CH.allocLike(local);
    CH.place(local, x*E.CELL_METRES, y, z*E.CELL_METRES, -yawA+Math.PI/2, placed, +(process.argv[9]||1.6));
    if(process.env.DBG) console.log('   DBG char',k,'count',placed.count,'pos0',placed.pos[0].toFixed(1),placed.pos[1].toFixed(1),placed.pos[2].toFixed(1));
    let culledW=0,culledN=0,pushed=0;
    for (let i=0;i<placed.count;i++){
      const p=[placed.pos[i*3], placed.pos[i*3+1], placed.pos[i*3+2]];
      const c=CAM.transformPoint(vp,p);
      if(c[3]<=0){culledW++;continue;}
      const nx=c[0]/c[3], ny=c[1]/c[3], nz=c[2]/c[3];
      if(nz<-1||nz>1||Math.abs(nx)>1.05||Math.abs(ny)>1.05){culledN++;continue;}
      pushed++;
      const d=Math.hypot(eye[0]-p[0],eye[1]-p[1],eye[2]-p[2]);
      let px=(placed.scale[i*3]*1.0)/d*(VH*0.5)/TAN;
      px=Math.max(1.0,Math.min(512,px));
      if(process.env.DBG && i<3 && k<2) console.log('   DBG char',k,'splat',i,'ndc',nx.toFixed(2),ny.toFixed(2),nz.toFixed(2),'screen',((nx*0.5+0.5)*VW)|0,((1-(ny*0.5+0.5))*VH)|0,'px',px.toFixed(2),'depth',d.toFixed(1));
      items.push({sx:(nx*0.5+0.5)*VW, sy:(1-(ny*0.5+0.5))*VH, r:px, depth:d,
                  col:[placed.color[i*3],placed.color[i*3+1],placed.color[i*3+2]],
                  nrm:[placed.normal[i*3],placed.normal[i*3+1],placed.normal[i*3+2]],
                  op:placed.opacity[i], override:true});
    }
    if(process.env.DBG) console.log('   DBG char',k,'culledBehind',culledW,'culledNDC',culledN,'pushed',pushed);
  }
  console.log(`characters: requested ${NCHAR}, placed ${realAdded} (skipped water ${skipWater}, forest ${skipVeg})`);
}

/* ------------------------------------------------------- fragment stage */
// Characters are drawn AFTER all terrain, each list sorted far->near on its own.
// Depth-correct blending would let near canopy occlude figures standing behind
// it; for a worldbuilding viewport you want to see your inhabitants, so this is a
// deliberate readability pass, the same trick RTS/unit renderers use.
let terr = [], chs = [];
for (const it of items) (it.override ? chs : terr).push(it);
if (process.env.CHONLY) { terr = []; console.log('CHONLY: kept', chs.length, 'character splats'); }
terr.sort((a, b) => b.depth - a.depth);
chs.sort((a, b) => b.depth - a.depth);
const drawList = terr.concat(chs);
const fb = new Float32Array(VW * VH * 3);
fb.fill(0.02); fb.fill(0.027, 1); // background; fill per-channel below properly
for (let i = 0; i < VW * VH; i++) { fb[i * 3] = 0.02; fb[i * 3 + 1] = 0.027; fb[i * 3 + 2] = 0.043; }

const EXPOSURE = 1.0;
const SUN = (()=>{const s=[0.45,0.75,0.30];const l=Math.hypot(...s);return s.map(v=>v/l);})();
for (const it of drawList) {
  const R = Math.ceil(it.r);
  const x0 = Math.max(0, Math.floor(it.sx - R)), x1 = Math.min(VW - 1, Math.ceil(it.sx + R));
  const y0 = Math.max(0, Math.floor(it.sy - R)), y1 = Math.min(VH - 1, Math.ceil(it.sy + R));
  const nrm = it.override ? it.nrm : (g.normal ? [g.normal[it.i*3], g.normal[it.i*3+1], g.normal[it.i*3+2]] : [0,1,0]);
  const ndl = Math.max(0, nrm[0]*SUN[0] + nrm[1]*SUN[1] + nrm[2]*SUN[2]);
  const lum = 0.35 + 0.85 * ndl;
  const src = it.override ? it.col : [g.color[it.i*3], g.color[it.i*3+1], g.color[it.i*3+2]];
  const cr = Math.min(1, src[0] * lum) * EXPOSURE;
  const cg = Math.min(1, src[1] * lum) * EXPOSURE;
  const cb = Math.min(1, src[2] * lum) * EXPOSURE;
  const op = it.override ? it.op : g.opacity[it.i];
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const ux = (x - it.sx) / it.r, uy = (y - it.sy) / it.r;
      const r2 = ux * ux + uy * uy;
      if (r2 > 1) continue;
      const gf = Math.exp(-0.5 * r2 * 4.0);
      const a = op * gf;
      if (a < 1 / 255) continue;
      const o = (y * VW + x) * 3;
      fb[o] = cr * a + fb[o] * (1 - a);
      fb[o + 1] = cg * a + fb[o + 1] * (1 - a);
      fb[o + 2] = cb * a + fb[o + 2] * (1 - a);
    }
  }
}

const rgb = Buffer.alloc(VW * VH * 3);
for (let i = 0; i < VW * VH * 3; i++) rgb[i] = Math.max(0, Math.min(255, Math.round(fb[i] * 255)));
writePNG(OUTP, VW, VH, rgb);
console.log(`wrote ${OUTP} (${VW}x${VH})`);
