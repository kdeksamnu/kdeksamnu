/* Assertions on the procedural character model. Run: node char_test.js */
require('./core.js');
const C = require('./char_emit.js');
let P=0,F=0;
const ok=(n,c,d='')=>{if(c){P++;console.log(`  \x1b[32mPASS\x1b[0m  ${n}${d?'  \x1b[90m'+d+'\x1b[0m':''}`);}else{F++;console.log(`  \x1b[31mFAIL\x1b[0m  ${n}  ${d}`);}};
const hdr=s=>console.log(`\n\x1b[1m${s}\x1b[0m`);

hdr('Anatomy and proportions');
const idle = C.buildCharacter({seed:7, pose:C.IDLE, density:1});
let ymin=1e9,ymax=-1e9,xmin=1e9,xmax=-1e9,zmin=1e9,zmax=-1e9;
for(let i=0;i<idle.count;i++){
  ymin=Math.min(ymin,idle.pos[i*3+1]); ymax=Math.max(ymax,idle.pos[i*3+1]);
  xmin=Math.min(xmin,idle.pos[i*3]); xmax=Math.max(xmax,idle.pos[i*3]);
  zmin=Math.min(zmin,idle.pos[i*3+2]); zmax=Math.max(zmax,idle.pos[i*3+2]);
}
console.log(`  height ${ (ymax-ymin).toFixed(2) } m   footprint ${(xmax-xmin).toFixed(2)} x ${(zmax-zmin).toFixed(2)} m   ${idle.count} gaussians`);
ok('an adult human is 1.5-2.1 m tall', (ymax-ymin)>1.5 && (ymax-ymin)<2.1, `${(ymax-ymin).toFixed(2)} m`);
// gaussian CENTRES sit ~half a splat radius above the sole, so the visible foot
// touches y=0 while the lowest centre is ~0.06. Assert the sole, not the centre.
ok('the figure stands on the ground (sole at y=0, centres just above)',
   ymin > 0 && ymin < 0.12, `lowest centre y=${ymin.toFixed(3)}, splat radius ~0.05`);
ok('shoulder width is human-plausible', (xmax-xmin)>0.3 && (xmax-xmin)<0.7, `${(xmax-xmin).toFixed(2)} m`);
ok('gaussian count is cheap enough for crowds', idle.count < 1200, `${idle.count} per figure`);

hdr('Determinism and pose response');
const a = C.buildCharacter({seed:7, pose:C.IDLE, density:1});
const b = C.buildCharacter({seed:7, pose:C.IDLE, density:1});
let same = a.count===b.count;
if(same) for(let i=0;i<a.pos.length;i++) if(a.pos[i]!==b.pos[i]){same=false;break;}
ok('same seed + pose is byte-identical', same);
const c2 = C.buildCharacter({seed:8, pose:C.IDLE, density:1});
ok('different seed differs (clothing/palette)', c2.pos[0]!==a.pos[0] || c2.color[0]!==a.color[0]);

// phases 0 and PI both give sin=0 (legs straight) — use quarter phases where
// the swing is at its extreme, otherwise the test compares two identical poses.
const w1 = C.buildCharacter({seed:7, pose:C.poseWalk(Math.PI/2), density:1});
const w2 = C.buildCharacter({seed:7, pose:C.poseWalk(Math.PI*1.5), density:1});
let legSpread1=0, legSpread2=0;
for(let i=0;i<w1.count;i++){ if(w1.part[i]===4||w1.part[i]===5) legSpread1=Math.max(legSpread1, Math.abs(w1.pos[i*3+2])); }
for(let i=0;i<w2.count;i++){ if(w2.part[i]===4||w2.part[i]===5) legSpread2=Math.max(legSpread2, Math.abs(w2.pos[i*3+2])); }
ok('walk phase moves the legs (sagittal swing)', legSpread1>0.1 || legSpread2>0.1, `max |z| of leg gaussians ${Math.max(legSpread1,legSpread2).toFixed(2)} m`);
let diff=0; for(let i=0;i<w1.pos.length;i++) if(Math.abs(w1.pos[i]-w2.pos[i])>1e-6) diff++;
ok('opposite walk phases produce different poses', diff > w1.pos.length*0.3, `${(diff/w1.pos.length*100).toFixed(0)}% of coords differ`);

hdr('Skeleton integrity');
let nonFinite=0, badN=0, badO=0;
for(let i=0;i<w1.count;i++){
  for(let k=0;k<3;k++){ if(!isFinite(w1.pos[i*3+k])||!isFinite(w1.normal[i*3+k])||!isFinite(w1.scale[i*3+k])) nonFinite++; }
  if(Math.abs(Math.hypot(w1.normal[i*3],w1.normal[i*3+1],w1.normal[i*3+2])-1)>1e-3) badN++;
  if(!(w1.opacity[i]>=0&&w1.opacity[i]<=1)) badO++;
}
ok('no NaN/Infinity in the figure', nonFinite===0);
ok('all normals unit length', badN===0, `${badN} bad`);
ok('opacities in [0,1]', badO===0);
const parts=new Set(w1.part);
ok('all body parts present (torso,neck,head,thigh,shin,foot,upperarm,forearm)', parts.size>=8, `${parts.size} parts`);

hdr('Placement transform');
const local = C.buildCharacter({seed:7, pose:C.IDLE, density:1});
const placed = C.allocLike(local);
C.place(local, 10, 2, 5, Math.PI/2, placed);
let px=placed.pos[0], pz=placed.pos[2];
ok('root translation applied', Math.abs(placed.pos[1*3+1]-local.pos[1*3+1]-2)<1e-6, 'y offset exact');
// yaw 90 deg should map local +Z to world +X
const idxTip = (()=>{ let bi=0,bz=-1e9; for(let i=0;i<local.count;i++) if(local.pos[i*3+2]>bz){bz=local.pos[i*3+2];bi=i;} return bi; })();
const lx=local.pos[idxTip*3], lz=local.pos[idxTip*3+2];
const wx=placed.pos[idxTip*3]-10, wz=placed.pos[idxTip*3+2]-5;
const dot = (lx*wx+lz*wz)/(Math.hypot(lx,lz)*Math.hypot(wx,wz)||1);
ok('yaw rotates the figure about Y', dot < 0.2, `local(+Z) vs world dir dot=${dot.toFixed(3)} (yaw 90deg)`);
let preserved=0; for(let i=0;i<local.count;i++){ const d1=Math.hypot(local.pos[i*3],local.pos[i*3+2]), d2=Math.hypot(placed.pos[i*3]-10,placed.pos[i*3+2]-5); if(Math.abs(d1-d2)<1e-5) preserved++; }
ok('yaw preserves radial distance (rigid transform)', preserved===local.count, `${preserved}/${local.count}`);

console.log(`\n\x1b[1m${P} passed, ${F} failed\x1b[0m\n`);
process.exit(F?1:0);
